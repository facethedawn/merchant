(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([["common"],{

/***/ "../../2023-qj/qj-request-tools/packages/request/dist/index.js":
/*!*********************************************************************!*\
  !*** ../../2023-qj/qj-request-tools/packages/request/dist/index.js ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "get": function() { return /* binding */ w; },
/* harmony export */   "post": function() { return /* binding */ S; },
/* harmony export */   "postFormData": function() { return /* binding */ N; }
/* harmony export */ });
/* unused harmony exports errorCallback, fly, getTaroEnv, isWechat, postWithJson, resetStatus, wxLogin */
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js */ "./node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js");
/* harmony import */ var _brushes_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @brushes/utils */ "../../2023-qj/qj-request-tools/packages/utils/dist/index.js");
/* harmony import */ var qs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! qs */ "../../2023-qj/qj-request-tools/node_modules/qs/lib/index.js");
/* harmony import */ var qs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(qs__WEBPACK_IMPORTED_MODULE_1__);
/* provided dependency */ var navigator = __webpack_require__(/*! @tarojs/runtime */ "webpack/container/remote/@tarojs/runtime")["navigator"];
/* provided dependency */ var document = __webpack_require__(/*! @tarojs/runtime */ "webpack/container/remote/@tarojs/runtime")["document"];
/* provided dependency */ var window = __webpack_require__(/*! @tarojs/runtime */ "webpack/container/remote/@tarojs/runtime")["window"];



function u(n, e, t, A) {
  return new (t || (t = Promise))(function (o, i) {
    function r(n) {
      try {
        c(A.next(n));
      } catch (n) {
        i(n);
      }
    }
    function s(n) {
      try {
        c(A.throw(n));
      } catch (n) {
        i(n);
      }
    }
    function c(n) {
      var e;
      n.done ? o(n.value) : (e = n.value, e instanceof t ? e : new t(function (n) {
        n(e);
      })).then(r, s);
    }
    c((A = A.apply(n, e || [])).next());
  });
}
var d = function () {
  var n = navigator.userAgent.toLowerCase();
  try {
    return "micromessenger" == n.match(/micromessenger/i) || Boolean(wx);
  } catch (n) {
    return !1;
  }
}();
function m(n) {
  return n.getEnv();
}
var g = !1,
  b = [];
function p(n, e, t) {
  return u(this, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_2__["default"])().mark(function _callee() {
    return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_2__["default"])().wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          return _context.abrupt("return", new Promise(function (A, o) {
            if (b.push({
              handler: function handler() {
                return e.request(n);
              },
              resolve: A
            }), !g) {
              g = !0;
              switch (m(t)) {
                case "WEAPP":
                  !function (n) {
                    setTimeout(function () {
                      n.navigateTo({
                        url: "/account/auth/index",
                        success: function success() {
                          g = !1;
                        }
                      });
                    }, 10);
                  }(t);
                  break;
                case "WEB":
                  !function (n) {
                    setTimeout(function () {
                      n.navigateTo({
                        url: "/account/mobileLogin/index",
                        success: function success() {
                          g = !1;
                        }
                      });
                    }, 10);
                  }(t);
              }
            }
          }));
        case 1:
        case "end":
          return _context.stop();
      }
    }, _callee);
  }));
}
var E = function E() {
    b.forEach(function (n) {
      return u(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_2__["default"])().mark(function _callee2() {
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_2__["default"])().wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              _context2.t0 = (0, n.resolve);
              _context2.next = 3;
              return n.handler();
            case 3:
              _context2.t1 = _context2.sent;
              (0, _context2.t0)(_context2.t1);
            case 5:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }));
    }), b = [];
  },
  D = function D() {
    g = !1;
  },
  h = "data:image/jpeg;base64,/9j/4QAYRXhpZgAASUkqAAgAAAAAAAAAAAAAAP/sABFEdWNreQABAAQAAABkAAD/4QMvaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA2LjAtYzAwNiA3OS5kYWJhY2JiLCAyMDIxLzA0LzE0LTAwOjM5OjQ0ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpFNzA0OEVFQTZBMzUxMUVEQThENUIyQURDQ0NGMzA5RSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpFNzA0OEVFOTZBMzUxMUVEQThENUIyQURDQ0NGMzA5RSIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjIuNCAoTWFjaW50b3NoKSI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkU3MDQ4RUU1NkEzNTExRURBOEQ1QjJBRENDQ0YzMDlFIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkU3MDQ4RUU2NkEzNTExRURBOEQ1QjJBRENDQ0YzMDlFIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+/+4ADkFkb2JlAGTAAAAAAf/bAIQAAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQICAgICAgICAgICAwMDAwMDAwMDAwEBAQEBAQECAQECAgIBAgIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMD/8AAEQgAKAAoAwERAAIRAQMRAf/EAIsAAAIDAQAAAAAAAAAAAAAAAAgKBAYHBQEAAgMBAQAAAAAAAAAAAAAABggDBQkEBxAAAQQCAQMDAwUAAAAAAAAAAQIDBAUGBwgAERMhEgkUFRcxIiMkFhEAAgECBAQEAwcEAwAAAAAAAQIDEQQSEwUGACEUBzFRIhVBoQhxMmIjMxYXYZFSQ7FTJP/aAAwDAQACEQMRAD8Ads5O8nNbcU9Zzdj7ElPyFOviqxPE6nwu5Nm+SvoUuJQ0MV1xtHuCUl2VKdKY0GKhbzyglPqPbj3Hp219NOo6gSeeFEX78jnwVR82J5KKknj2Lsh2Q3p373tHszZ0aoFTNu7uWotrK2U0eedgCfGixRKDJPKVjjUseSwG+PkQ5Wb8nzEzdgTtU4c+ZLcTANT2M3HozcF/2oSxf5gwtnK8lm+JsBbiXocQrKi3GQCOlu1rf26NdY452tbM1pFASgofg0g9bn+tVXyUcbj9qvo97CdprWM22kRa/uNcJe/1WNLhi688UFowa1tkqfSpSaWlA8zEcBz9/wAjLypRyjKjNU2Wl2Jye/NotskKKF2psTYLQVAEgunuoA/qO/Qnn3GLFmS4/PG1f71r8+GMGkaNgEIsbDp61EfTQZQPmIsvLBp5L4cvDgxND/Idyq0HaRHYuf2m2sPjsNxZOuts3E69r3ojQX4xSZc8iXleNWDYX+x0vTIvcJDkZYHRXom/Nz6DKGSdrq0AoYZ2LAj8MnN0Pkasvmp4XTur9H/YfuzYyRz6TBt/cLsWXUdKhSCQOaVz7RSlrcxmnqXBDLzOCZTw0Dxj5Oa05Wa1i7G1zNfaUzINPluJ2obZyTCMmaZbelUN7FbUU+7xuJdiymiqNOjLQ8ytSVejJ7b3Jp26NOGoaeSKHC6NyeNx4qw+YI5MKEGnGG/e/shvbsLvWTZu8Y0YMmbaXUVWtr22JISeBjz8QVliakkMgaORQw5rA/Ihvmz35yrz2Q7LZfw7Udpcan1zGiOeaG1Co5yGcxvg4EoS5Y5LlcR5LrgB/qQozYUQgkrbv7W5Nd3ROxINraM0EQHMUU/mN9ruDX8KqPhxuN9H3amx7TdhtJhijZNx7hgh1XUWcYXLzoWs4KcyI7a1dCqn/bNO9AW5ZFxt0EeS2wxqyt2nhesMusK9czD2M4q7ifDzqXFRIftKKllVUiM3Euq2CwJPhdKnJLBWplC/C72qdvaJ+4tQ9rjuoba7ZaxiRWIlIqSqlSKMAK0PMitAaHj0HvP3ZHZXZ377vdB1PXNuwzBLtrKWGN7FGKrFPMsqsXhkdsvGlFjfCJGXMStZ/BW3RvE8bThFn+aBlycOOIjuUiQoh9OTGyDao4wM0pFr937fS/bf5O/v/j65vZdV96/buS3vObl5f9fHHXwysPrx+GDn48uL3+VO3v8AF380e6Qfxt7f1nV/hHpNtl1xddnf+XpP1eo9H3fXxZ+SmgVcaNi/iuz2nhmzsvrq9qZmEfCKq4gQ8FlTG40mqormTayZLcy6s6+R9UGWilyPH9inkJ8zXfp3DoZ25qHtclzDc3arWQRqwERNCqsWJqzA4qDmBQkCo4ouy3dod7Nnfvyy0HUtD27NMUtGvZYZHvlQsss8KxKpSGKRcrG9VkkxLGzZb01347t8T9B8rMBmKmFnDNsT6/UuwYjsr6aC5GyGcljDcgfCwpn67GcseZS24QFiHNlNhQC+rbYOtPoW54GrS0umEEorQUc/lt9qPSh/xZh8ePPvrD7U2ndjsLq1sseLcmgRSarYOFxOGt0LXlutKHBc2ocstaGaGByCV4Di/wDMMjycSg2icMqyYWKWu4bRZi/sRaIQFd1hKLDygBRKh29ST36E5v15K/ezXr9uI1+deGN0jB7NY5FTbdBbZZPiYsiPKJ+FTHhPLl5cqcRK9y3YtqN7G3btjKmr+jOHvYwZCcpZzA2cZOLqxYxP7X+jN0WRDDf7lPEA90lQ6jQyrKhgLi5Ei5eCuPMqMGCnPHiphp8eOi7TTpdPuo9aW1fQWtJ+rW5w9KbTLY3PVY/T0+TjM2LkEqfEDhsBMfaydUC5+2aHV8piuLhguxxZVyLlWPJvipLhQAoqgpv1Jd7FAov9F3aDoh/u6aCmqDS83DY/yZ7ZSlRiwYv+MXP/AK83lXBz4wJMuwjv720z7rH0JDfWMNlyGHqMihFf8zBVfHrvb6SGM3PLhUCykXUq3vZOTv3krLXr+7VmUnKVPqyp7MBYyG8nVlJldpX+jTcIdTMDnZSXklIASEgK+7StK7XJc3ZkbML1xmSpx4688eKuKvx430sotNg061h0NLWPb62kIs1tcItRZ5am26XD6enyShhK8ihBNWJPEqg8wyPGDFLaJwyrGTXKd7htFmL+uNWtZT3WEosPESUgqHb0BPbqSH9eOn3s1KfbiFPnTiHV8Hs19n1Nt0FzmAeJiyJM0D4VMeIc+XnyrwY/yI6Hn6D5WZ9DTDLOGbYn2G2tfS2ov00FyNkM5T+ZY+wUFTP12M5Y88pxsELEObFcKQF9Fm/tFfQtzzrSlpdMZ4jSgo5/MX7UetR/iyn48Ll9Hnda07sdhdJuWkxbk0CKPSr9C2Jw1ugWzuGrQ4Lm1CBWpQzQzoCSvGS8Zt8QONuyvyt+KMb2tlNXVPQ8HTld7PqK3B7eUXG5uUQosKusUWNzIhKEZpxYaciMl3wrSp5RFXtzWk29qXunSx3VyqUjxsVEbHxcAA1YjkCaFRWh5ng/73dqbvvTsr9he/3ugaFPOHvTawJLJexLQpbOzyRmOFXBkZVxLK4jzFIjUHgDkFuRO+1cnk5rJTu5WSHJVZT4VGCpox/tpw40/n8X4+OPgVn2ryeMQx7gr6j+bqAa7q41z9yiY+85mPH8PCmXhr+lh9GCtMPxxeri3PaLtw3agdjn0xD2wFl03S19dcWZ1mdhr7h1H/p6rDizuVMn8riwcmd8wOSmyRtX8T4zqnKbOraiZwMTvJ9tAzq3jeFuFk06LNrq5FdcxITZjOONhxyWz4/MtSmUHqfcetpuLUfdOlitbllpJlsWErDwcggUYDlUVLClSaDin7JdqLrstsv9h+/32v6DBOXsuqgjiksYmqXtkZJJDJCzkSKrYVifHlqBIw41j479DWe/OVeBR2ojL+HajtKfbGxpMtvzQ2oVHOW9h1CWypCXLHJcriMqabJP9SFJcKSEAG02Dokmu7ogUAG1tGWeUnmKKfy1+13Ap+FWPw4AfrB7rWPabsNq00sjJuPcME2lacqHC5edAt5PXmRHbWruGYf7ZoEqC3Jn7k5xj1pys1rK1zsaE+0pmQLjEssqi2zkmEZM0y4zFvqKU4kp93jcU1KiuhUadGWtl5Ckq9GS3JtvTt0acdP1AEUOJHXk8bjwZT8iDyYVBFOMOeyHe/e3YXese8tnSIwZMq7tZatbXtsSC8E6jn4gNFKtJIZAskbBhzV+3z8eXKnQVpLbl4Dabaw+Ow5Lj7G1PTzryudhshBdXeYiyuVleNWLYV3W0GZkX0UW5KwOls1vYe59DlKvA11aAVE0ClgR+KPm6HzFGXyY8bkdqvq/7Dd2bGOS31aDb+4ncI2narMkEgc1oILshbW5jNPS2OGXmMcKngNRU3ypCYgxjLjNUgOJrxiOTGxW2SUhaK8VX1q0lYIBDZ9R2/XoQy5cWDLlx+WW9f7Ya/LhkPcdJERuOu0/pgaGTq7bLB8jJm4Aac/veHPw4MvQ/wAeHKrf06GuDgE/VWGvmM7L2Dtium49FbhP+5Sn6HD30s5Xks0Ntn2NqZhxCspDklAJ6MNE2DufXXGXA1rZGlZZwUFD8VjPrc/0oq+bDhbu631gdhu01tIt1q0WvbkTEEsNKkS4YuvLDPdqTa2yVIxMHmlpUpCxHDQHGLjHrbinrOFrjXcV+Qp182uWZZbeF3Js3yV9CUS76+lNNto9wSkNRYrQTGgxUIZZSEp9WR25tzTtr6aNO08E88Tu335HPizH5KByUUAHGHHe/vfvTv3vaTee8ZFQKmVaWkVRbWVspqkECkk+NWllYmSeUtJIxY8v/9k=";
function M(n) {
  var e = function (n) {
    var e = document.createElement("div");
    return e.innerHTML = "\n    <div\n      style=\"\n        box-sizing: border-box; \n        margin: 0;\n        padding: 0;\n        color: rgba(0, 0, 0, 0.88);\n        font-size: 14px; \n        line-height: 1.5714285714285714;\n        list-style: none;\n        font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,'Noto Sans',sans-serif,'Apple Color Emoji','Segoe UI Emoji','Segoe UI Symbol','Noto Color Emoji';\n        position: fixed;\n        top: 8px;\n        inset-inline-start: 0;\n        width: 100%;\n        text-align: center;\n        pointer-events: none;\n        z-index: 1010;\"\n      >\n      <div\n        style=\"display: inline-block;\n        padding: 9px 12px;\n        background: #fff;\n        border-radius: 8px;\n        line-height: 1;\n        box-shadow: 0 6px 16px 0 rgb(0 0 0 / 8%), 0 3px 6px -4px rgb(0 0 0 / 12%), 0 9px 28px 8px rgb(0 0 0 / 5%);\n        pointer-events: all\"\n        >\n          <span\n            style=\"vertical-align: text-bottom;\n            margin-inline-end: 4px;\n            font-size: 16px;\n            display: inline-block;\n            font-style: normal;\n            line-height: 0;\n            text-align: center;\n            text-transform: none;\n            text-rendering: optimizeLegibility\"\n          >\n            <img width=\"16\" alt=\"error\" src=".concat(h, ">\n        </span>\n        <span>\n            ").concat(n, "\n          </span>\n      </div>\n    </div>"), e;
  }(n);
  document.body.appendChild(e), setTimeout(function () {
    document.body.removeChild(e);
  }, 1e3);
}
var v = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_0__.getEnv)() ? function (n, A, o) {
    return u(this, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_2__["default"])().mark(function _callee3() {
      var i, _n;
      return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_2__["default"])().wrap(function _callee3$(_context3) {
        while (1) switch (_context3.prev = _context3.next) {
          case 0:
            i = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_0__.getTaro)();
            if (!("nologin" === n.errorCode)) {
              _context3.next = 7;
              break;
            }
            _n = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_0__.getKey)();
            i.removeStorageSync(_n);
            _context3.next = 6;
            return p(A, o, i);
          case 6:
            return _context3.abrupt("return", _context3.sent);
          case 7:
            return _context3.abrupt("return", (i.showToast({
              title: n.msg || "接口失败",
              icon: "error",
              duration: 1e3
            }), Promise.reject(n.msg || "接口失败")));
          case 8:
          case "end":
            return _context3.stop();
        }
      }, _callee3);
    }));
  } : function (n) {
    return u(this, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_2__["default"])().mark(function _callee4() {
      var _n2;
      return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_2__["default"])().wrap(function _callee4$(_context4) {
        while (1) switch (_context4.prev = _context4.next) {
          case 0:
            if (!(M(n.msg || "接口报错"), "nologin" === n.errorCode)) {
              _context4.next = 17;
              break;
            }
            _n2 = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_0__.getKey)();
            if (localStorage.getItem(_n2)) {
              _context4.next = 4;
              break;
            }
            return _context4.abrupt("return");
          case 4:
            _context4.prev = 4;
            if (!process.env.REACT_APP_NO_LOAD) {
              _context4.next = 7;
              break;
            }
            return _context4.abrupt("return");
          case 7:
            _context4.next = 9;
            return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_0__.removeStorage)(_n2);
          case 9:
            window.location.reload();
            _context4.next = 17;
            break;
          case 12:
            _context4.prev = 12;
            _context4.t0 = _context4["catch"](4);
            _context4.next = 16;
            return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_0__.removeStorage)(_n2);
          case 16:
            window.location.reload();
          case 17:
            return _context4.abrupt("return", Promise.reject(n.msg || "接口失败"));
          case 18:
          case "end":
            return _context4.stop();
        }
      }, _callee4, null, [[4, 12]]);
    }));
  },
  y = new (__webpack_require__(d ? /*! flyio/dist/npm/wx */ "../../2023-qj/qj-request-tools/node_modules/flyio/dist/npm/wx.js" : /*! flyio/dist/npm/fly */ "../../2023-qj/qj-request-tools/node_modules/flyio/dist/npm/fly.js"))();
y.interceptors.request.use(function (n) {
  var e = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_0__.getKey)(),
    A = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_0__.getTokenValueKey)();
  n.headers[e] = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_0__.getStorage)(A), n.baseURL = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_0__.getBaseUrl)();
  var c = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_0__.getH5Platform)();
  return c && (n.headers["Saas-Agent"] = c), d && (n.headers["Saas-Agent"] = "qj-wemini"), n;
});
y.interceptors.response.use(function (n) {
  return u(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_2__["default"])().mark(function _callee5() {
    var e;
    return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_2__["default"])().wrap(function _callee5$(_context5) {
      while (1) switch (_context5.prev = _context5.next) {
        case 0:
          e = n.data;
          if (!function (n) {
            return n.errorCode || !1 === n.success;
          }(e)) {
            _context5.next = 7;
            break;
          }
          _context5.next = 4;
          return v(e, n.request, y);
        case 4:
          _context5.t0 = _context5.sent;
          _context5.next = 8;
          break;
        case 7:
          _context5.t0 = e;
        case 8:
          return _context5.abrupt("return", _context5.t0);
        case 9:
        case "end":
          return _context5.stop();
      }
    }, _callee5);
  }));
}, function (n) {
  console.log(n);
});
var Q = function Q(n) {
    var e = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    return x(n, function () {
      return y.post(n, (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_0__.getParams)(e));
    }, e);
  },
  w = function w(n) {
    var e = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    return x(n, function () {
      return y.get(n, (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_0__.getParams)(e));
    }, e);
  },
  N = function N(n) {
    var e = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    return x(n, function () {
      var t = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_0__.formDataTrans)((0,_brushes_utils__WEBPACK_IMPORTED_MODULE_0__.getParams)(e));
      return y.post(n, t);
    }, e);
  },
  S = function S(n) {
    var e = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    return x(n, function () {
      return y.post(n, qs__WEBPACK_IMPORTED_MODULE_1__.stringify((0,_brushes_utils__WEBPACK_IMPORTED_MODULE_0__.getParams)(e)));
    }, e);
  },
  x = function x(n, e, t) {
    var _t$isLocalMock = t.isLocalMock,
      A = _t$isLocalMock === void 0 ? "" : _t$isLocalMock;
    if (!A) return e();
    var o = n.match(/(\w+)\.json/g);
    return o ? y.get("https://brushes.oss-cn-shanghai.aliyuncs.com/mock/".concat(o)) : e();
  },
  Z = y;


/***/ }),

/***/ "../../2023-qj/qj-request-tools/packages/utils/dist/index.js":
/*!*******************************************************************!*\
  !*** ../../2023-qj/qj-request-tools/packages/utils/dist/index.js ***!
  \*******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "formDataTrans": function() { return /* binding */ I; },
/* harmony export */   "getBaseUrl": function() { return /* binding */ L; },
/* harmony export */   "getEnv": function() { return /* binding */ i; },
/* harmony export */   "getH5Platform": function() { return /* binding */ M; },
/* harmony export */   "getKey": function() { return /* binding */ k; },
/* harmony export */   "getPagesRefreshStore": function() { return /* binding */ m; },
/* harmony export */   "getParams": function() { return /* binding */ R; },
/* harmony export */   "getStorage": function() { return /* binding */ E; },
/* harmony export */   "getTaro": function() { return /* binding */ l; },
/* harmony export */   "getTokenValueKey": function() { return /* binding */ C; },
/* harmony export */   "navigatorBackImpl": function() { return /* binding */ h; },
/* harmony export */   "navigatorHandler": function() { return /* binding */ v; },
/* harmony export */   "removeStorage": function() { return /* binding */ O; },
/* harmony export */   "setRouterMap": function() { return /* binding */ _; },
/* harmony export */   "setStorage": function() { return /* binding */ T; },
/* harmony export */   "taroMessage": function() { return /* binding */ w; },
/* harmony export */   "updatePagesRefreshStore": function() { return /* binding */ p; },
/* harmony export */   "useImmutableCallback": function() { return /* binding */ $; }
/* harmony export */ });
/* unused harmony exports getStorageWeb, pagesRefreshStore, routerMap, setPagesRefreshStore, setStorageWeb, setTaro, useMountedRef */
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash-es */ "../../2023-qj/qj-request-tools/node_modules/lodash-es/isEmpty.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash-es */ "../../2023-qj/qj-request-tools/node_modules/lodash-es/omit.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash-es */ "../../2023-qj/qj-request-tools/node_modules/lodash-es/isFunction.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lodash-es */ "../../2023-qj/qj-request-tools/node_modules/lodash-es/noop.js");
/* harmony import */ var qs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! qs */ "../../2023-qj/qj-request-tools/node_modules/qs/lib/index.js");
/* harmony import */ var qs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(qs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/container/remote/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* provided dependency */ var window = __webpack_require__(/*! @tarojs/runtime */ "webpack/container/remote/@tarojs/runtime")["window"];



var s = {};
function i() {
  try {
    var _r = l();
    return !(0,lodash_es__WEBPACK_IMPORTED_MODULE_2__["default"])(_r);
  } catch (t) {
    return !1;
  }
}
function l() {
  return (0,lodash_es__WEBPACK_IMPORTED_MODULE_2__["default"])(s) && (s = __webpack_require__(/*! @tarojs/taro */ "webpack/container/remote/@tarojs/taro")), s;
}
function f(t) {
  s = t;
}
var S = {},
  g = {};
function p(t) {
  Object.assign(g, t), y(g);
}
function y(t) {
  g = t;
}
function m() {
  return g;
}
function _(t) {
  S = t, s.setStorageSync("routerMap", S);
}
var d = function d() {
  var r = S;
  return (0,lodash_es__WEBPACK_IMPORTED_MODULE_2__["default"])(r) && (r = s.getStorageSync("routerMap")), r;
};
function v(t) {
  var r = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  if (i()) {
    if (!t) return;
    if (/^\/account/.test(t)) return void s.navigateTo({
      url: t
    });
    var _e = d(),
      _e$t = _e[t],
      _n = _e$t.level,
      _c = _e$t.pagePath;
    if (s.setStorageSync("menuOpcode", t), 1 === _n) s.switchTab({
      url: "/".concat(_c)
    });else {
      var _t = "/".concat(_c, "?").concat(qs__WEBPACK_IMPORTED_MODULE_0__.stringify(r));
      s.navigateTo({
        url: _t
      });
    }
  }
}
function h() {
  var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
  i() && s.navigateBack({
    delta: t
  });
}
function w(t) {
  var r = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "success";
  s.showToast({
    title: t,
    icon: r,
    duration: 2e3
  });
}
var A = function A(t) {
    var r = window.localStorage.getItem(t) || "";
    try {
      return JSON.parse(r);
    } catch (t) {
      return r;
    }
  },
  E = function E(t) {
    try {
      if (localStorage) return A(t);
      return l().getStorageSync(t);
    } catch (t) {
      return "";
    }
  },
  P = function P(t, r) {
    "string" == typeof r ? window.localStorage.setItem(t, r) : window.localStorage.setItem(t, JSON.stringify(r));
  },
  T = function T(t, r) {
    if (localStorage) P(t, r);else {
      l().setStorageSync(t, r);
    }
  },
  O = function O(t) {
    if (localStorage) window.localStorage.removeItem(t);else {
      l().removeStorageSync(t);
    }
  },
  I = function I(t) {
    var r = new FormData();
    for (var _e2 in t) ["", void 0, null].includes(t[_e2]) || r.append(_e2, t[_e2]);
    return r;
  },
  R = function R() {
    var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,lodash_es__WEBPACK_IMPORTED_MODULE_3__["default"])(t, "isLocalMock");
  };
function k() {
  try {
    return "saas-token" || 0;
  } catch (t) {
    return "saas-token";
  }
}
function C() {
  try {
    return process.env.REACT_APP_SESSION_VALUE_KEY || "";
  } catch (t) {
    return "saas-token";
  }
}
function L() {
  try {
    return "https://b2cweapp40673927e2a14ea49df338dc06bd4e9a.saas.qjclouds.com/" || 0;
  } catch (t) {
    return "";
  }
}
function M() {
  try {
    return process.env.REACT_APP_PLAT_FORM || "";
  } catch (t) {
    return "";
  }
}
var N = function N() {
  var t = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(!1);
  return (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    return t.current = !0, function () {
      t.current = !1;
    };
  }, []), t;
};
function $(t) {
  var r = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
  return r.current = (0,lodash_es__WEBPACK_IMPORTED_MODULE_4__["default"])(t) ? t : lodash_es__WEBPACK_IMPORTED_MODULE_5__["default"], (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(function () {
    return r.current.apply(r, arguments);
  }, [r]);
}


/***/ }),

/***/ "../../qj/qj-mobile-react/packages/s-material-react/dist/index.js":
/*!************************************************************************!*\
  !*** ../../qj/qj-mobile-react/packages/s-material-react/dist/index.js ***!
  \************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddressDetail": function() { return /* binding */ Hs; },
/* harmony export */   "AddressList": function() { return /* binding */ Rs; },
/* harmony export */   "AllCouponList": function() { return /* binding */ yt; },
/* harmony export */   "AllPromotionList": function() { return /* binding */ ft; },
/* harmony export */   "ArticleDetail": function() { return /* binding */ xa; },
/* harmony export */   "BackTop": function() { return /* binding */ Pa; },
/* harmony export */   "Cart": function() { return /* binding */ Js; },
/* harmony export */   "CartList": function() { return /* binding */ ra; },
/* harmony export */   "CartOperate": function() { return /* binding */ da; },
/* harmony export */   "CartTop": function() { return /* binding */ _s; },
/* harmony export */   "ClassifyNav": function() { return /* binding */ Ma; },
/* harmony export */   "ClassifyNavOne": function() { return /* binding */ Wa; },
/* harmony export */   "ClassifyNavOneJsx": function() { return /* binding */ Fa; },
/* harmony export */   "ClassifyNavThree": function() { return /* binding */ Ea; },
/* harmony export */   "ClassifyNavTwo": function() { return /* binding */ Ga; },
/* harmony export */   "CollectionList": function() { return /* binding */ fa; },
/* harmony export */   "CouponList": function() { return /* binding */ qs; },
/* harmony export */   "Cube": function() { return /* binding */ Te; },
/* harmony export */   "EvaluateDetail": function() { return /* binding */ Ss; },
/* harmony export */   "EvaluateList": function() { return /* binding */ vs; },
/* harmony export */   "ExpressInfo": function() { return /* binding */ Vs; },
/* harmony export */   "FootPrint": function() { return /* binding */ ja; },
/* harmony export */   "GetCouponOne": function() { return /* binding */ Nt; },
/* harmony export */   "Goods": function() { return /* binding */ Ha; },
/* harmony export */   "GoodsClassify": function() { return /* binding */ ls; },
/* harmony export */   "GoodsClassifyOne": function() { return /* binding */ hs; },
/* harmony export */   "GoodsClassifyTwo": function() { return /* binding */ Ns; },
/* harmony export */   "GoodsDetailAndEvaluate": function() { return /* binding */ lt; },
/* harmony export */   "GoodsDetailBanner": function() { return /* binding */ Ka; },
/* harmony export */   "GoodsDetailCoupon": function() { return /* binding */ at; },
/* harmony export */   "GoodsDetailHandleBar": function() { return /* binding */ ht; },
/* harmony export */   "GoodsDetailHandleBarOne": function() { return /* binding */ pt; },
/* harmony export */   "GoodsDetailInfo": function() { return /* binding */ Za; },
/* harmony export */   "GoodsDetailInfoOne": function() { return /* binding */ $a; },
/* harmony export */   "GoodsDetailPromotion": function() { return /* binding */ et; },
/* harmony export */   "GoodsDetailSku": function() { return /* binding */ _a; },
/* harmony export */   "GoodsList": function() { return /* binding */ fs; },
/* harmony export */   "GoodsSlider": function() { return /* binding */ Ya; },
/* harmony export */   "GoodsSlideshow": function() { return /* binding */ Qa; },
/* harmony export */   "Line": function() { return /* binding */ za; },
/* harmony export */   "MineData": function() { return /* binding */ ga; },
/* harmony export */   "MineFunction": function() { return /* binding */ ha; },
/* harmony export */   "MineOrderEntry": function() { return /* binding */ ma; },
/* harmony export */   "Notice": function() { return /* binding */ Ve; },
/* harmony export */   "NoticeDetail": function() { return /* binding */ ya; },
/* harmony export */   "OrderDetail": function() { return /* binding */ is; },
/* harmony export */   "OrderList": function() { return /* binding */ ts; },
/* harmony export */   "PaymentMode": function() { return /* binding */ ba; },
/* harmony export */   "PlaceOrderAddress": function() { return /* binding */ Ia; },
/* harmony export */   "PlaceOrderCoupon": function() { return /* binding */ Aa; },
/* harmony export */   "PlaceOrderDelivery": function() { return /* binding */ Ba; },
/* harmony export */   "PlaceOrderGood": function() { return /* binding */ Va; },
/* harmony export */   "PlaceOrderInfo": function() { return /* binding */ Da; },
/* harmony export */   "PlaceOrderOperate": function() { return /* binding */ Ta; },
/* harmony export */   "PlaceOrderResult": function() { return /* binding */ Us; },
/* harmony export */   "QjMobileIcon": function() { return /* binding */ Os; },
/* harmony export */   "Search": function() { return /* binding */ Me; },
/* harmony export */   "SearchPage": function() { return /* binding */ xs; },
/* harmony export */   "SearchStyleTwo": function() { return /* binding */ Fe; },
/* harmony export */   "Service": function() { return /* binding */ Pe; },
/* harmony export */   "Slider": function() { return /* binding */ Ee; },
/* harmony export */   "TextLine": function() { return /* binding */ Ra; },
/* harmony export */   "Title": function() { return /* binding */ De; },
/* harmony export */   "Video": function() { return /* binding */ Le; }
/* harmony export */ });
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js */ "./node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "webpack/container/remote/react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @brushes/simulate-component */ "../../qj/qj-mobile-react/node_modules/@brushes/simulate-component/dist/index.js");
/* harmony import */ var _brushes_simulate_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @brushes/simulate-component */ "../../qj/qj-mobile-react/node_modules/antd-mobile/es/index.js");
/* harmony import */ var qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! qj-mobile-store */ "../../qj/lerna-repo/packages/qj-mobile-store/dist/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "webpack/container/remote/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _brushes_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @brushes/utils */ "../../qj/qj-mobile-react/node_modules/@brushes/utils/dist/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! classnames */ "../../qj/qj-mobile-react/node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var qj_b2c_api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! qj-b2c-api */ "../../qj/qj-mobile-react/node_modules/qj-b2c-api/dist/index.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! lodash-es */ "../../qj/qj-mobile-react/node_modules/lodash-es/get.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! lodash-es */ "../../qj/qj-mobile-react/node_modules/lodash-es/isEmpty.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! lodash-es */ "../../qj/qj-mobile-react/node_modules/lodash-es/groupBy.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! lodash-es */ "../../qj/qj-mobile-react/node_modules/lodash-es/isEqual.js");
/* harmony import */ var china_division_dist_provinces_json__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! china-division/dist/provinces.json */ "../../qj/qj-mobile-react/node_modules/china-division/dist/provinces.json");
/* harmony import */ var china_division_dist_cities_json__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! china-division/dist/cities.json */ "../../qj/qj-mobile-react/node_modules/china-division/dist/cities.json");
/* harmony import */ var china_division_dist_areas_json__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! china-division/dist/areas.json */ "../../qj/qj-mobile-react/node_modules/china-division/dist/areas.json");
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! dayjs */ "../../qj/qj-mobile-react/node_modules/dayjs/dayjs.min.js");
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_9__);
















var Ve = function Ve(_ref) {
    var s = _ref.direction,
      a = _ref.speed,
      i = _ref.num,
      n = _ref.color;
    var _l = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useNotice)(i),
      c = _l.content,
      o = _l.navigator;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.NoticeBar, {
      navigator: o,
      color: n,
      speed: a,
      direction: s,
      content: c
    });
  },
  De = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref2) {
    var s = _ref2.value,
      a = _ref2.textIndent,
      t = _ref2.fontSize,
      n = _ref2.textAlign,
      c = _ref2.color,
      l = _ref2.backgroundColor,
      o = _ref2.fontWeight,
      r = _ref2.textDecoration,
      d = _ref2.fontStyle,
      g = _ref2.paddingTop,
      m = _ref2.paddingLeft,
      h = _ref2.paddingRight,
      p = _ref2.paddingBottom;
    var _i = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      b = _i.View;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, Object.assign({
      className: "components-title",
      style: {
        paddingTop: g,
        paddingBottom: p
      }
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, Object.assign({
        style: {
          fontSize: t,
          textAlign: n,
          color: c,
          backgroundColor: l,
          fontWeight: o,
          textDecoration: r,
          fontStyle: d,
          paddingLeft: m,
          paddingRight: h,
          textIndent: a
        }
      }, {
        children: s
      }))
    }));
  }),
  Te = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref3) {
    var s = _ref3.defaultValue,
      a = _ref3.type,
      t = _ref3.borderRadius,
      n = _ref3.outerShadow,
      c = _ref3.paddingRight,
      l = _ref3.paddingLeft,
      r = _ref3.picGap,
      d = _ref3.xGap,
      g = _ref3.paddingTop,
      m = _ref3.paddingBottom,
      h = _ref3.selectImg;
    var _i2 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      p = _i2.View,
      b = _i2.Image,
      u = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useCube)(s, h);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
      style: {
        paddingTop: g,
        paddingBottom: m,
        paddingLeft: d,
        paddingRight: d
      }
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
        className: "cube-type".concat(a),
        style: {
          paddingLeft: l,
          paddingRight: c,
          gap: r
        }
      }, {
        children: u.map(function (s, i) {
          return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, {
            className: "block " + (n ? "outer-shadow" : ""),
            mode: 1 === a ? "widthFix" : "scaleToFill",
            src: s.imgUrl,
            style: {
              width: "100%",
              borderRadius: t + "px"
            },
            onClick: function onClick() {
              var e, a;
              return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)(null === (e = s.link) || void 0 === e ? void 0 : e.value, null === (a = s.link) || void 0 === a ? void 0 : a.params);
            }
          }, i);
        })
      }))
    }));
  }),
  Le = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref4) {
    var s = _ref4.url,
      a = _ref4.poster,
      t = _ref4.autoplay,
      n = _ref4.loop,
      c = _ref4.paddingTop,
      l = _ref4.paddingBottom,
      o = _ref4.paddingLeft,
      r = _ref4.paddingRight;
    var _i3 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      d = _i3.View;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
      style: {
        paddingTop: c,
        paddingBottom: l
      }
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("video", {
        className: "components-video",
        src: s,
        poster: a,
        autoPlay: t,
        loop: n,
        controls: !0,
        "object-fit": "contain",
        style: {
          width: "100%",
          height: "240px",
          paddingLeft: o,
          paddingRight: r
        }
      })
    }));
  }),
  Pe = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref5) {
    var s = _ref5.width,
      a = _ref5.height,
      t = _ref5.top,
      n = _ref5.right,
      c = _ref5.bottom,
      l = _ref5.left,
      o = _ref5.borderRadius;
    var _i4 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      r = _i4.View;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, {
      style: {
        width: s,
        height: a,
        borderRadius: o,
        top: t,
        left: l,
        right: n,
        bottom: c
      },
      className: "components-service"
    });
  }),
  Re = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAAAXNSR0IArs4c6QAADcdJREFUeF7tnQXMZUcVx38FihUvbkGCu7sVDVYo7lLctUhwd1JcUiw4FCgeXIMU1+LuUtwtP3Ze2C673zvn3pkr37sn2WzTPTNv5sz/jhzdi4U2WgJ7bfTsl8mzAGDDQbAAYAHAhktgw6e/7AALADZcAhs+/WUHWACw4RLY8OkvO8ACgG0jgb2BMwHnKH+fCNgHOB7gfwv2vwF/BI4E/gD8Cvg68DXgh9tGEomJzHkHOCewH3B54LzAGYFjJOa+K6uAEAifAt4HfAD4eY/+ZtF0TgA4FnBN4ICy8KdsLOF/A18C3g28Gji88e+N0v0cAHAh4JbATYCTjSKlHT96BPAa4GXAt0ccR9WfnioAjg7cGHgQcK6qM+7f2b+Aw4DHleOif48j9jA1AHiR80t/MHC2EeUS/emPAg8H3httMDW+KQHg2sDBwBmmJqTAeN4B3B34VoB3UixTAMBpgMcDt5iUZPKD8Yn5dOARwF/yzcdpMSYA/O37FYEdd5zpN/nVbwIHAh9q0nvlTscCwEmBlwJXrzyfqXT3T+AxwKMAL42TpTEAcFnglYBb/3an9wM3BX461YkODYC7lXOyj8Zud7L0i/s88Nmi2lW965/f7aT6td0xi3r4xMC+wFmBs5cXx8WA0zdYqB8D1wA+16Dv3l0OCYBHAw/pPeL/daDu/g3lCeZ5+5sKfZ8ZuAJwZeBawHEq9GkXvwWuU9TLlbqs080QAFCp8xzgDhWGrCHn0KKNc3tteb6eALheeZ1ob+grq78CNyvjryCKOl30ndS6Ubj4nvc3XMe45t+13j0TeEax4PXsLt1cY5PKqesDzqkreVTdtgC4ax9V27UGwPOAO/YYsV+8KlcX//c9+qnV1DuDR1kfQP8DuC7w1lqD6tNPSwD4BHpoj8EpIC+N3+vRR6umHgnPBjRJd6E/A1cBPtKlcc02rQBwlyKgLmP9RdkmJ/GFbDEBXxTaAR4IHK3DRH8NXAb4Soe21Zq0AIDPqQ8DGnay5G3ed/OPsg1H5PfV8ArgVB3G8A1Ac/dox1ttAPi29i1+ug7CeFK5aHlRmhu5+L5OLtFh4C8f0w5SEwD29UZg/6QQ9Lw5CHhKst3U2LVnvLYofbJjux1wSLZRDf6aALhX0fJlxvV34NblqZhpN1VeNZwupB5MGfJSeMHidZRp15u3FgBOC3y1eOBGB+WX75v4JdEGM+FTphq6suZt7z++LpTLYFQLAK8vWrPMwO8LPC3TYEa8XoDfAlw1OWYvwK9KtunFXgMAVwP0iMmQ5/39Mw1myHv88s5XixilnxTjlEasQagvADzzfMeeJTFalR8+ndSIbXdSc2icgWCI0lOLo0yUvxdfXwB42fG8i5LKDy87U9TuReeQ5btRiSuItvtTCXIZJCilDwDUfhk4YShWlNSBvynKvI34jCXIXAqfUFzim4ugDwC0jL0uMcI3d9ARJLqfNKsKMsPO/DtC3gH0jtYK2pT6AMCzTTVmhNzWDPD4boR5m/LcufhFRKenIU2/wqbUFQAXAD6TGNkji/dvosm2Y9WP4NPA+YIz82Mx2rmpXqArAHy/3zs4kcG2s+B4xmS7QVEXR8dwudbu5V0A4NPvB0A0OtegD71pFtphNv5CIt5RtbJ2gmbUBQB6uEZt9UbIeJn5WbMZzK/jWyXU3+6efmjaCppQFwC8MIFKw6mN8l3ofxI4NqDGz6wlETInwtsijF14ugDAAEgvJxFqOvjIACbK49auISxC3re0mzShLAAMnIhq8dRkaSXU5LvQUSWg1U+39ggZUOKrqwllAXAb4EXBkXhU1IgFCP7crNi8DBouFsl4YuzDKYBftphhFgDq/aPODiZ6MLfOQruXgN5DPgsjZICKUVDVKQsAlT+R7UjlxamnHBRZXZL5DjOaQb2PdbOvThkAyOuzxLx760jvoK4+8+v63i7/blCqcoqQTiI6i1SnDAC80KkAipBbv0fAQnuWgPcAI598Fq4jVcgXXsfU5d8zALhSyZkX+Z1F9x+REnwROHeA1SSWBqtWtwtkAHB74AWBwcpiFKxBoQttLQHN6ZrVI6RGsLpGNQMA8/k8OTJS4OLAJ4K8m8z2xBITEZGBafNMelGVMgBwW39Y8Ne94OgAsdDWEjARptHPEdL3ImOCj/SZSnqQMQF7YZxTfF9IWA2YjH429D1Cag8/GGHM8GR2gIwR6ITlyZgZyybyZiyDJtI01qAqZQCQ0QIaJ9fMhFlVAuN25lM5ellWa2gATlXKAMCECMb9R8g8gBZjWGhrCWReVuZUzAbgrJV/BgC6Kj9gbY87GCzesMkOoEExcR/AQJAINXEPywDAFG/mx4mQ4VAqORbaWgLq+M0tHKHRXwH3KNm8I4M1z957IowbzmP6PI1CETLMzIwiVSmzA2QuLD5vvDMstLUE/EiuGBCSPgFerM01WJUyAHALMhgkQubzu2eEccN5zHYayZksX5e0O2vFmwGAZmDNwZE27+oQG792sNuMISNPk26ZZLs6RRZz5x+NIta8vT4F55jwqbqQ99ChW3/0nvTihBNpavxZAETPLAeh/Vo79kK7l8BjEwEzd03GFYZlngWAUT4mRoyQGUDmnvkrMs+uPB8rVtNIe93wmqSbzwLA553ne4QsuGg61IX+XwInKbb9SN0EvYYMImmSUSULAJ8iZvmwiuc68vz35moUzEJHlcCdgOcGhWIZ28hTMdjdUdmyALC1JsnojXQ7ZwLrJPDSyHqDlwx2oLrYamRNqAsAMiphy7icv8nI59upVUnU6EVlL3+zUrXRQews7uwEzAhmJe6FdkhAJZlFJiPU/APqAgAHbqq3S0VmUN66Xh4X2hHi9Z1ELSJd8KIGuE7y7QoAq4BYDSRKnnc+ezadMiZ1b/3mVmjqWtcVAJZdsxxaJKjBRbe4snEFm0zZfMpmXj+gtcC6AsBxZXwE5TdRhAkjNpUyMQDKSB2KupSm1AcAXgaPACLKDCfhjqG7+GjVMZpKcuvOMwo0ezKPkK+n6pFAuw6zDwDsy2oXRgFFyciiPlXEor8zJT49pLWJ+MFEya3fI6A59QWAaWJNF5spmnTzUmOn+eQm8gPWE8pE9lpyR9+L5l+/8ukLAPvIuIvLr0+BlsLq7k0TWfCdh5HJAbBqZ8naaBa23lOuAQDftt4FolmvHLQp5i2Zpl1hu5IKMN24I3aTlQzMBmZircGoBgAcrPbqZyVH/UlgvxIjn2w6efbzlAyfmY/CQBpDxZupfXcntVoAMA/uxzskMXCrM//N3ya/pPEBetnThStbR9BAURVFg1ItADhoUW9IeLbkum9db70mQZg7+XRz24+m0V3N149HC+vgKfVqAsDJmBbu+R1WUW9jU9AOUiWjw/giTYzetRiGz74M/bYk3tJGMDjVBoATyD57VpP27LMq9xz9CI2ZNHw+c+Fbzds5ZwpvVAVJCwBYIOlwwIwWWTLwwUwk2Qtl9ndq8Zu3R5V413LyHnvWWh6tgHQLAChccwnr9ZI9C1cLY3kZbebfr7VSDfpRvatbV0bDt7thmPfH19AoIGgFACfqpVD3MS2HXcgyM+Yk0hO5ekhUlwGVNt7uze2TKQK17ue8++j3p1Z1UGoJACfixeidHc/GlSDUGAoC7Q6D35J3Wo2Tw3/DudV5RJJlZhdylJ2gNQAUgrd78+LqUdyHzFJuiXmBMFhlzbLFGxlt5Y6+c1g3/8FBMAQAnLQXHZU+hov1JauQGKFkLT6fXS12BTV45uRxm3drHkpOymbQ42DIianm9DiIRMNGQeIb2qrb+s77x9y7XQDhy0WQqr/3QqaxKurnEB1rhm+wnWBIACgAC06Y6OgiGWkkeF189Qkap/xbY5NPLf8YYeNCq6jxDPdMN+mCz9WaoNx1uDrAZGoHr9oPAoKhAeDk/LIsiHjQwFtrAkdVWL2n6PyiYsvqIF1A1vw4GAMAK+nuDxj23PWZWGWVGnWiIsyMKtZXkqyuPkkQjAkABWPs4MGARaW3A6m7MKWuauFdgzk9arynWEgjS82Og7EBsBKEFy9zCuk0OlfylaP2cqv0eJPbCaYCABddM7J2AEvSzulYMIGzETzR2n5ePD0OJrETTAkAqy/fG/qBJSll1qliyN3jy2W791WTdeCczE4wRQCsFnGfon0znaql56dAnuuHlbA4o52yC7/zHCaxE0wZADsLSzdptXLerH2/D026ah9aXi0GuNSi0UEwFwCsBL43cOmirfPieNFGGjuVN7ppebHzi49WS+0CjFFBMDcA7Cpg7wsCwtzECtJXhH/2Da6EW7qp79Qa+mbXNc0oZm3zQ6a4Gw0EcwfAntZZ1auGJwGy+uP/UzunWlgX7CNL/qIutoMgvlJso4BguwIgJfkJMQ/+OlgAMKHVL0PpsxOYkU1DWzipxAKA6QHAEfXZCVLhZQsApgmAviDQKTcUZ7AAYLoA6AMCjWt6S62lBQBrRTQ6Q5fjQD/Mt0dGvgAgIqXxeTIgMNBWQ1OoatsCgPEXNzqCKAhM3xetQzSot2t0ogvfniUgCDRC7al8jO5nxmKEI62XHWB+cDMji84zhtSv1s/IqUOKCT28+E59AcD8ALAasU6mFpLwzNeG0SndzgKA+QKgysgXAFQR43w7WQAw37WrMvIFAFXEON9OFgDMd+2qjHwBQBUxzreTBQDzXbsqI18AUEWM8+1kAcB8167KyBcAVBHjfDv5D+vIKZ/vdzjHAAAAAElFTkSuQmCC",
  ze = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAGCAYAAADQQP5pAAAAAXNSR0IArs4c6QAAAMhJREFUKFPFUjFqQkEUfLOmeAoWJodI7qE3sFdrS4sPCykexPA/C7baqr030Hskh1ALQbfJTviBSFiszZQz82bgMTCzhxjjq4iMATRJblR1YmYHyWBmrRhjSXJQSwDWqurN7Jx7vfdPJGcA+iRrfaGqU3jv30jWhVcA2JVl2bsRsiQ5zPhVVVWjG94tyW6W+1O4J/mYH6SUXkIIn798URRt59xRRBqZ9yul1AkhnP54n51zH3kmgMO/FN7tpSLyjjuN5iIi83o039P9n5mWDu/PAAAAAElFTkSuQmCC\n",
  Me = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref6) {
    var a = _ref6.value,
      t = _ref6.iconShow,
      n = _ref6.fontColor,
      c = _ref6.backgroundColor,
      l = _ref6.borderRadius,
      o = _ref6.paddingLeft,
      r = _ref6.paddingRight,
      d = _ref6.sticky,
      g = _ref6.fontsize,
      m = _ref6.paddings,
      _ref6$otherStyles = _ref6.otherStyles,
      h = _ref6$otherStyles === void 0 ? [] : _ref6$otherStyles;
    var _i5 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      p = _i5.View,
      b = _i5.Image,
      u = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(function () {
        return classnames__WEBPACK_IMPORTED_MODULE_4___default().apply(void 0, ["txt"].concat((0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_11__["default"])(h)));
      }, [h]);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
      onClick: function onClick() {
        return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("search");
      },
      style: {
        paddingTop: m,
        paddingBottom: m,
        paddingLeft: o,
        paddingRight: r
      },
      className: d ? "boxpositon" : ""
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
        className: "components-search",
        style: {
          backgroundColor: c,
          borderRadius: l ? "20px" : "",
          height: "32px",
          lineHeight: "32px",
          width: "100%",
          display: "inline-block",
          textAlign: "center"
        }
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, {
          src: Re,
          alt: "",
          style: {
            height: "16px",
            width: "16px",
            display: t ? "inline-block" : "none",
            verticalAlign: "top",
            marginTop: "8px",
            marginRight: "10px"
          }
        }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
          className: u,
          style: {
            color: n,
            display: "inline-block",
            fontSize: g
          }
        }, {
          children: a
        }))]
      }))
    }));
  }),
  Fe = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref7) {
    var a = _ref7.value,
      t = _ref7.iconShow,
      n = _ref7.fontColor,
      c = _ref7.backgroundColor,
      l = _ref7.borderRadius,
      o = _ref7.paddingLeft,
      r = _ref7.paddingRight,
      d = _ref7.sticky,
      g = _ref7.fontsize,
      m = _ref7.paddings,
      _ref7$otherStyles = _ref7.otherStyles,
      h = _ref7$otherStyles === void 0 ? ["mockWeight", "mockItalic"] : _ref7$otherStyles;
    var _i6 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      p = _i6.View,
      b = _i6.Image,
      u = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(function () {
        return classnames__WEBPACK_IMPORTED_MODULE_4___default().apply(void 0, ["txt"].concat((0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_11__["default"])(h)));
      }, [h]);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
      onClick: function onClick() {
        return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("search");
      },
      style: {
        paddingTop: m,
        paddingBottom: m,
        paddingLeft: o,
        paddingRight: r
      },
      className: d ? "boxPosition" : ""
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
        className: "components-search",
        style: {
          border: "1px solid ".concat(c),
          borderRadius: l ? "20px" : "",
          height: "32px",
          lineHeight: "32px",
          width: "100%",
          display: "flex",
          textAlign: "center",
          backgroundColor: "#ffffff"
        }
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
          style: {
            width: "80%"
          }
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, {
            src: Re,
            alt: "",
            style: {
              height: "16px",
              width: "16px",
              display: t ? "inline-block" : "none",
              verticalAlign: "top",
              marginTop: "8px",
              marginRight: "10px"
            }
          }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
            className: u,
            style: {
              color: n,
              display: "inline-block",
              fontSize: g
            }
          }, {
            children: a
          }))]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
          className: ["seachBtn", l ? "btnBorderRadius" : ""].join(" "),
          style: {
            fontSize: g,
            backgroundColor: c,
            width: "20%",
            color: n
          }
        }, {
          children: "搜索"
        }))]
      }))
    }));
  }),
  We = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref8) {
    var s = _ref8.item,
      a = _ref8.position,
      t = _ref8.direction;
    var n, c;
    var _i7 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      l = _i7.Image,
      o = _i7.View;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, {
      mode: "scaleToFill",
      src: s.imgUrl,
      style: {
        width: "100%",
        height: "100%",
        paddingBottom: "top" === a && "vertical" === t ? "30px" : "",
        marginTop: "top" === a && "horizontal" === t ? "30px" : ""
      },
      onClick: _brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler.bind(null, null === (n = s.link) || void 0 === n ? void 0 : n.value, null === (c = s.link) || void 0 === c ? void 0 : c.params)
    });
  }),
  Ge = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref9) {
    var t = _ref9.Position,
      _ref9$className = _ref9.className,
      n = _ref9$className === void 0 ? "" : _ref9$className,
      _ref9$className2 = _ref9.className1,
      c = _ref9$className2 === void 0 ? "" : _ref9$className2,
      _ref9$defaultValue = _ref9.defaultValue,
      l = _ref9$defaultValue === void 0 ? [] : _ref9$defaultValue,
      r = _ref9.type,
      d = _ref9.autoplay,
      g = _ref9.autoplayInterval,
      m = _ref9.direction,
      h = _ref9.loop,
      p = _ref9.paddingTop,
      b = _ref9.paddingBottom,
      u = _ref9.paddingLeft,
      N = _ref9.paddingRight,
      O = _ref9.selectImg,
      j = _ref9.imgHeight,
      _ref9$fontsize = _ref9.fontsize,
      C = _ref9$fontsize === void 0 ? 16 : _ref9$fontsize,
      _ref9$textAlign = _ref9.textAlign,
      f = _ref9$textAlign === void 0 ? "center" : _ref9$textAlign,
      _ref9$fontColor = _ref9.fontColor,
      y = _ref9$fontColor === void 0 ? "#000000" : _ref9$fontColor,
      _ref9$backGroundColor = _ref9.backGroundColor,
      x = _ref9$backGroundColor === void 0 ? "#ffffff" : _ref9$backGroundColor;
    var k = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(function () {
        return classnames__WEBPACK_IMPORTED_MODULE_4___default()({
          paddingbtm: "none" !== t,
          imgHeights: "bottom" === t && "horizontal" === m
        });
      }),
      _i8 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      w = _i8.SmoothSwiper,
      v = _i8.View,
      I = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useCube)(l, O || []),
      S = function S(s) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(v, Object.assign({
          className: c,
          style: {
            fontSize: C,
            zIndex: 99,
            justifyContent: "left" === f ? "flex-start" : "center" === f ? "center" : "flex-end",
            color: y,
            backgroundColor: x
          }
        }, {
          children: s.title
        }));
      };
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(v, Object.assign({
      className: n,
      style: {
        paddingTop: p,
        paddingBottom: b,
        paddingLeft: u,
        paddingRight: N
      }
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(w, {
        imgHeight: j,
        data: I,
        className: k,
        type: r,
        autoplay: d,
        autoplayInterval: g,
        direction: m,
        loop: h,
        interval: 5e3,
        vertical: "vertical" === m,
        render: function render(i) {
          return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: ["top" === t || "bottom" === t ? S(i) : null, (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(We, {
              item: i,
              position: t,
              direction: m
            })]
          });
        }
      })
    }));
  }),
  Ee = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref10) {
    var s = _ref10.paddingTop,
      a = _ref10.paddingBottom,
      t = _ref10.paddingLeft,
      n = _ref10.paddingRight,
      _ref10$defaultValue = _ref10.defaultValue,
      c = _ref10$defaultValue === void 0 ? [] : _ref10$defaultValue,
      l = _ref10.type,
      o = _ref10.autoplay,
      r = _ref10.autoplayInterval,
      d = _ref10.direction,
      g = _ref10.loop,
      m = _ref10.selectImg,
      h = _ref10.vertical,
      p = _ref10.imgHeight,
      _ref10$paddingTB = _ref10.paddingTB,
      b = _ref10$paddingTB === void 0 ? 0 : _ref10$paddingTB,
      _ref10$paddingLR = _ref10.paddingLR,
      u = _ref10$paddingLR === void 0 ? 0 : _ref10$paddingLR,
      _ref10$fontsize = _ref10.fontsize,
      N = _ref10$fontsize === void 0 ? 16 : _ref10$fontsize,
      _ref10$textAlign = _ref10.textAlign,
      O = _ref10$textAlign === void 0 ? "center" : _ref10$textAlign,
      _ref10$fontColor = _ref10.fontColor,
      j = _ref10$fontColor === void 0 ? "#000000" : _ref10$fontColor,
      _ref10$backGroundColo = _ref10.backGroundColor,
      C = _ref10$backGroundColo === void 0 ? "#ffffff" : _ref10$backGroundColo,
      _ref10$otherStyles = _ref10.otherStyles,
      f = _ref10$otherStyles === void 0 ? [] : _ref10$otherStyles,
      _ref10$ImgShadow = _ref10.ImgShadow,
      y = _ref10$ImgShadow === void 0 ? !1 : _ref10$ImgShadow,
      _ref10$Position = _ref10.Position,
      x = _ref10$Position === void 0 ? "top" : _ref10$Position;
    var _i9 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      k = _i9.View,
      w = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(function () {
        return classnames__WEBPACK_IMPORTED_MODULE_4___default().apply(void 0, ["silder-title", {
          "silder-tops1": "top" === x && "horizontal" === d,
          "silder-bottoms": "bottom" === x && "horizontal" === d,
          "silder-bottoms1": "vertical" === d && "bottom" === x,
          "silder-tops": "vertical" === d && "top" === x
        }].concat((0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_11__["default"])(f)));
      }, [f, x]);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(k, Object.assign({
      style: {
        padding: "".concat(b, "px ").concat(u, "px")
      }
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Ge, Object.assign({}, {
        Position: x,
        defaultValue: c,
        type: l,
        autoplay: o,
        autoplayInterval: r,
        direction: d,
        loop: g,
        selectImg: m,
        vertical: h,
        imgHeight: p,
        paddingTop: s,
        paddingBottom: a,
        paddingLeft: t,
        paddingRight: n,
        fontsize: N,
        textAlign: O,
        fontColor: j,
        backGroundColor: C
      }, {
        className: classnames__WEBPACK_IMPORTED_MODULE_4___default()({
          "outer-shadow": y
        }),
        className1: w
      }))
    }));
  });
function He(e, s) {
  var a = {};
  for (var t in e) Object.prototype.hasOwnProperty.call(e, t) && s.indexOf(t) < 0 && (a[t] = e[t]);
  if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
    var i = 0;
    for (t = Object.getOwnPropertySymbols(e); i < t.length; i++) s.indexOf(t[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, t[i]) && (a[t[i]] = e[t[i]]);
  }
  return a;
}
function Ye(e, s, a, t) {
  return new (a || (a = Promise))(function (i, n) {
    function c(e) {
      try {
        o(t.next(e));
      } catch (e) {
        n(e);
      }
    }
    function l(e) {
      try {
        o(t.throw(e));
      } catch (e) {
        n(e);
      }
    }
    function o(e) {
      var s;
      e.done ? i(e.value) : (s = e.value, s instanceof a ? s : new a(function (e) {
        e(s);
      })).then(c, l);
    }
    o((t = t.apply(e, s || [])).next());
  });
}
var Ue = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)(),
  Qe = function Qe() {
    var _ne = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]),
      _ne2 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_12__["default"])(_ne, 2),
      e = _ne2[0],
      s = _ne2[1];
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
      Ye(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_13__["default"])().mark(function _callee() {
        var e, _e2;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_13__["default"])().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              e = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getStorage)("service");
              if (!e) {
                _context.next = 5;
                break;
              }
              s(a(e));
              _context.next = 9;
              break;
            case 5:
              _context.next = 7;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_5__.queryOcsconfigList)();
            case 7:
              _e2 = _context.sent;
              s(a(_e2));
            case 9:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }));
    }, []);
    var a = function a(e) {
      var s = [];
      for (var _a2 = 0; _a2 < e.length; _a2++) {
        var _t = e[_a2].ocsOcserviceReDomain;
        s.push("".concat(_t.ocserviceName, ": ").concat(_t.ocserviceRemark));
      }
      return s;
    };
    return {
      servicePopup: function servicePopup() {
        if (!Ue) return;
        (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getTaro)().showActionSheet({
          itemList: e,
          success: function success(e) {
            console.log(e.tapIndex);
          },
          fail: function fail(e) {
            console.log(e.errMsg);
          }
        });
      }
    };
  },
  Ke = function Ke() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
    return e ? "￥ " + +e.toFixed(2) : 0;
  },
  qe = function qe(_ref11) {
    var a = _ref11.dataPic,
      t = _ref11.goodsName,
      n = _ref11.goodsCamount,
      c = _ref11.pricesetNprice,
      l = _ref11.skuName,
      o = _ref11.skuCode;
    var _i10 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      r = _i10.View,
      d = _i10.Image,
      g = _i10.SmoothView,
      m = Ke(c),
      h = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(function () {
        return n ? "x ".concat(n) : "";
      }, [n]);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(r, Object.assign({
      className: "card-item"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, {
        src: a,
        alt: "",
        className: "card-item-img"
      }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(r, Object.assign({
        className: "card-item-info"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(r, Object.assign({
          className: "card-item-info-container"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
            className: "card-item-info-container-title"
          }, {
            children: t
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
            className: "card-item-info-container-price"
          }, {
            children: m
          }))]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(r, Object.assign({
          className: "card-item-info-sub"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
            className: "sku"
          }, {
            children: l
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
            className: "count"
          }, {
            children: h
          }))]
        }))]
      }))]
    }));
  },
  Ze = _brushes_simulate_component__WEBPACK_IMPORTED_MODULE_14__.Button,
  Xe = function Xe(s) {
    var t = s.dataState,
      i = He(s, ["dataState"]);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: ["2", "-1"].includes(t + "") ? null : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)($e, Object.assign({
        dataState: t
      }, i))
    });
  },
  $e = function $e(s) {
    var a = s.dataState,
      t = s.contractAppraise,
      n = s.color,
      c = s.borderColor,
      l = s.btnColor,
      o = s.btnShape,
      d = He(s, ["dataState", "contractAppraise", "color", "borderColor", "btnColor", "btnShape"]);
    var _i11 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      g = _i11.View;
    4 !== a && 4 !== a || 1 === t ? 4 !== a && 4 !== a || 1 !== t || (a = 5) : a = 4;
    var _r = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useOrderOperate)(Object.assign({
        dataState: a
      }, d)),
      m = _r.operateArray,
      h = _r.handlerImpl;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
      className: "btnGroup"
    }, {
      children: m.map(function (s, a) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Ze, Object.assign({
          style: {
            color: n,
            borderColor: c,
            backgroundColor: l
          },
          className: classnames__WEBPACK_IMPORTED_MODULE_4___default()({
            btn: !0,
            white: 0 === a,
            black: 1 === a
          }),
          onClick: function onClick() {
            return h(s.handler);
          },
          shape: o
        }, {
          children: s.name
        }), a);
      })
    }));
  },
  Je = _brushes_simulate_component__WEBPACK_IMPORTED_MODULE_14__.Button;
function _e(_ref12) {
  var a = _ref12.contractBillcode,
    t = _ref12.dataBmoney,
    n = _ref12.dataBnum,
    c = _ref12.goodsList,
    l = _ref12.dataState,
    o = _ref12.contractId,
    r = _ref12.init,
    g = _ref12.contractAppraise,
    m = _ref12.borderRadius,
    h = _ref12.orderSpacing;
  var _i12 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
    p = _i12.View,
    b = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.orderStatusImpl)(l);
  return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
    className: "orderListItem",
    style: {
      borderRadius: m ? 8 : "",
      marginTop: h,
      marginBottom: h
    }
  }, {
    children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
      onClick: function onClick() {
        return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("orderDetail", {
          contractBillcode: a
        });
      }
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
        className: "topInfo"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
          className: "orderNo"
        }, {
          children: ["订单号: ", a, (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Je, Object.assign({
            className: "copy",
            size: "mini",
            fill: "outline"
          }, {
            children: "复制"
          }))]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
          className: "status"
        }, {
          children: b
        }))]
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
        className: "goodsItemWrap"
      }, {
        children: [c.map(function (s) {
          return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(qe, Object.assign({}, s), s.contractGoodsId);
        }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
          className: "allInfo"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
            className: "totalNum"
          }, {
            children: ["共", n, "件商品"]
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
            className: "totalPrice"
          }, {
            children: ["合计 ￥", t]
          }))]
        }))]
      }))]
    })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Xe, {
      init: r,
      contractId: o,
      contractBillcode: a,
      dataState: l,
      contractAppraise: g
    })]
  }));
}
var es = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)(),
  ss = function ss(s) {
    var a = s.bottomHeight,
      t = s.children,
      n = s.id,
      c = s.heightWrap,
      l = He(s, ["bottomHeight", "children", "id", "heightWrap"]);
    var o = function (e) {
        var _ne3 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0),
          _ne4 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_12__["default"])(_ne3, 2),
          s = _ne4[0],
          a = _ne4[1];
        return (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
          if (!(0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)() || !e) return;
          var s = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getTaro)().createSelectorQuery();
          setTimeout(function () {
            s.select("#".concat(e)).boundingClientRect(function (e) {
              if (e) {
                var _s2 = e.top;
                a(_s2);
              }
            }).exec();
          });
        }), s;
      }(n),
      r = function () {
        var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
        return (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(function () {
          if (!(0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)()) return 0;
          var s = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getTaro)(),
            a = s.getStorageSync("safeArea"),
            t = s.getStorageSync("tabBarHeight") || 0;
          return a + (s.getCurrentPages().at(-1).$taroPath.indexOf("pages/") >= 0 ? t : 0) + (e ? +e : 0);
        }, []);
      }(a),
      _i13 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      d = _i13.View,
      g = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(function () {
        if (!es) return n ? {
          height: "100%"
        } : {
          maxHeight: "50vh",
          overflow: "auto"
        };
        if (n) {
          return {
            height: "calc(".concat((0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getTaro)().getSystemInfoSync().windowHeight + "px", " - ").concat(o + r, "px)")
          };
        }
        return {
          maxHeight: "50vh",
          overflow: "auto"
        };
      }, [o, r]);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({}, l, {
      style: Object.assign(Object.assign({}, g), {
        paddingBottom: n ? "" : r
      }),
      id: n
    }, {
      children: t
    }));
  };
var as = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref13) {
    var a = _ref13.item,
      t = _ref13.refreshNum,
      n = _ref13.borderRadius,
      c = _ref13.orderSpacing;
    var _i14 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      l = _i14.View,
      o = _i14.ScrollView,
      r = _i14.Loading,
      _g = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useOrderList)(a, t),
      d = _g.onScroll,
      m = _g.data,
      h = _g.loading,
      p = _g.init;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, Object.assign({
      className: "orderListItemWrap"
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ss, Object.assign({
        id: "orderListItemWrap"
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
          onScroll: d
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(l, {
            children: [m.map(function (e, s) {
              return /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.createElement)(_e, Object.assign({
                init: p
              }, e, {
                key: s,
                borderRadius: n,
                orderSpacing: c
              }));
            }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, {
              children: h ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, {}) : null
            })]
          })
        }))
      }))
    }));
  }),
  ts = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref14) {
    var _ref14$refreshNum = _ref14.refreshNum,
      s = _ref14$refreshNum === void 0 ? 0 : _ref14$refreshNum,
      _ref14$indexId = _ref14.indexId,
      a = _ref14$indexId === void 0 ? 0 : _ref14$indexId,
      _ref14$borderRadius = _ref14.borderRadius,
      t = _ref14$borderRadius === void 0 ? !1 : _ref14$borderRadius,
      _ref14$orderSpacing = _ref14.orderSpacing,
      n = _ref14$orderSpacing === void 0 ? 12 : _ref14$orderSpacing;
    console.log(19, qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.orderStatusList);
    var _i15 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      c = _i15.View,
      l = _i15.Tabs;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
      className: "order-container"
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, {
        defaultIndex: +a,
        tabs: qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.orderStatusList,
        render: function render(a) {
          return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
            className: "orderList"
          }, {
            children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(as, {
              item: a,
              orderSpacing: n,
              refreshNum: s,
              borderRadius: t
            })
          }));
        }
      })
    }));
  }),
  is = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref15) {
    var a = _ref15.contractBillcode,
      t = _ref15.expressWay,
      n = _ref15.backgroundColor,
      c = _ref15.color,
      l = _ref15.paddingBottom,
      o = _ref15.paddingTop,
      r = _ref15.borderColor,
      g = _ref15.btnColor,
      m = _ref15.btnShape;
    console.log(333, a);
    var _i16 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      p = _i16.View,
      b = _i16.Text,
      _h = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useOrderDetail)(a || ""),
      u = _h.orderDetail;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
      className: "orderDetail"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
        style: {
          backgroundColor: n
        },
        className: "orderDetailTopTitle"
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
          className: "orderDetailTopTitleContent"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, Object.assign({
            className: "title"
          }, {
            children: (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.orderStatusImpl)(u.dataState)
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, {
            className: "subTitleWrap"
          })]
        }))
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
        className: "orderDetailContent",
        style: {
          paddingTop: o + "px",
          paddingBottom: l + "px"
        }
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
          style: {
            position: "relative",
            top: -26
          }
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
            className: "addressInfo"
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, {
              className: "lPart"
            }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
              className: "mPart"
            }, {
              children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
                className: "personInfo"
              }, {
                children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, Object.assign({
                  className: "personName"
                }, {
                  children: u.goodsReceiptMem
                })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, Object.assign({
                  className: "personPhone"
                }, {
                  children: u.goodsReceiptPhone
                }))]
              })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
                className: "address"
              }, {
                children: u.goodsReceiptArrdess
              }))]
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, {
              className: "rPart"
            })]
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
            className: "orderDetailGoodsWrap"
          }, {
            children: [u.goodsList.map(function (s) {
              return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(qe, Object.assign({}, s), s.contractGoodsId);
            }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
              className: "priceInfo"
            }, {
              children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
                className: "priceInfoFloor top"
              }, {
                children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
                  className: "totalNum"
                }, {
                  children: ["共", u.goodsNum, "件商品"]
                })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
                  className: "totalPrice"
                }, {
                  children: ["合计 ", parseFloat((u.dataBmoney - u.refundMoney).toFixed(2))]
                }))]
              })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
                className: "priceInfoFloor"
              }, {
                children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
                  className: "totalNum"
                }, {
                  children: "商品总额"
                })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
                  className: "totalPrice"
                }, {
                  children: ["合计 ￥", u.contractInmoney]
                }))]
              })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
                className: "priceInfoFloor"
              }, {
                children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
                  className: "totalNum"
                }, {
                  children: "优惠"
                })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
                  className: "totalPrice"
                }, {
                  children: ["合计 ￥", u.goodsPmoney]
                }))]
              }))]
            }))]
          })), t && (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
            className: "express"
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
              className: "label"
            }, {
              children: "配送方式"
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
              className: "name"
            }, {
              children: "快递"
            }))]
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
            className: "orderInfo"
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
              className: "orderInfoItem"
            }, {
              children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
                className: "label"
              }, {
                children: "订单信息"
              }))
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
              className: "orderInfoItem"
            }, {
              children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
                className: "label"
              }, {
                children: "买家留言"
              })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
                className: "name"
              }, {
                children: u.packageRemark
              }))]
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
              className: "orderInfoItem"
            }, {
              children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
                className: "label"
              }, {
                children: "订单编号"
              })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
                className: "name"
              }, {
                children: u.contractBillcode
              }))]
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
              className: "orderInfoItem"
            }, {
              children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
                className: "label"
              }, {
                children: "下单时间"
              })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
                className: "name"
              }, {
                children: u.gmtCreate
              }))]
            }))]
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
            className: "btnGroupFooter"
          }, {
            children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Xe, {
              borderColor: r,
              btnColor: g,
              btnShape: m,
              color: c,
              contractBillcode: u.contractBillcode,
              contractId: u.contractId,
              dataState: u.dataState
            })
          }))]
        }))
      }))]
    }));
  }),
  ns = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref16) {
    var t = _ref16.navList,
      n = _ref16.activeKey,
      _ref16$cell = _ref16.cell,
      c = _ref16$cell === void 0 ? 4 : _ref16$cell;
    var _i17 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      l = _i17.View,
      o = _i17.Text,
      r = _i17.Image;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: t.map(function (a) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, Object.assign({
          className: ["content", n === "".concat(a.goodsClassCode) ? " active" : ""].join("")
        }, {
          children: ((null == a ? void 0 : a.childList) || []).map(function (a) {
            return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(l, Object.assign({
              className: "classifyFloor"
            }, {
              children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(l, Object.assign({
                className: "titleWrap"
              }, {
                children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
                  className: "title"
                }, {
                  children: a.goodsClassName
                })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, {
                  className: "line"
                })]
              })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, Object.assign({
                className: "container container_columns".concat(c)
              }, {
                children: ((null == a ? void 0 : a.childList) || []).map(function (_ref17) {
                  var a = _ref17.classtreeCode,
                    t = _ref17.goodsClassCode,
                    i = _ref17.goodsClassLogo,
                    n = _ref17.goodsClassName;
                  return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(l, Object.assign({
                    onClick: function onClick() {
                      return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("goodList", {
                        classtreeCode: a
                      });
                    },
                    className: "classifyFloorGoodsItem"
                  }, {
                    children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, {
                      src: i,
                      className: "logo"
                    }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, Object.assign({
                      className: "title"
                    }, {
                      children: n
                    }))]
                  }), t);
                })
              }))]
            }), a.goodsClassCode);
          })
        }), a.goodsClassCode);
      })
    });
  }),
  cs = _brushes_simulate_component__WEBPACK_IMPORTED_MODULE_14__.SideBar,
  ls = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref18) {
    var a = _ref18.cell,
      t = _ref18.color,
      n = _ref18.activeTitle,
      c = _ref18.paddingTop,
      l = _ref18.paddingBottom;
    var _i18 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      o = _i18.View,
      r = _i18.ScrollView,
      _p = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoodsClassify)(),
      d = _p.activeKey,
      g = _p.setActiveKey,
      m = _p.navList,
      h = _p.flag;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ss, Object.assign({
        id: "goodsClassify"
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(o, Object.assign({
            style: {
              height: h ? "100%" : "667px",
              paddingTop: c,
              paddingBottom: l
            },
            className: "goodsClassifyContainer"
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
              className: "side"
            }, {
              children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(cs, Object.assign({
                activeKey: d,
                onChange: g,
                style: {
                  "--width": "90px",
                  "--background-color": "#f5f5f5"
                }
              }, {
                children: m.map(function (s) {
                  return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(cs.Item, {
                    title: s.goodsClassName,
                    className: 0 === n ? "typeBlock" : "typeNoBlock",
                    style: {
                      color: s.goodsClassCode === d ? t : "#000"
                    }
                  }, s.goodsClassCode);
                })
              }))
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
              className: "main"
            }, {
              children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ns, {
                navList: m,
                activeKey: d,
                cell: a
              })
            }))]
          }))
        })
      }))
    });
  }),
  os = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.createContext)(null),
  rs = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function () {
    var _re = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(os),
      a = _re.navList,
      t = _re.activeKey,
      n = _re.setActiveKey,
      l = _re.setFCoe,
      o = _re.setSCoe,
      r = _re.selectFontColor,
      _i19 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      d = _i19.View,
      g = _i19.ScrollView,
      _ne5 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(!1),
      _ne6 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_12__["default"])(_ne5, 2),
      m = _ne6[0],
      h = _ne6[1],
      p = function p(e, s) {
        n.bind(null, e)(), l("".concat(s)), o("0"), m && h(!1);
      };
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(d, Object.assign({
      className: "goodsClassifyOne-headerPart"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(d, Object.assign({
        className: "goodsClassifyOne-topListWrap"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
          className: "goodsClassifyOne-topList"
        }, {
          children: a.map(function (s, a) {
            return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
              className: ["goodsClassifyOne-topListItem"].join(" "),
              onClick: function onClick() {
                return p(s.goodsClassCode, a);
              },
              style: {
                color: t === "".concat(s.goodsClassCode) ? r : "#000",
                borderColor: t === "".concat(s.goodsClassCode) ? r : "#000"
              }
            }, {
              children: s.goodsClassName
            }), a);
          })
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
          className: "goodsClassifyOne-icon",
          onClick: function onClick() {
            return h(!0);
          }
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.IconMobile, {
            value: "paixusort-jiang"
          })
        }))]
      })), m ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(d, Object.assign({
        className: "goodsClassifyOne-tipWrap"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
          className: "goodsClassifyOne-tipWrap-handleBar"
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
            className: "goodsClassifyOne-icon",
            onClick: function onClick() {
              return h(!1);
            }
          }, {
            children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.IconMobile, {
              value: "paixusort-sheng"
            })
          }))
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ss, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, {
            children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
              className: "goodsClassifyOne-tipWrapItemWrap"
            }, {
              children: a.map(function (s, a) {
                return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
                  class: ["goodsClassifyOne-tipWrapItem"].join(""),
                  onClick: function onClick() {
                    return p(s.goodsClassCode, a);
                  },
                  style: {
                    color: t === "".concat(s.goodsClassCode) ? r : "#000",
                    borderColor: t === "".concat(s.goodsClassCode) ? r : "#000"
                  }
                }, {
                  children: s.goodsClassName
                }), a);
              })
            }))
          })
        })]
      })) : null]
    }));
  }),
  ds = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref19) {
    var a = _ref19.thirdList;
    var _i20 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      t = _i20.View,
      n = _i20.Image,
      _re2 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(os),
      c = _re2.picShadow,
      l = _re2.layout;
    return console.log(9, a), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
      className: "goodsClassifyOneFloor",
      style: {
        gridTemplateColumns: "repeat(".concat(l, ", 1fr)")
      }
    }, {
      children: a.map(function (a, i) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
          className: "goodsClassifyOneFloorItem",
          onClick: function onClick() {
            return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("goodList", {
              classtreeCode: a.classtreeCode
            });
          }
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, {
            src: a.goodsClassLogo,
            className: "pic",
            style: {
              boxShadow: c ? "#DDDDDD 0px 0px 10px" : ""
            }
          }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
            className: "title"
          }, {
            children: a.goodsClassName
          }))]
        }), i);
      })
    }));
  }),
  gs = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)(),
  ms = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function () {
    var _re3 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(os),
      a = _re3.navList,
      t = _re3.fCoe,
      n = _re3.sCoe,
      c = _re3.setSCoe,
      l = _re3.selectFontColor,
      o = _re3.selectBlcShow,
      r = _re3.selectBlcStyle,
      _ref20 = function (_ref21) {
        var e = _ref21.navList,
          s = _ref21.fCoe,
          a = _ref21.sCoe;
        var t = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(function () {
            var a;
            return (null === (a = e[s]) || void 0 === a ? void 0 : a.childList) || [];
          }, [s, e]),
          i = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(function () {
            var e;
            return (null === (e = t[a]) || void 0 === e ? void 0 : e.childList) || [];
          }, [a, s, e]);
        return {
          secondList: t,
          thirdList: i
        };
      }({
        navList: a,
        fCoe: t,
        sCoe: n
      }),
      d = _ref20.secondList,
      g = _ref20.thirdList,
      _i21 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      m = _i21.View,
      h = _i21.ScrollView,
      p = _i21.SideBar;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(m, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ss, Object.assign({
        id: "goodsClassifyOneContent"
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(h, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(m, Object.assign({
            className: "goodsClassifyOneContent",
            style: {
              height: gs ? "100%" : "667px"
            }
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
              activeKey: n,
              onChange: c
            }, {
              children: d.map(function (s, a) {
                return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p.Item, {
                  title: s.goodsClassName,
                  className: [o ? "" : "goodsClassifyOneFloorNoBlc", 1 === r ? "" : "goodsClassifyOneFloorNoRound"].join(" "),
                  style: {
                    "adm-side-bar-item-active": l,
                    "--adm-color-primary": l
                  }
                }, a);
              })
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ds, {
              thirdList: g
            })]
          }))
        })
      }))
    });
  }),
  hs = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref22) {
    var a = _ref22.selectFontColor,
      t = _ref22.selectBlcColor,
      n = _ref22.selectBlcShow,
      c = _ref22.selectBlc,
      l = _ref22.selectBlcStyle,
      o = _ref22.picShadow,
      r = _ref22.layout;
    var _i22 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      d = _i22.View,
      _p2 = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoodsClassify)(),
      g = _p2.navList,
      m = _p2.activeKey,
      h = _p2.setActiveKey,
      _ne7 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("0"),
      _ne8 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_12__["default"])(_ne7, 2),
      b = _ne8[0],
      u = _ne8[1],
      _ne9 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("0"),
      _ne10 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_12__["default"])(_ne9, 2),
      N = _ne10[0],
      O = _ne10[1];
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(os.Provider, Object.assign({
      value: {
        fCoe: b,
        setFCoe: u,
        sCoe: N,
        setSCoe: O,
        navList: g,
        activeKey: m,
        setActiveKey: h,
        selectFontColor: a,
        selectBlcColor: t,
        selectBlcShow: n,
        selectBlc: c,
        selectBlcStyle: l,
        picShadow: o,
        layout: r
      }
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(d, Object.assign({
        className: "goodsClassifyOne"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(rs, {}), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ms, {})]
      }))
    }));
  }),
  ps = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref23) {
    var a = _ref23.childList,
      t = _ref23.layout,
      n = _ref23.picShadow;
    var _i23 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      c = _i23.View,
      l = _i23.Image;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
      className: "level3Arr",
      style: {
        gridTemplateColumns: "repeat(".concat(t, ", 1fr)")
      }
    }, {
      children: a.map(function (a, t) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(c, Object.assign({
          className: "level3ArrItem",
          onClick: function onClick() {
            return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("goodList", {
              classtreeCode: a.classtreeCode
            });
          }
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, {
            src: a.goodsClassLogo,
            className: "logo",
            style: {
              boxShadow: n ? "#DDDDDD 0px 0px 10px" : ""
            }
          }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
            className: "title"
          }, {
            children: a.goodsClassName
          }))]
        }), t);
      })
    }));
  }),
  bs = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref24) {
    var a = _ref24.navList,
      t = _ref24.activeKey,
      n = _ref24.layout,
      c = _ref24.picShadow;
    var l;
    var _ne11 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0),
      _ne12 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_12__["default"])(_ne11, 2),
      o = _ne12[0],
      r = _ne12[1];
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
      r(a.findIndex(d));
    }, [t, o]);
    var d = function d(e) {
        return e.goodsClassCode === t;
      },
      _i24 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      g = _i24.View,
      m = _i24.Image;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(g, Object.assign({
      className: "goodsClassifyTwoContent"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(m, {
        className: "firstLevelImg",
        src: (0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(a[o], "goodsClassLogo"),
        mode: "widthFix"
      }), null === (l = (0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(a[o], "childList")) || void 0 === l ? void 0 : l.map(function (a, t) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(g, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
            className: "level2Title"
          }, {
            children: a.goodsClassName
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ps, {
            childList: a.childList,
            layout: n,
            picShadow: c
          })]
        }, t);
      })]
    }));
  }),
  us = _brushes_simulate_component__WEBPACK_IMPORTED_MODULE_14__.SideBar,
  Ns = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref25) {
    var a = _ref25.selectFontColor,
      t = _ref25.selectBlcShow,
      n = _ref25.selectBlcColor,
      c = _ref25.selectBlcStyle,
      l = _ref25.layout,
      o = _ref25.picShadow;
    var _i25 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      r = _i25.View,
      _p3 = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoodsClassify)(),
      d = _p3.activeKey,
      g = _p3.setActiveKey,
      m = _p3.navList,
      h = _p3.flag;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
      className: "goodsClassifyTwo"
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ss, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(r, Object.assign({
          className: "goodsClassifyTwoWrap",
          style: {
            height: h ? "100%" : "667px"
          }
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
            className: "side"
          }, {
            children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(us, Object.assign({
              activeKey: d,
              onChange: g,
              style: {
                "--width": "88px",
                "--background-color": "#f5f5f5"
              }
            }, {
              children: m.map(function (s) {
                return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(us.Item, {
                  title: s.goodsClassName,
                  className: [t ? "" : "goodsClassifyTwoFloorNoBlc", 1 === c ? "" : "goodsClassifyTwoFloorNoRound"].join(" "),
                  style: {
                    "--adm-color-primary": a
                  }
                }, s.goodsClassCode);
              })
            }))
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
            className: "main"
          }, {
            children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(bs, {
              navList: m,
              activeKey: d,
              layout: l,
              picShadow: o
            })
          }))]
        }))
      })
    }));
  }),
  Os = function Os(_ref26) {
    var _ref26$className = _ref26.className,
      s = _ref26$className === void 0 ? "iconfont" : _ref26$className,
      _ref26$prefixClass = _ref26.prefixClass,
      a = _ref26$prefixClass === void 0 ? "icon" : _ref26$prefixClass,
      _ref26$onClick = _ref26.onClick,
      t = _ref26$onClick === void 0 ? function () {} : _ref26$onClick,
      _ref26$style = _ref26.style,
      n = _ref26$style === void 0 ? {
        fontSize: 16,
        color: "#444",
        fontWeight: 900
      } : _ref26$style,
      c = _ref26.value;
    var _i26 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      l = _i26.Text;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, {
      onClick: t,
      className: classnames__WEBPACK_IMPORTED_MODULE_4___default()(a, c ? "".concat(a, "-").concat(c) : "", s),
      style: n
    });
  },
  js = [{
    name: "默认",
    sortField: "pricesetNprice"
  }, {
    name: "新品",
    sortField: ""
  }, {
    name: "销量",
    sortField: "goodsSalesvolume",
    order: "asc"
  }, {
    name: "价格",
    sortField: "pricesetNprice",
    order: "asc"
  }],
  Cs = function Cs(_ref27) {
    var a = _ref27.setParams,
      t = _ref27.activeColor;
    var _i27 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      n = _i27.View,
      _ne13 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0),
      _ne14 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_12__["default"])(_ne13, 2),
      c = _ne14[0],
      l = _ne14[1],
      _ne15 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(js),
      _ne16 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_12__["default"])(_ne15, 2),
      o = _ne16[0],
      r = _ne16[1];
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
      className: "sortWrap"
    }, {
      children: o.map(function (_ref28, g) {
        var i = _ref28.order,
          o = _ref28.sortField,
          d = _ref28.name;
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(n, Object.assign({
          className: "sortItem " + (c === g ? "active" : ""),
          onClick: function onClick() {
            return function (e, s, t) {
              console.log(78944, e, s, t), l(s), t && r(function (e) {
                return e[s].order = "asc" === t ? "desc" : "asc", (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_11__["default"])(e);
              }), a({
                sortField: e,
                order: t
              });
            }(o, g, i);
          },
          style: {
            color: c === g ? t : ""
          }
        }, {
          children: [d, i && (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Os, {
            style: {
              color: c === g ? t : "#444",
              fontSize: 20
            },
            value: "desc" === i ? "jiangxu" : "shengxu"
          })]
        }), g);
      })
    }));
  },
  fs = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref29) {
    var _ref29$classtreeCode = _ref29.classtreeCode,
      a = _ref29$classtreeCode === void 0 ? "" : _ref29$classtreeCode,
      _ref29$searchParam = _ref29.searchParam,
      t = _ref29$searchParam === void 0 ? "" : _ref29$searchParam,
      _ref29$activeColor = _ref29.activeColor,
      n = _ref29$activeColor === void 0 ? "#e54e29" : _ref29$activeColor,
      _ref29$goodsName = _ref29.goodsName,
      c = _ref29$goodsName === void 0 ? !0 : _ref29$goodsName,
      _ref29$goodsPrice = _ref29.goodsPrice,
      l = _ref29$goodsPrice === void 0 ? !0 : _ref29$goodsPrice,
      _ref29$lineationGoods = _ref29.lineationGoods,
      o = _ref29$lineationGoods === void 0 ? !0 : _ref29$lineationGoods,
      _ref29$salesQuantity = _ref29.salesQuantity,
      r = _ref29$salesQuantity === void 0 ? !0 : _ref29$salesQuantity,
      _ref29$goodsCar = _ref29.goodsCar,
      d = _ref29$goodsCar === void 0 ? !0 : _ref29$goodsCar,
      _ref29$borderRadius = _ref29.borderRadius,
      g = _ref29$borderRadius === void 0 ? !0 : _ref29$borderRadius,
      _ref29$goodsColor = _ref29.goodsColor,
      m = _ref29$goodsColor === void 0 ? !0 : _ref29$goodsColor,
      _ref29$goodsGap = _ref29.goodsGap,
      h = _ref29$goodsGap === void 0 ? 10 : _ref29$goodsGap,
      _ref29$paddingLR = _ref29.paddingLR,
      p = _ref29$paddingLR === void 0 ? 0 : _ref29$paddingLR;
    var _i28 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      u = _i28.View,
      N = _i28.Loading,
      O = _i28.SmoothView,
      j = _i28.Image,
      C = _i28.ScrollView,
      _ne17 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({}),
      _ne18 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_12__["default"])(_ne17, 2),
      f = _ne18[0],
      y = _ne18[1],
      _b = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoodsList)(a, t, f),
      x = _b.loading,
      k = _b.getData,
      w = _b.list,
      v = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(function () {
        return classnames__WEBPACK_IMPORTED_MODULE_4___default()("textBox", {
          btm: !l && !o
        });
      }, [l, o]),
      I = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(function () {
        return classnames__WEBPACK_IMPORTED_MODULE_4___default()("mgrf", {
          boxNone: !r
        });
      }, [r]),
      S = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(function () {
        return classnames__WEBPACK_IMPORTED_MODULE_4___default()("goodDetail", {
          boxNone: !l && !o && !d
        });
      }, [l, o, d]);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(u, Object.assign({
      className: "goodsList"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(u, Object.assign({
        className: "top-info"
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Cs, {
          setParams: y,
          activeColor: n
        })
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(u, Object.assign({
        className: "listWrap",
        style: {
          padding: " 0px ".concat(p, "px")
        }
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ss, Object.assign({
          id: "listWrap"
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(C, Object.assign({
            onScroll: function onScroll() {
              return k(f);
            }
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(u, Object.assign({
              className: "list",
              style: {
                gap: h
              }
            }, {
              children: w.map(function (a) {
                return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(u, Object.assign({
                  onClick: function onClick() {
                    return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("goodDetail", {
                      skuCode: a.skuCode
                    });
                  },
                  className: "listItem",
                  style: {
                    borderRadius: g ? "8px" : "",
                    boxShadow: m ? "4px 4px 4px #969292" : ""
                  }
                }, {
                  children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(j, {
                    src: a.dataPic,
                    className: "img"
                  }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, Object.assign({
                    className: "name",
                    style: {
                      display: c ? "block" : "none"
                    }
                  }, {
                    children: a.goodsName
                  })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(u, Object.assign({
                    className: I
                  }, {
                    children: ["已售：", a.goodsNum]
                  })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(u, Object.assign({
                    className: S
                  }, {
                    children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(u, Object.assign({
                      className: v
                    }, {
                      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, Object.assign({
                        className: "price",
                        style: {
                          display: l ? "block" : "none"
                        }
                      }, {
                        children: Ke(a.pricesetNprice)
                      })), " ", " ", (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(u, Object.assign({
                        className: "decoration",
                        style: {
                          display: o ? "block" : "none"
                        }
                      }, {
                        children: a.pricesetMakeprice
                      }))]
                    })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(u, Object.assign({
                      style: {
                        display: d ? "block" : "none"
                      }
                    }, {
                      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Os, {
                        style: {
                          fontSize: 20,
                          color: "#f00"
                        },
                        value: "cart"
                      })
                    }))]
                  }))]
                }), a.skuCode);
              })
            })), x ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(N, {}) : null]
          }))
        }))
      }))]
    }));
  }),
  ys = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)(),
  xs = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref30) {
    var a = _ref30.placeholder,
      t = _ref30.placeholderText,
      n = _ref30.history,
      c = _ref30.historyText,
      l = _ref30.paddingBottom,
      o = _ref30.paddingTop;
    var _i29 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      r = _i29.View,
      d = _i29.Text,
      g = _i29.Input,
      _ne19 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(function () {
        return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getStorage)("history") || [];
      }),
      _ne20 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_12__["default"])(_ne19, 2),
      m = _ne20[0],
      h = _ne20[1];
    console.log(23, (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getStorage)("history"));
    var p = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.useImmutableCallback)(function (e) {
        return Ye(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_13__["default"])().mark(function _callee2() {
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_13__["default"])().wrap(function _callee2$(_context2) {
            while (1) switch (_context2.prev = _context2.next) {
              case 0:
                ys && (h(function (s) {
                  if ((0,lodash_es__WEBPACK_IMPORTED_MODULE_16__["default"])(e.detail.value)) return s;
                  var a = s.concat(e.detail.value);
                  return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.setStorage)("history", a), a;
                }), b(e.detail.value));
              case 1:
              case "end":
                return _context2.stop();
            }
          }, _callee2);
        }));
      }),
      b = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.useImmutableCallback)(function (e) {
        (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("goodList", {
          searchParam: e
        });
      });
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(r, Object.assign({
      className: "searchPage",
      style: {
        paddingTop: o,
        paddingBottom: l
      }
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(r, Object.assign({
        className: "search-title"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
          src: Re,
          alt: ""
        }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
          "confirm-type": "search",
          type: "text",
          className: "content",
          onConfirm: p
        }, a ? {
          placeholder: t
        } : {})), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
          className: "btn",
          onClick: function onClick() {
            return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorBackImpl)();
          }
        }, {
          children: "取消"
        }))]
      })), n ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(r, Object.assign({
        className: "historyWrap"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(r, Object.assign({
          className: "title"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(r, Object.assign({
            className: "label"
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, {
              className: "icon"
            }), c]
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Os, {
            onClick: function onClick() {
              return Ye(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_13__["default"])().mark(function _callee3() {
                return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_13__["default"])().wrap(function _callee3$(_context3) {
                  while (1) switch (_context3.prev = _context3.next) {
                    case 0:
                      _context3.next = 2;
                      return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getTaro)();
                    case 2:
                      _context3.sent.removeStorageSync("history");
                      h([]);
                    case 4:
                    case "end":
                      return _context3.stop();
                  }
                }, _callee3);
              }));
            },
            value: "shanchu",
            style: {
              fontSize: 18,
              color: "#222",
              lineHeight: "61px",
              cursor: "pointer"
            }
          })]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
          className: "content"
        }, {
          children: m.map(function (s, a) {
            return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
              onClick: function onClick() {
                return b(s);
              },
              className: "historyItem"
            }, {
              children: s
            }), a);
          })
        }))]
      })) : null]
    }));
  }),
  ks = function ks(_ref31) {
    var _ref31$starColor = _ref31.starColor,
      a = _ref31$starColor === void 0 ? "#FF0934" : _ref31$starColor,
      _ref31$starSize = _ref31.starSize,
      t = _ref31$starSize === void 0 ? "12px" : _ref31$starSize,
      c = _ref31.itemData;
    var _i30 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      l = _i30.View,
      o = _i30.Text,
      r = _i30.Image,
      d = _brushes_simulate_component__WEBPACK_IMPORTED_MODULE_14__.Rate;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(l, Object.assign({
      className: "evaluateItem"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(l, Object.assign({
        className: "userInfo"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, {
          src: c.avatar,
          className: "avatar"
        }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(l, Object.assign({
          className: "userNameWrap"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
            className: "userName"
          }, {
            children: c.userName
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, {
            readOnly: !0,
            value: c.rate,
            style: {
              "--star-size": t,
              "--active-color": a
            }
          })]
        }))]
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(l, Object.assign({
        className: "size"
      }, {
        children: ["规格： ", c.size]
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, Object.assign({
        className: "content"
      }, {
        children: c.evaluate
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, Object.assign({
        className: "img-group"
      }, {
        children: c.imgUrls.map(function (s, a) {
          return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, {
            src: s.imgUrl,
            className: "img"
          }, a);
        })
      }))]
    }));
  },
  ws = [{
    avatar: "http://www.qianjiangcloud.com/images/centerimga/pic%EF%BC%8Flogo+@2x.png",
    userName: "张三李四王五",
    rate: 4.5,
    size: "一大通",
    evaluate: "实物与描述的一样，质量相当好，卖家态度也好，有问必答，发货速度杠杠的，值得购买哦。外观设计漂亮，尺寸大小合适，包装仔细完整，宝贝手感不错，感觉很好，发货速度快，服务态度一流，给力！5星好评！",
    imgUrls: [{
      imgUrl: "https://img12.360buyimg.com/n1/jfs/t1/137059/18/27631/76566/635fc607E0b9e9c60/762dac6802e989d3.jpg"
    }, {
      imgUrl: "https://img12.360buyimg.com/n1/jfs/t1/137059/18/27631/76566/635fc607E0b9e9c60/762dac6802e989d3.jpg"
    }, {
      imgUrl: "https://img12.360buyimg.com/n1/jfs/t1/137059/18/27631/76566/635fc607E0b9e9c60/762dac6802e989d3.jpg"
    }, {
      imgUrl: "https://img12.360buyimg.com/n1/jfs/t1/137059/18/27631/76566/635fc607E0b9e9c60/762dac6802e989d3.jpg"
    }]
  }, {
    avatar: "http://www.qianjiangcloud.com/images/centerimga/pic%EF%BC%8Flogo+@2x.png",
    userName: "张三李四王五",
    rate: 4.5,
    size: "一大通",
    evaluate: "实物与描述的一样，质量相当好，卖家态度也好，有问必答，发货速度杠杠的，值得购买哦。外观设计漂亮，尺寸大小合适，包装仔细完整，宝贝手感不错，感觉很好，发货速度快，服务态度一流，给力！5星好评！",
    imgUrls: [{
      imgUrl: "https://img12.360buyimg.com/n1/jfs/t1/137059/18/27631/76566/635fc607E0b9e9c60/762dac6802e989d3.jpg"
    }]
  }],
  vs = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function () {
    var _ne21 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("1"),
      _ne22 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_12__["default"])(_ne21, 2),
      t = _ne22[0],
      n = _ne22[1],
      _i31 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      c = _i31.View,
      l = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)([{
        label: "全部",
        num: "900+",
        index: "1"
      }, {
        label: "好评",
        num: "800+",
        index: "2"
      }, {
        label: "中评",
        num: "99+",
        index: "3"
      }, {
        label: "差评",
        num: "12",
        index: "4"
      }]),
      o = function o(e) {
        n(e);
      };
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
        className: "evaluateListTab"
      }, {
        children: l.current.map(function (e) {
          return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(c, Object.assign({
            className: "evaluateListTabItem " + (e.index === t ? "active" : ""),
            "data-index": e.index,
            onClick: o.bind(null, e.index)
          }, {
            children: [e.label, " ", e.num]
          }), e.index);
        })
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
        className: "evaluateListContent"
      }, {
        children: ws.map(function (s, a) {
          return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ks, {
            itemData: s
          }, a);
        })
      }))]
    });
  }),
  Is = function Is(_ref32) {
    var s = _ref32.onChange,
      _ref32$readOnly = _ref32.readOnly,
      a = _ref32$readOnly === void 0 ? !1 : _ref32$readOnly,
      _ref32$size = _ref32.size,
      t = _ref32$size === void 0 ? 22 : _ref32$size,
      n = _ref32.count;
    var _i32 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      c = _i32.View,
      _ne23 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([{
        icon: "star-fill"
      }, {
        icon: "star"
      }, {
        icon: "star"
      }, {
        icon: "star"
      }, {
        icon: "star"
      }]),
      _ne24 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_12__["default"])(_ne23, 2),
      l = _ne24[0],
      o = _ne24[1];
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
      if (n) {
        var _e3 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_11__["default"])(l);
        for (var _s3 = 0; _s3 < _e3.length; _s3++) _e3[_s3].icon = _s3 > n - 1 ? "star" : "star-fill";
        o(_e3);
      }
    }, []);
    var r = function r(e) {
      if (!a) {
        for (var _s4 = 0; _s4 < l.length; _s4++) l[_s4].icon = _s4 > e ? "star" : "star-fill";
        o((0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_11__["default"])(l)), s(e + 1);
      }
    };
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, {
      children: l.map(function (s, a) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Os, {
          onClick: r.bind(null, a),
          value: s.icon,
          style: {
            color: "#EC6C5C",
            fontSize: t
          }
        }, a);
      })
    });
  },
  Ss = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref33) {
    var a = _ref33.code,
      t = _ref33.borderRadius,
      c = _ref33.borderColor,
      l = _ref33.color,
      o = _ref33.buttonColor,
      r = _ref33.buttonBorderRadius,
      d = _ref33.paddingTop,
      g = _ref33.paddingBottom;
    var _u = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useEvaluateDetail)(a),
      m = _u.orderInfo,
      h = _u.changeStar,
      p = _u.Submit,
      b = _u.changeContent,
      N = _brushes_simulate_component__WEBPACK_IMPORTED_MODULE_14__.Button,
      _i33 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      O = _i33.View,
      j = _i33.Image,
      C = _i33.TextArea,
      f = _i33.Textarea,
      y = C || f,
      x = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)("宝贝满足你吗？分享一下它吧");
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(O, Object.assign({
      className: "evaluateDetail",
      style: {
        paddingTop: d,
        paddingBottom: g
      }
    }, {
      children: [m.map(function (a, i) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(O, Object.assign({
            className: "topInfo"
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(O, Object.assign({
              className: "lPart"
            }, {
              children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(j, {
                src: a.dataPic,
                className: "img",
                style: {
                  borderRadius: 1 === t ? "20px" : "0px"
                }
              }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(O, Object.assign({
                className: "goodsInfo"
              }, {
                children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, Object.assign({
                  className: "goodsName"
                }, {
                  children: a.goodsName
                })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, Object.assign({
                  className: "goodsSize"
                }, {
                  children: a.skuName
                }))]
              }))]
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, Object.assign({
              className: "rPart"
            }, {
              children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(O, Object.assign({
                className: "price"
              }, {
                children: ["￥ ", a.pricesetNprice]
              }))
            }))]
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(O, Object.assign({
            className: "rate"
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, Object.assign({
              className: "title"
            }, {
              children: "商品评价"
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Is, {
              onChange: h.bind(null, i)
            })]
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, Object.assign({
            className: "evaluate"
          }, {
            children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(y, {
              className: "content",
              placeholder: x.current,
              rows: 5,
              maxLength: 30,
              onInput: b.bind(null, i)
            })
          }))]
        }, i);
      }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(N, Object.assign({
        style: {
          border: "1px solid ".concat(c),
          color: l,
          backgroundColor: o,
          borderRadius: 1 === r ? "20px" : "0px"
        },
        className: "btn",
        onClick: p
      }, {
        children: "提交"
      }))]
    }));
  }),
  As = function As(_ref34) {
    var a = _ref34.code,
      t = _ref34.defaultValue;
    var _N = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useExpressInfo)(a),
      n = _N.info,
      c = _N.detail,
      l = _N.stateObj,
      _i34 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      o = _i34.View,
      r = (0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(n, "packageList[0].contractGoodsList[0].dataPic", t.dataPic),
      d = (0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(n, "packageList.length", t.count),
      g = (0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(n, "packageList[0].expressName", t.expressName),
      m = (0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(n, "packageList[0].packageBillno", t.packageBillno),
      h = (0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(c, "state", t.result) || "-1";
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(o, Object.assign({
      className: "expressInfoTop"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
        className: "goodsImg",
        style: {
          backgroundImage: "url(".concat(r, ")")
        }
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(o, Object.assign({
          className: "tip"
        }, {
          children: ["共 ", d, " 件商品"]
        }))
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(o, Object.assign({
        className: "list"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(o, Object.assign({
          className: "listItem"
        }, {
          children: ["物流状态：", h ? l[h] : "暂时无法获取物流状态"]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(o, Object.assign({
          className: "listItem"
        }, {
          children: ["快递公司：", g]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(o, Object.assign({
          className: "listItem"
        }, {
          children: ["快递单号：", m]
        }))]
      }))]
    }));
  },
  Bs = function Bs(_ref35) {
    var a = _ref35.code,
      t = _ref35.defaultValue;
    var _N2 = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useExpressInfo)(a),
      n = _N2.detail,
      _i35 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      c = _i35.View,
      l = (0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(n, "message", t.message),
      o = (0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(n, "data", t.list);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
      className: "expressInfoStep"
    }, {
      children: "ok" === l ? o.map(function (a, t) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(c, Object.assign({
          className: "step"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
            className: "time"
          }, {
            children: a.time
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, {
            children: a.context
          })]
        }), t);
      }) : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
        className: "noInfo"
      }, {
        children: l
      }))
    }));
  },
  Vs = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref36) {
    var a = _ref36.code,
      t = _ref36.defaultValue;
    var _i36 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      n = _i36.View;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(n, Object.assign({
      className: "expressInfo"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(As, {
        code: a,
        defaultValue: t
      }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Bs, {
        code: a,
        defaultValue: t
      })]
    }));
  }),
  Ds = function Ds(_ref37) {
    var s = _ref37.setDefault,
      a = _ref37.checked;
    var _i37 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      t = _i37.SmoothCheckbox,
      n = _i37.Checkbox;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
      onChange: s
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
        checked: a,
        style: {
          "--icon-size": "18px",
          "--font-size": "14px",
          "--gap": "6px"
        }
      }, {
        children: "设为默认地址"
      }))
    }));
  },
  Ts = function Ts(_ref38) {
    var a = _ref38.itemData,
      t = _ref38.delAddress,
      n = _ref38.setDefault;
    var _i38 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      c = _i38.View,
      l = _i38.Text,
      _O = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useAddressItem)(a),
      o = _O.handlerImpl;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(c, Object.assign({
      className: "addressItem"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(c, Object.assign({
        className: "upInfo",
        onClick: o
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(c, Object.assign({
          className: "userInfo"
        }, {
          children: [a.addressMember, " ", a.addressPhone]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
          className: "addressInfo"
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(l, Object.assign({
            className: "address"
          }, {
            children: [a.provinceName, " ", a.areaName, " ", a.cityName, " ", a.addressDetail]
          }))
        }))]
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(c, Object.assign({
        className: "downInfo"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Ds, {
          checked: "1" === (null == a ? void 0 : a.addressDefault),
          setDefault: n
        }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, Object.assign({
          className: "del",
          onClick: t
        }, {
          children: "删除"
        }))]
      }))]
    }));
  },
  Ls = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function () {
    var _i39 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      s = _i39.View,
      t = _i39.Skeleton,
      n = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(new Array(3).fill(0));
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(s, Object.assign({
        className: "skullWrap"
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(s, Object.assign({
          className: "skull"
        }, {
          children: n.current.map(function (s, a) {
            return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, {
              className: "skullItem",
              animated: !0
            }, a);
          })
        }))
      }))
    });
  }),
  Ps = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref39) {
    var a = _ref39.url,
      t = _ref39.title,
      n = _ref39.subTitle,
      l = _ref39.link,
      o = _ref39.style;
    var _i40 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      r = _i40.View,
      d = _i40.Image;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
      className: "noData",
      style: o
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(r, Object.assign({
        className: "content"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, {
          className: "img",
          src: a
        }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
          className: "title"
        }, {
          children: t
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
          className: "subTitle"
        }, {
          children: n
        })), l ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(r, Object.assign({
          className: "link",
          onClick: function onClick() {
            return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)(l);
          }
        }, {
          children: ["去看看", (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.IconMobile, {
            value: "xiangyou1"
          })]
        })) : null]
      }))
    }));
  }),
  Rs = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref40) {
    var a = _ref40.refreshNum,
      t = _ref40.btnShape,
      n = _ref40.btnColor,
      c = _ref40.borderColor,
      l = _ref40.paddingBottom,
      o = _ref40.paddingTop,
      r = _ref40.color;
    var _i41 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      d = _i41.View,
      _j = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useAddressList)(a),
      g = _j.list,
      m = _j.delAddress,
      h = _j.setDefault,
      p = _j.skullShow;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(d, Object.assign({
      className: "addressListWrap"
    }, {
      children: [p ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Ls, {}) : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
        className: "addressList",
        style: {
          paddingTop: o + "px",
          paddingBottom: l + "px"
        }
      }, {
        children: g.length ? g.map(function (s, a) {
          return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Ts, {
            itemData: s,
            setDefault: h.bind(null, s, a),
            delAddress: m.bind(null, s)
          }, null == s ? void 0 : s.addressId);
        }) : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Ps, {
          url: "https://brushes.oss-cn-shanghai.aliyuncs.com/static/mini/noAddress.png",
          title: "您还没有添加过地址"
        })
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
        className: "addBtnWrap"
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
          style: {
            borderRadius: t,
            borderColor: c,
            color: r,
            backgroundColor: n
          },
          className: "addBtn",
          onClick: function onClick() {
            return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("addressEditor");
          }
        }, {
          children: "+ 新增地址"
        }))
      }))]
    }));
  }),
  zs = [{
    type: "input",
    props: {
      onlyShowClearWhenFocus: !0,
      placeholder: "请填写收货人姓名"
    },
    label: "收货人",
    name: "addressMember",
    rules: [{
      required: !0,
      message: "收货人姓名不能为空"
    }]
  }, {
    type: "input",
    props: {
      type: "number",
      onlyShowClearWhenFocus: !0,
      placeholder: "请填写收货人手机号码"
    },
    label: "手机号码",
    name: "addressPhone",
    rules: [{
      required: !0,
      message: "收货人手机号码不能为空"
    }, {
      validator: function validator(e, s) {
        return new Promise(function (e, a) {
          !/^1[3456789]\d{9}$/.test(s) && s ? a("请输入正确手机号") : e("");
        });
      }
    }]
  }, {
    type: "cascader",
    label: "所在地区",
    name: "area",
    rules: [{
      required: !0,
      message: "所在地区不能为空"
    }]
  }, {
    type: "input",
    props: {
      onlyShowClearWhenFocus: !0,
      placeholder: "街道/楼牌号等"
    },
    label: "详细地址",
    name: "addressDetail",
    rules: [{
      required: !0,
      message: "收货人详细地址不能为空"
    }]
  }, {
    type: "switch",
    props: {},
    label: "设置默认地址",
    name: "addressDefault"
  }],
  Ms = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function () {
    var _i42 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      s = _i42.View,
      t = _i42.Skeleton,
      n = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(new Array(5).fill(0));
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(s, Object.assign({
        className: "skullWrap"
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(s, Object.assign({
          className: "skull"
        }, {
          children: n.current.map(function (s, a) {
            return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, {
              className: "skullItem",
              animated: !0
            }, a);
          })
        }))
      }))
    });
  });
china_division_dist_areas_json__WEBPACK_IMPORTED_MODULE_8__.forEach(function (e) {
  var s = china_division_dist_cities_json__WEBPACK_IMPORTED_MODULE_7__.filter(function (s) {
    return s.code === e.cityCode;
  })[0];
  s && (s.children = s.children || [], s.children.push({
    label: e.name,
    value: e.code
  }));
}), china_division_dist_cities_json__WEBPACK_IMPORTED_MODULE_7__.forEach(function (e) {
  var s = china_division_dist_provinces_json__WEBPACK_IMPORTED_MODULE_6__.filter(function (s) {
    return s.code === e.provinceCode;
  })[0];
  s && (s.children = s.children || [], s.children.push({
    label: e.name,
    value: e.code + "00",
    children: e.children
  }));
});
var Fs = china_division_dist_provinces_json__WEBPACK_IMPORTED_MODULE_6__.map(function (e) {
    return {
      label: e.name,
      value: e.code + "0000",
      children: e.children
    };
  }),
  Ws = function Ws(_ref41) {
    var a = _ref41.form,
      t = _ref41.handleArea;
    var _i43 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      c = _i43.View,
      l = _brushes_simulate_component__WEBPACK_IMPORTED_MODULE_14__.CascadePicker,
      o = a.getFieldValue("area"),
      _ne25 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(!1),
      _ne26 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_12__["default"])(_ne25, 2),
      r = _ne26[0],
      d = _ne26[1],
      g = function g(e) {
        var s = {
            provinceName: "",
            provinceCode: e[0],
            cityName: "",
            cityCode: e[1],
            areaName: "",
            areaCode: e[2]
          },
          a = {
            pIndex: 0,
            cIndex: 0
          };
        for (var _t2 = 0; _t2 < Fs.length; _t2++) if (Fs[_t2].value === e[0]) {
          s.provinceName = Fs[_t2].label, a.pIndex = _t2;
          break;
        }
        for (var _t3 = 0; _t3 < Fs[a.pIndex].children.length; _t3++) if (Fs[a.pIndex].children[_t3].value === e[1]) {
          s.cityName = Fs[a.pIndex].children[_t3].label, a.cIndex = _t3;
          break;
        }
        for (var _t4 = 0; _t4 < Fs[a.pIndex].children[a.cIndex].children.length; _t4++) if (Fs[a.pIndex].children[a.cIndex].children[_t4].value === e[2]) {
          s.areaName = Fs[a.pIndex].children[a.cIndex].children[_t4].label;
          break;
        }
        return console.log(52, s), s;
      };
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(c, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
        className: "txt",
        onClick: function onClick() {
          return d(!0);
        }
      }, {
        children: (null == o ? void 0 : o.provinceName) ? "".concat(o.provinceName, "\u2014").concat(o.cityName, "-").concat(o.areaName) : "请选择所在地区"
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, {
        onConfirm: function onConfirm(e) {
          t("h5", g(e));
        },
        options: Fs,
        visible: r,
        onClose: function onClose() {
          return d(!1);
        }
      })]
    });
  },
  Gs = function Gs(_ref42) {
    var s = _ref42.checked,
      a = _ref42.onChange;
    var _i44 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      t = _i44.View,
      c = _brushes_simulate_component__WEBPACK_IMPORTED_MODULE_14__.Switch;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, {
        checked: s,
        onChange: a,
        style: {
          "--checked-color": "#000000",
          "--height": "36px",
          "--width": "60px"
        }
      })
    });
  },
  Es = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)(),
  Hs = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref43) {
    var s = _ref43.addressId,
      t = _ref43.btnShape,
      c = _ref43.btnColor,
      l = _ref43.borderColor,
      o = _ref43.color,
      r = _ref43.paddingTop,
      d = _ref43.paddingBottom;
    var _i45 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      g = _i45.View,
      m = _i45.Switch,
      h = _brushes_simulate_component__WEBPACK_IMPORTED_MODULE_14__.Form,
      p = _brushes_simulate_component__WEBPACK_IMPORTED_MODULE_14__.Button,
      b = _brushes_simulate_component__WEBPACK_IMPORTED_MODULE_14__.Input,
      u = "weapp",
      _C = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useEditAddress)(s, h, Es),
      N = _C.skullShow,
      O = _C.form,
      j = _C.area,
      f = _C.defaultAddress,
      y = _C.handleArea,
      x = _C.handleDefaultAddress,
      k = _C.handleFinish;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
      className: "addressDetail",
      style: {
        height: Es ? "100%" : "667px",
        paddingBottom: d + "px",
        paddingTop: r + "px"
      }
    }, {
      children: N ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Ms, {}) : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(h, Object.assign({
        form: O,
        layout: "horizontal",
        mode: "card",
        onFinish: k,
        footer: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
          style: {
            color: o,
            backgroundColor: c,
            borderColor: l
          },
          shape: t,
          block: !0,
          type: "submit",
          size: "large"
        }, {
          children: "提交"
        }))
      }, {
        children: zs.map(function (s, t) {
          return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(h.Item, Object.assign({
            label: s.label,
            name: s.name,
            rules: s.rules,
            trigger: "cascader" === s.type ? "onConfirm" : "onChange",
            arrow: !1
          }, {
            children: "input" === s.type ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, Object.assign({}, s.props)) : "switch" === s.type ? "h5" === u ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Gs, {
              onChange: x.bind(null, "h5"),
              checked: "1" === f
            }) : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(m, {
              color: "#000",
              onChange: x.bind(null, "weapp"),
              checked: "1" === f
            }) : "cascader" === s.type ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
              children: Es ? "h5" === u ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Ws, {
                form: O,
                handleArea: y
              }) : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("picker", Object.assign({
                mode: "region",
                onChange: y.bind(null, "weapp"),
                value: j
              }, {
                children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
                  className: "areaWrap"
                }, {
                  children: j.provinceName ? "".concat(j.provinceName, "\u2014").concat(j.cityName, "-").concat(j.areaName) : "请选择所在地区"
                }))
              })) : "请选择所在地区"
            }) : void 0
          }), t);
        })
      }))
    }));
  }),
  Ys = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)(),
  Us = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref44) {
    var a = _ref44.code,
      t = _ref44.borderRadius,
      n = _ref44.leftColor,
      c = _ref44.leftButtonColor,
      l = _ref44.leftBorderColor,
      o = _ref44.leftBorderRadius,
      r = _ref44.rightValue,
      d = _ref44.rightAddHref,
      g = _ref44.rightColor,
      m = _ref44.rightButtonColor,
      h = _ref44.rightBorderColor,
      p = _ref44.rightBorderRadius,
      b = _ref44.paddingTop,
      u = _ref44.paddingBottom;
    var _i46 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      N = _i46.View,
      O = _i46.Text,
      _f = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useOrderResultResult)(a || ((0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getStorage)("contractBillcode") || {}).contractBillcode),
      j = _f.result,
      C = j.sysRecode,
      y = j.dataObj;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(N, Object.assign({
      className: "placeOrderResult",
      style: {
        height: Ys ? "100vh" : "667px",
        paddingTop: b,
        paddingBottom: u
      }
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(N, C ? Object.assign({
        className: "placeOrderResultContent",
        style: {
          borderRadius: 1 === t ? "20px" : "0px"
        }
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, {
          className: "icon"
        }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(N, Object.assign({
          className: "tips"
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, Object.assign({
            className: "title"
          }, {
            children: "订单支付成功"
          }))
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(N, Object.assign({
          className: "placeOrderResultWrap"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(N, Object.assign({
            className: "placeOrderResultItem"
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, Object.assign({
              className: "label"
            }, {
              children: "订单号："
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, Object.assign({
              className: "value"
            }, {
              children: y.contractBillcode
            }))]
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(N, Object.assign({
            className: "placeOrderResultItem"
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, Object.assign({
              className: "label"
            }, {
              children: "支付方式："
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, Object.assign({
              className: "value"
            }, {
              children: "在线支付"
            }))]
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(N, Object.assign({
            className: "placeOrderResultItem"
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, Object.assign({
              className: "label"
            }, {
              children: "支付金额："
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(O, Object.assign({
              className: "value"
            }, {
              children: ["￥ ", y.dataBmoney]
            }))]
          }))]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(N, Object.assign({
          className: "btnGroup"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(N, Object.assign({
            className: "btn black",
            onClick: function onClick() {
              return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("orderDetail", {
                contractBillcode: y.contractBillcode
              });
            },
            style: {
              color: n,
              backgroundColor: c,
              border: "1px solid ".concat(l),
              borderRadius: 1 === o ? "20px" : "0px"
            }
          }, {
            children: "查看订单"
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(N, Object.assign({
            style: {
              color: g,
              backgroundColor: m,
              border: "1px solid ".concat(h),
              borderRadius: 1 === p ? "20px" : "0px"
            },
            onClick: function onClick() {
              return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)(d.value);
            },
            className: "btn white"
          }, {
            children: r
          }))]
        }))]
      }) : Object.assign({
        className: "placeOrderResultContent"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, {
          className: "icon"
        }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(N, Object.assign({
          className: "tips"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, Object.assign({
            className: "title"
          }, {
            children: "订单支付失败"
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, Object.assign({
            className: "tip"
          }, {
            children: "您的订单将保留15分钟，可点击下方“去支付”完成订单"
          }))]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(N, Object.assign({
          className: "btnGroup"
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(N, Object.assign({
            onClick: function onClick() {
              return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("paymentMode", {
                contractBillcode: j.contractBillcode
              });
            },
            className: "btn white"
          }, {
            children: "去支付"
          }))
        }))]
      }))
    }));
  });
/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function () {
  var _i47 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
    s = _i47.View,
    t = _i47.Skeleton,
    n = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(new Array(3).fill(0));
  return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(s, Object.assign({
      className: "skullWrap"
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(s, Object.assign({
        className: "skull"
      }, {
        children: n.current.map(function (s, a) {
          return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, {
            className: "skullItem",
            animated: !0
          }, a);
        })
      }))
    }))
  });
});
var Qs = function Qs() {
    var _i48 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      s = _i48.View,
      a = _i48.Image;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(s, Object.assign({
      className: "noData"
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(a, {
        src: "https://b2cweapp7c0069b43749439d97b7cae6a02bd459.saas.qjclouds.com/paas/shop-master/c-static/images/wxminiImg/no_coupon.png",
        className: "img"
      })
    }));
  },
  Ks = function Ks(_ref45) {
    var t = _ref45.list,
      n = _ref45.coe,
      c = _ref45.config,
      l = _ref45.backgroundColor,
      o = _ref45.color;
    var _i49 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      r = _i49.View,
      d = _i49.Text;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: t.length ? t.map(function (t, i) {
        return console.log(16, c.current[n.current].text), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
          className: "couponListItem\n                   ".concat(c.current[n.current].styleName),
          style: {
            backgroundColor: l,
            color: o
          }
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(r, Object.assign({
            className: "coupon-content"
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
              className: "price"
            }, {
              children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
                className: "num"
              }, {
                children: t.pbName
              }))
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(r, Object.assign({
              className: "couponListItem-info"
            }, {
              children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
                className: "title"
              }, {
                children: t.discName
              })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(d, Object.assign({
                className: "date"
              }, {
                children: ["有效期至：", "".concat(new Date(t.gmtModified).getFullYear(), "-").concat(new Date(t.gmtModified).getMonth() + 1, "-").concat(new Date(t.gmtModified).getDate())]
              })), c.current[n.current].text ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
                className: "btn"
              }, {
                children: c.current[n.current].text
              })) : null, 2 === n.current ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
                  className: "round"
                }, {
                  children: "已失效"
                }))
              }) : null]
            }))]
          }))
        }), i);
      }) : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Qs, {})
    });
  },
  qs = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref46) {
    var a = _ref46.backgroundColor,
      t = _ref46.color,
      n = _ref46.paddingTop,
      c = _ref46.paddingBottom,
      l = _ref46.queue;
    var _i50 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      o = _i50.View,
      r = _i50.Text,
      d = _i50.ScrollView,
      _y = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useCouponList)(),
      g = _y.coe,
      m = _y.getList,
      h = _y.config,
      p = _y.switchTab,
      _y$list = _y.list,
      b = _y$list === void 0 ? [] : _y$list;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(o, Object.assign({
      className: "couponList"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
        className: "couponTab"
      }, {
        children: h.current.map(function (a, t) {
          return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(o, Object.assign({
            className: "couponTabItem " + (g.current === t ? "active" : ""),
            onClick: function onClick() {
              return p(t);
            }
          }, {
            children: [a.label, (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, {
              className: "icon"
            })]
          }), a.id);
        })
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ss, Object.assign({
        id: "couponTab",
        bottomHeight: "60"
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
          onScroll: m
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
            className: "couponListContent",
            style: {
              paddingTop: n,
              paddingBottom: c
            }
          }, {
            children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Ks, {
              backgroundColor: a,
              color: t,
              queue: l,
              list: b,
              coe: g,
              config: h
            })
          }))
        }))
      }))]
    }));
  });
function Zs(_ref47) {
  var a = _ref47.list;
  var _i51 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
    t = _i51.View,
    n = _i51.Text,
    c = _i51.Image,
    l = _i51.Checkbox,
    o = _i51.NumStep,
    r = _i51.SmoothCheckbox,
    d = _i51.WrapLoading,
    _x = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useStore)(),
    g = _x.loading,
    _k = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useCartItem)(),
    m = _k.select,
    h = _k.onChange,
    p = _k.handleStep;
  return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
    loading: g
  }, {
    children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
      onChange: h
    }, {
      children: a.map(function (a, i) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
          className: "cartItem"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
            className: "checkBoxWrap"
          }, {
            children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, {
              checked: m.includes(a.shoppingGoodsId + ""),
              value: a.shoppingGoodsId,
              style: {
                "--icon-size": "16px",
                "--font-size": "14px",
                "--gap": "6px"
              }
            })
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, {
            className: "img",
            src: a.dataPic,
            onClick: function onClick() {
              return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("goodDetail", {
                skuCode: a.skuCode
              });
            }
          }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
            className: "cartItem-info"
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
              className: "cartItem-goodsName"
            }, {
              children: a.goodsName
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
              className: "cartItem-size"
            }, {
              children: ["规格：", a.skuName, " X ", a.goodsCamount]
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
              className: "cartItem-handleWrap"
            }, {
              children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(n, Object.assign({
                className: "price"
              }, {
                children: ["￥", a.pricesetNprice]
              })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, {
                count: a.goodsCamount,
                handleStep: p.bind(null, a.shoppingGoodsId, a.goodsCamount)
              })]
            }))]
          }))]
        }), i);
      })
    }))
  }));
}
var Xs = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)(),
  $s = function $s(_ref48) {
    var t = _ref48.refreshNum;
    var _i52 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      n = _i52.View,
      c = _i52.SmoothView,
      l = _i52.Checkbox,
      o = _i52.SmoothCheckbox,
      r = _i52.ScrollView,
      _ne27 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(!0),
      _ne28 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_12__["default"])(_ne27, 2),
      d = _ne28[0],
      g = _ne28[1],
      _v = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useCartList)(t),
      m = _v.cartList,
      h = _v.amount,
      p = _v.selectAll,
      b = _v.allCart,
      u = _v.toOrderImpl,
      N = _v.select,
      O = _v.deleteCart,
      j = _v.disMoney;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
      className: "cart",
      style: {
        height: Xs ? "100%" : "667px"
      }
    }, {
      children: m.length ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
          className: "edit"
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
            className: "btn",
            onClick: function onClick() {
              return g(!d);
            }
          }, {
            children: d ? "编辑" : "完成"
          }))
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ss, Object.assign({
          id: "editId",
          bottomHeight: "50"
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, {
            children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Zs, {
              list: m
            })
          })
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(n, Object.assign({
          className: "cart-dashboard"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
            className: "choose"
          }, {
            children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
              onChange: p
            }, {
              children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, Object.assign({
                checked: b.current.length === N.length,
                value: "true",
                style: {
                  "--icon-size": "16px",
                  "--font-size": "14px",
                  "--gap": "6px"
                }
              }, {
                children: "全选"
              }))
            }))
          })), d ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(n, Object.assign({
            className: "check"
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(n, Object.assign({
              className: "priceGroup"
            }, {
              children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(n, Object.assign({
                className: "discount"
              }, {
                children: ["优惠: ", (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
                  className: "data"
                }, {
                  children: Ke(j)
                }))]
              })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(n, Object.assign({
                className: "all"
              }, {
                children: ["合计: ", (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
                  className: "data"
                }, {
                  children: Ke(h.amount)
                }))]
              }))]
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(n, Object.assign({
              onClick: u,
              className: "btn"
            }, {
              children: ["结算(", h.num, ")"]
            }))]
          })) : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
            className: "del"
          }, {
            children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
              onClick: O,
              className: "btn"
            }, {
              children: "删除"
            }))
          }))]
        }))]
      }) : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Ps, {
        url: "https://brushes.oss-cn-shanghai.aliyuncs.com/static/mini/noCarts.png",
        title: "购物车竟然是空的",
        subTitle: "快点挑选点东西犒赏自己吧",
        link: "index"
      })
    }));
  },
  Js = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref49) {
    var s = _ref49.refreshNum;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.StoreProvider, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)($s, {
        refreshNum: s
      })
    });
  });
function _s(_ref50) {
  var s = _ref50.dispatchPageStore;
  var _i53 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
    a = _i53.View,
    _I = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useCartTop)(s),
    t = _I.isEditor,
    n = _I.editorImpl;
  return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(a, Object.assign({
    className: "cart-edit"
  }, {
    children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(a, Object.assign({
      className: "btn",
      onClick: n
    }, {
      children: t ? "完成" : "编辑"
    }))
  }));
}
var ea = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref51) {
    var a = _ref51.promotionName,
      t = _ref51.checked,
      n = _ref51.promotionCode;
    var _i54 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      c = _i54.View,
      l = _i54.Radio;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(c, Object.assign({
      className: "promotion-item"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
        className: "content"
      }, {
        children: a
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
        className: "choose"
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, {
          checked: t,
          value: n
        })
      }))]
    }));
  }),
  sa = function sa(_ref52) {
    var s = _ref52.onChange,
      a = _ref52.promotionCode,
      t = _ref52.visible,
      n = _ref52.setVisible,
      c = _ref52.promotion;
    var _i55 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      l = _i55.Popup,
      o = _i55.ScrollView,
      r = _i55.View,
      d = _i55.SmoothRadio;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, Object.assign({
      popupVisible: t,
      popupHandler: n
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
        className: "goodsDetail-coupon-popup"
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ss, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, {
            children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
              onChange: s
            }, {
              children: c.map(function (e, s) {
                return /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.createElement)(ea, Object.assign({
                  checked: e.promotionCode === a
                }, e, {
                  key: s
                }));
              })
            }))
          })
        })
      }))
    }));
  },
  aa = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref53) {
    var t = _ref53.goodsName,
      n = _ref53.skuName,
      c = _ref53.goodsCamount,
      l = _ref53.shoppingGoodsId,
      o = _ref53.pricesetNprice,
      r = _ref53.handleStep;
    var _i56 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      d = _i56.View,
      g = _i56.SmoothView,
      m = _i56.NumStep;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(d, Object.assign({
        className: "cartItem-info"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
          className: "cartItem-goodsName"
        }, {
          children: t
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(d, Object.assign({
          className: "cartItem-size"
        }, {
          children: ["规格：", n, " X ", c]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(d, Object.assign({
          className: "cartItem-handleWrap"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
            className: "price"
          }, {
            children: Ke(o)
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(m, {
            count: c,
            handleStep: r.bind(null, l, c)
          })]
        }))]
      }))
    });
  }),
  ta = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref54) {
    var s = _ref54.dataPic,
      a = _ref54.skuCode;
    var _i57 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      t = _i57.Image;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, {
      className: "img",
      src: s,
      onClick: function onClick() {
        return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("goodDetail", {
          skuCode: a
        });
      }
    });
  }),
  ia = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (s) {
    var a = s.shoppingGoodsId,
      t = He(s, ["shoppingGoodsId"]);
    var _i58 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      n = _i58.View,
      c = _i58.Checkbox,
      _t$select = t.select,
      l = _t$select === void 0 ? [] : _t$select;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
      className: "checkBoxWrap"
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, {
        checked: l.includes(a + ""),
        value: a,
        style: {
          "--icon-size": "16px",
          "--font-size": "14px",
          "--gap": "6px"
        }
      })
    }));
  }),
  na = function na(_ref55) {
    var _ref55$promotion = _ref55.promotion,
      t = _ref55$promotion === void 0 ? [] : _ref55$promotion,
      n = _ref55.updatePm,
      c = _ref55.shoppingGoodsId,
      l = _ref55.promotionCode;
    var _i59 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      o = _i59.View,
      _ne29 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(!1),
      _ne30 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_12__["default"])(_ne29, 2),
      r = _ne30[0],
      d = _ne30[1],
      g = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(function () {
        return (t.find(function (e) {
          return e.promotionCode === l;
        }) || {}).promotionName;
      }, [t]);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(o, Object.assign({
        className: "cart-promote-active",
        onClick: function onClick() {
          return d(!0);
        }
      }, {
        children: [g, (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, {
          children: "修改"
        })]
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(sa, {
        promotionCode: l,
        onChange: function onChange(e) {
          d(!1), n(c, e.detail.value);
        },
        promotion: t,
        visible: r,
        setVisible: d
      })]
    });
  },
  ca = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (a) {
    var t = a.item,
      n = He(a, ["item"]);
    var _i60 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      c = _i60.View;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(c, Object.assign({
      className: "cart-list-item"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ia, Object.assign({}, n, {
        shoppingGoodsId: t.shoppingGoodsId
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ta, {
        dataPic: t.dataPic,
        skuCode: t.skuCode
      }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(aa, Object.assign({}, t, n))]
    }));
  }),
  la = function la(t) {
    var _t$shoppingGoodsList = t.shoppingGoodsList,
      i = _t$shoppingGoodsList === void 0 ? [] : _t$shoppingGoodsList,
      n = He(t, ["shoppingGoodsList"]);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: i.map(function (a, t) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ca, Object.assign({}, n, {
            item: a
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(na, {
            promotionCode: n.promotionCode,
            shoppingGoodsId: a.shoppingGoodsId,
            updatePm: n.updatePm,
            promotion: a.pmPromotionList
          })]
        }, t);
      })
    });
  },
  oa = function oa(_ref56) {
    var a = _ref56.disNextMsg,
      t = _ref56.promotionName,
      n = _ref56.pbName;
    var _i61 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      c = _i61.View,
      l = _i61.SmoothView;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(c, Object.assign({
      className: "cart-dis-title"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, Object.assign({
        className: "tips"
      }, {
        children: n
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, Object.assign({
        style: {
          padding: "0 10px"
        }
      }, {
        children: t
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, {
        children: a
      })]
    }));
  },
  ra = function ra(_ref57) {
    var t = _ref57.refreshNum,
      n = _ref57.cartSelect,
      c = _ref57.dispatchPageStore,
      _ref57$cartUpdateCoun = _ref57.cartUpdateCount,
      l = _ref57$cartUpdateCoun === void 0 ? 0 : _ref57$cartUpdateCoun;
    var _i62 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      o = _i62.SmoothCheckbox,
      r = _i62.WrapLoading,
      d = _i62.View,
      _S = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useCartListNext)(t, l, c),
      g = _S.loading,
      m = _S.cartList,
      h = _S.onChange,
      p = _S.handleStep,
      b = _S.updatePm;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
      loading: g
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
        className: "cart-wrap"
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
          onChange: h
        }, {
          children: m.length ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: m.map(function (_ref58, r) {
              var a = _ref58.memberCname,
                t = _ref58.promotionCode,
                i = _ref58.disNextMsg,
                c = _ref58.promotionName,
                l = _ref58.pbName,
                o = _ref58.shoppingGoodsList;
              return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
                children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h4", {
                  children: a
                }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(d, Object.assign({
                  className: "cart-bg"
                }, {
                  children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(oa, {
                    disNextMsg: i,
                    promotionName: c,
                    pbName: l
                  }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(la, {
                    promotionCode: t,
                    handleStep: p,
                    select: n,
                    updatePm: b,
                    shoppingGoodsList: o
                  })]
                }))]
              }, r);
            })
          }) : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Ps, {
            url: "https://brushes.oss-cn-shanghai.aliyuncs.com/static/mini/noCarts.png",
            title: "购物车竟然是空的",
            subTitle: "快点挑选点东西犒赏自己吧",
            link: "index"
          })
        }))
      }))
    }));
  },
  da = function da(_ref59) {
    var _ref59$cartInfo = _ref59.cartInfo,
      a = _ref59$cartInfo === void 0 ? [] : _ref59$cartInfo,
      _ref59$cartSelect = _ref59.cartSelect,
      t = _ref59$cartSelect === void 0 ? [] : _ref59$cartSelect,
      _ref59$cartIsEditor = _ref59.cartIsEditor,
      n = _ref59$cartIsEditor === void 0 ? !1 : _ref59$cartIsEditor,
      c = _ref59.dispatchPageStore;
    var _i63 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      l = _i63.View,
      o = _i63.SmoothView,
      r = _i63.SmoothCheckbox,
      d = _i63.Checkbox,
      _A = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useCartOperate)(t, a, c),
      g = _A.toOrderImpl,
      m = _A.deleteCart,
      h = _A.selectAll,
      p = _A.cartDetail;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(l, Object.assign({
      className: "cart-dashboard"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, Object.assign({
        className: "choose"
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
          onChange: h
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
            checked: a.length === t.length,
            value: "true",
            style: {
              "--icon-size": "16px",
              "--font-size": "14px",
              "--gap": "6px"
            }
          }, {
            children: "全选"
          }))
        }))
      })), n ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, Object.assign({
        className: "del"
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, Object.assign({
          onClick: m,
          className: "btn"
        }, {
          children: "删除"
        }))
      })) : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(l, Object.assign({
        className: "check"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(l, Object.assign({
          className: "priceGroup"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(l, Object.assign({
            className: "discount"
          }, {
            children: ["优惠: ", (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
              className: "data"
            }, {
              children: Ke(p.disMoney)
            }))]
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(l, Object.assign({
            className: "all"
          }, {
            children: ["合计: ", (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
              className: "data"
            }, {
              children: Ke(p.amount)
            }))]
          }))]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(l, Object.assign({
          onClick: g,
          className: "btn"
        }, {
          children: ["结算(", p.num, ")"]
        }))]
      }))]
    }));
  },
  ga = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref60) {
    var a = _ref60.avatarStyle,
      t = _ref60.paddingTop,
      n = _ref60.paddingBottom,
      c = _ref60.userAvatar,
      l = _ref60.userNickname;
    var _i64 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      o = _i64.View,
      r = _i64.Text,
      d = _i64.IconMobile,
      g = _i64.Image,
      _Qe = Qe(),
      m = _Qe.servicePopup;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(o, Object.assign({
      className: "mineData",
      style: {
        paddingTop: "".concat(t, "px"),
        paddingBottom: "".concat(n, "px")
      }
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(o, Object.assign({
        className: "topBoard"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, {
          value: "shezhi",
          onClick: function onClick() {
            return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("/account/setting/index");
          }
        }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, {
          value: "kehufuwukefu",
          onClick: m
        })]
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(o, Object.assign({
        className: "userSetting",
        onClick: function onClick() {
          return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("/account/setting/index");
        }
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(o, Object.assign({
          className: "lPart"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
            className: "name"
          }, {
            children: l || "用户名称"
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
            className: "link",
            style: {
              paddingTop: "10px"
            }
          }, {
            children: "编辑个人资料 >"
          }))]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, {
          src: c,
          alt: "",
          className: "avatar",
          style: {
            borderRadius: a ? "50%" : "2px"
          }
        })]
      }))]
    }));
  }),
  ma = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref61) {
    var a = _ref61.title,
      t = _ref61.columnList;
    var _i65 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      n = _i65.View,
      c = _i65.Text,
      l = _i65.Badge,
      o = _i65.Image,
      _ne31 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({}),
      _ne32 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_12__["default"])(_ne31, 2),
      r = _ne32[0],
      d = _ne32[1];
    return (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
      Ye(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_13__["default"])().mark(function _callee4() {
        var _e4;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_13__["default"])().wrap(function _callee4$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              _context4.prev = 0;
              _context4.next = 3;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_5__.getContractNumbers)();
            case 3:
              _e4 = _context4.sent;
              d(_e4.dataObj);
              _context4.next = 9;
              break;
            case 7:
              _context4.prev = 7;
              _context4.t0 = _context4["catch"](0);
            case 9:
            case "end":
              return _context4.stop();
          }
        }, _callee4, null, [[0, 7]]);
      }));
    }, []), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(n, Object.assign({
      className: "mineOrderEntry"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(n, Object.assign({
        className: "title"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
          className: "name"
        }, {
          children: a
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
          className: "more",
          onClick: function onClick() {
            return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("orderlist");
          }
        }, {
          children: "查看全部"
        }))]
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
        className: "content"
      }, {
        children: t.map(function (a, t) {
          return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(n, Object.assign({
            onClick: function onClick() {
              return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("orderlist", {
                indexId: t + 1
              });
            },
            className: "contentItem",
            style: {
              display: a.show ? "block" : "none"
            }
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, Object.assign({}, r[a.code] > 0 ? {
              content: r[a.code]
            } : {}, {
              color: "#000",
              style: {
                color: "#fff",
                fontSize: 12
              }
            }, {
              children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, {
                src: a.imgUrl,
                className: "icon"
              })
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
              className: "subTitle"
            }, {
              children: a.label
            }))]
          }), t);
        })
      }))]
    }));
  }),
  ha = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref62) {
    var a = _ref62.paddingTop,
      t = _ref62.paddingBottom,
      n = _ref62.columnList;
    var _i66 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      c = _i66.View,
      l = _i66.Text,
      o = _i66.IconMobile,
      r = _i66.Image;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
      className: "mineFunction",
      style: {
        paddingTop: a + "px",
        paddingBottom: t + "px"
      }
    }, {
      children: n.map(function (a, t) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(c, Object.assign({
          className: "menuListItem",
          onClick: function onClick() {
            return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)(a.link.value);
          }
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(c, Object.assign({
            className: "lPart"
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, {
              src: a.imgUrl,
              className: "icon"
            }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, Object.assign({
              className: "label"
            }, {
              children: a.link.label
            }))]
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, {
            value: "xiangyou1"
          })]
        }), t);
      })
    }));
  }),
  pa = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)(),
  ba = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref63) {
    var a = _ref63.contractBillcode,
      t = _ref63.contractBbillcode,
      n = _ref63.btnColor,
      c = _ref63.btnShape,
      l = _ref63.borderColor,
      o = _ref63.paddingTop,
      r = _ref63.paddingBottom,
      d = _ref63.color;
    var _i67 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      g = _i67.View,
      m = _i67.Text,
      h = _i67.Radio,
      p = _i67.IconMobile,
      b = _i67.WrapLoading,
      u = _i67.SmoothRadio,
      _B = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useOrderResult)({
        contractBillcode: a,
        contractBbillcode: t
      }),
      N = _B.paymentImpl,
      O = _B.channelList,
      j = _B.contract,
      C = _B.handleRadio,
      f = _B.loading;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(g, Object.assign({
      className: "paymentModeWrap",
      style: {
        height: pa ? "inherit" : "667px",
        paddingBottom: r + "px",
        paddingTop: o + "px"
      }
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(g, Object.assign({
        className: "paymentMode"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(g, Object.assign({
          className: "topInfo"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(m, Object.assign({
            className: "title"
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, {
              value: "roundcheck"
            }), "订单提交成功"]
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(g, Object.assign({
            className: "info"
          }, {
            children: ["订单号：", j.current.contractBillcode, " | 总金额：", j.current.dataBmoney, "元"]
          }))]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
          className: "paymentGroup"
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(u, Object.assign({
            onChange: C
          }, {
            children: O.map(function (a) {
              return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(g, Object.assign({
                className: "paymentItem"
              }, {
                children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, {
                  value: a.icon
                }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(g, {
                  children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(g, Object.assign({
                    className: "base"
                  }, {
                    children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(m, {
                      children: a.fchannelName
                    }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(h, {
                      value: a.fchannelCode,
                      className: "choose"
                    })]
                  })), "account" === a.value ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(g, Object.assign({
                    className: "info"
                  }, {
                    children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, {
                      children: "账户余额：0元"
                    }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, {
                      children: "本单抵扣：5.4元"
                    })]
                  })) : null]
                })]
              }), a.fchannelCode);
            })
          }))
        }))]
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, Object.assign({
        loading: f
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
          className: "btnGroup",
          onClick: N
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
            style: {
              borderRadius: c,
              backgroundColor: n,
              color: d,
              borderColor: l
            },
            className: "payment"
          }, {
            children: "立即支付"
          }))
        }))
      }))]
    }));
  }),
  ua = function ua(_ref64) {
    var a = _ref64.footprintItem,
      t = _ref64.edit;
    var _i68 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      n = _i68.View,
      c = _i68.Image,
      l = _i68.Checkbox,
      o = _i68.SmoothView,
      r = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(function () {
        return a.footprintOpnum ? "".concat(a.footprintOpnum, "\u5143") : "";
      }, [a.footprintOpnum]);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(n, Object.assign({
      className: "footprintItem"
    }, {
      children: [t ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
        className: "lPart"
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, {
          value: a.footprintCode
        })
      })) : null, (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(n, Object.assign({
        className: "rPart",
        onClick: function onClick() {
          return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("goodDetail", {
            skuCode: a.footprintOpcode
          });
        }
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, {
          src: a.footprintOppic,
          className: "img"
        }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(n, Object.assign({
          className: "info"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
            className: "title"
          }, {
            children: a.footprintOpcont
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
            className: "price"
          }, {
            children: r
          }))]
        }))]
      }))]
    }));
  },
  Na = function Na(_ref65) {
    var t = _ref65.item,
      n = _ref65.edit;
    var _i69 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      c = _i69.View;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(c, Object.assign({
      className: "footPrint"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
          className: "title",
          style: {
            paddingLeft: "20px",
            paddingTop: "30px",
            paddingBottom: "10px"
          }
        }, {
          children: null == t ? void 0 : t.title
        }))
      }), t.option.map(function (s, a) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ua, {
          footprintItem: s,
          edit: n
        }, a);
      })]
    }));
  },
  Oa = function Oa(_ref66) {
    var s = _ref66.footprintList,
      t = _ref66.edit;
    var i = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(function () {
      var e = s.map(function (e) {
          return e.gmtCreate = e.gmtCreate ? dayjs__WEBPACK_IMPORTED_MODULE_9___default()(e.gmtCreate).format("YYYY-MM-DD") : e.gmtCreate, e;
        }),
        a = (0,lodash_es__WEBPACK_IMPORTED_MODULE_17__["default"])(e, "gmtCreate");
      return Object.keys(a).map(function (e) {
        return {
          title: e || "",
          option: a[e]
        };
      });
    }, [s]);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: i.map(function (s, a) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Na, {
          item: s,
          edit: t
        }, a);
      })
    });
  },
  ja = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function () {
    var _i70 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      a = _i70.View,
      t = _i70.ScrollView,
      n = _i70.SmoothCheckbox,
      c = _i70.Button,
      l = _i70.Image,
      _V = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useFootprint)(),
      o = _V.footprintList,
      r = _V.edit,
      d = _V.setEdit,
      g = _V.getSelectItem,
      m = _V.delItem,
      h = _V.getData;
    return console.log(18, o), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(a, Object.assign({
      className: "footprint"
    }, {
      children: 0 === o.length ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(a, Object.assign({
        className: "noDate"
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, {
          className: "img",
          src: "https://b2cweapp7c0069b43749439d97b7cae6a02bd459.saas.qjclouds.com/paas/shop-master/c-static/images/wxminiImg/noCollection.png"
        })
      })) : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(a, Object.assign({
        className: "hasDate"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(a, Object.assign({
          className: "topBar"
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(a, Object.assign({
            className: "edit",
            onClick: function onClick() {
              return d(!r);
            }
          }, {
            children: r ? "完成" : "编辑"
          }))
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ss, Object.assign({
          id: "topBar1"
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
            scrollY: !0,
            scrollWithAnimation: !0,
            refresherEnabled: !0,
            onScroll: h
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
              onChange: g
            }, {
              children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Oa, {
                footprintList: o,
                edit: r
              })
            })), r ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(a, Object.assign({
              className: "handleBar"
            }, {
              children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(a, {
                className: "checkAll"
              }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
                className: "btn",
                onClick: m
              }, {
                children: "删除"
              }))]
            })) : null]
          }))
        }))]
      }))
    }));
  }),
  Ca = function Ca(_ref67) {
    var a = _ref67.item,
      t = _ref67.edit,
      n = _ref67.checked;
    var _i71 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      c = _i71.View,
      l = _i71.Image,
      o = _i71.Checkbox,
      r = _i71.SmoothView;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(c, Object.assign({
      className: "collectItem"
    }, {
      children: [t ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, {
        className: "lPart",
        value: a.collectCode,
        checked: n
      }) : null, (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(c, Object.assign({
        className: "rPart",
        onClick: function onClick() {
          return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("goodDetail", {
            skuCode: a.collectOpcode
          });
        }
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, {
          src: a.collectOppic,
          className: "img"
        }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(c, Object.assign({
          className: "info"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
            className: "title"
          }, {
            children: a.collectOpcont
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(r, Object.assign({
            className: "price"
          }, {
            children: [a.collectOpnum, " 元"]
          }))]
        }))]
      }))]
    }));
  },
  fa = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function () {
    var _D = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useCollectionList)(),
      a = _D.collectionList,
      t = _D.edit,
      n = _D.setEdit,
      c = _D.getData,
      l = _D.getSelectItem,
      o = _D.delItem,
      r = _D.init,
      d = _D.checked,
      g = _D.handleSelectAll,
      m = _D.selectAllChecked,
      _i72 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      h = _i72.View,
      p = _i72.ScrollView,
      b = _i72.SmoothCheckbox,
      u = _i72.Checkbox,
      N = _i72.Button,
      O = _i72.Image;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(h, Object.assign({
      className: "collectList"
    }, {
      children: 0 === a.length ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(h, Object.assign({
        className: "noDate"
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, {
          className: "img",
          src: "https://b2cweapp7c0069b43749439d97b7cae6a02bd459.saas.qjclouds.com/paas/shop-master/c-static/images/wxminiImg/noCollection.png"
        })
      })) : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(h, Object.assign({
        className: "hasDate"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(h, Object.assign({
          className: "topBar"
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(h, Object.assign({
            className: "edit",
            onClick: function onClick() {
              return n(!t);
            }
          }, {
            children: t ? "完成" : "编辑"
          }))
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ss, Object.assign({
          id: "topBar"
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
            scrollY: !0,
            scrollWithAnimation: !0,
            onScrollToLower: c,
            onScrollToUpper: r
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, Object.assign({
              onChange: l,
              style: {
                height: "100%"
              }
            }, {
              children: a.map(function (s) {
                return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Ca, {
                  item: s,
                  edit: t,
                  checked: d
                }, s.collectId);
              })
            })), t ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(h, Object.assign({
              className: "handleBar"
            }, {
              children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(h, Object.assign({
                className: "checkAll"
              }, {
                children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, Object.assign({
                  onChange: g
                }, {
                  children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(u, Object.assign({
                    value: "1",
                    checked: m
                  }, {
                    children: "全选"
                  }))
                }))
              })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(N, Object.assign({
                className: "btn",
                onClick: o
              }, {
                children: "删除"
              }))]
            })) : null]
          }))
        }))]
      }))
    }));
  }),
  ya = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref68) {
    var a = _ref68.noticeId;
    var _i73 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      t = _i73.View,
      n = _i73.Image,
      _T = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useNoticeDetail)(a),
      c = _T.info;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
      className: "noticeDetailContainer"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
        className: "title"
      }, {
        children: c.noticeTitle
      })), c.noticePicurl ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, {
        className: "img",
        mode: "widthFix",
        src: c.noticePicurl
      }) : null, c.noticePicurl1 ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, {
        className: "img",
        mode: "widthFix",
        src: c.noticePicurl1
      }) : null, c.noticePicurl2 ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, {
        className: "img",
        mode: "widthFix",
        src: c.noticePicurl2
      }) : null, c.noticePicurl3 ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, {
        className: "img",
        mode: "widthFix",
        src: c.noticePicurl3
      }) : null, (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
        className: "content"
      }, {
        children: c.noticeContext
      }))]
    }));
  }),
  xa = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref69) {
    var _ref69$doclistId = _ref69.doclistId,
      a = _ref69$doclistId === void 0 ? 2031 : _ref69$doclistId;
    var _L = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useArticleDetail)(a),
      t = _L.info,
      _i74 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      n = _i74.View,
      c = _i74.ScrollView,
      l = t.doclistContent,
      o = t.doclistTitle,
      r = t.doclistTitle4;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
      className: "articleDetail"
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ss, Object.assign({
        id: "a"
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(c, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
            className: "title"
          }, {
            children: o
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
            className: "author"
          }, {
            children: r
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
            className: "content",
            dangerouslySetInnerHTML: {
              __html: l || ""
            }
          })]
        })
      }))
    }));
  }),
  ka = function ka(_ref70) {
    var s = _ref70.address;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: (0,lodash_es__WEBPACK_IMPORTED_MODULE_16__["default"])(s) ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(va, {}) : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(wa, {
        address: s
      })
    });
  },
  wa = function wa(_ref71) {
    var a = _ref71.address;
    var _i75 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      t = _i75.View,
      n = _i75.SmoothView,
      c = _i75.IconMobile,
      l = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(function () {
        var e = a.provinceName,
          s = a.addressDefault,
          t = a.cityName,
          i = a.areaName,
          n = a.addressDetail,
          _a$addressMember = a.addressMember,
          c = _a$addressMember === void 0 ? "" : _a$addressMember,
          _a$addressPhone = a.addressPhone,
          l = _a$addressPhone === void 0 ? "" : _a$addressPhone;
        return {
          addressDefault: "1" === s,
          addressMember: c,
          addressPhone: l,
          address: e + t + i + n
        };
      }, [a]);
    return console.log(46, l.addressDefault), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
      className: "address-info"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, {
        style: {
          fontWeight: 900,
          color: "#444",
          lineHeight: 3.2
        },
        value: "shouhuodizhi"
      }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
        className: "left"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
          className: "left-title"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, {
            children: l.addressMember
          }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
            className: "left-padding"
          }, {
            children: l.addressPhone
          })), l.addressDefault ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
            className: "left-padding left-title-default"
          }, {
            children: "默认"
          })) : null]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
          className: "left-detail"
        }, {
          children: l.address
        }))]
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, {
        value: "xiangyou1",
        style: {
          color: "#444",
          lineHeight: 3,
          textAlign: "right"
        }
      })]
    }));
  },
  va = function va() {
    var _i76 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      t = _i76.View,
      n = _i76.Text;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
        className: "group"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, {
          className: "local"
        }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
          className: "address"
        }, {
          children: "选择收货地址"
        }))]
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, {
        className: "arrow"
      })]
    });
  },
  Ia = function Ia(_ref72) {
    var s = _ref72.refreshNum;
    var _i77 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      a = _i77.View,
      t = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useOrderAddress)(s);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(a, Object.assign({
      className: "placeOrder-chooseAddress",
      onClick: function onClick() {
        return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("addressList");
      }
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ka, {
        address: t
      })
    }));
  },
  Sa = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref73) {
    var a = _ref73.couponStart,
      t = _ref73.pbName,
      n = _ref73.discName,
      c = _ref73.promotionCode,
      l = _ref73.promotionName,
      o = _ref73.couponEnd,
      r = _ref73.disable;
    var _i78 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      d = _i78.View,
      g = _i78.Text,
      m = _i78.Radio;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
      className: "couponItem"
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(d, Object.assign({
        className: "coupon-content"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(d, Object.assign({
          className: "price"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
            className: "symbol"
          }, {
            children: t
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
            className: "num"
          }, {
            children: n
          }))]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(d, Object.assign({
          className: "info"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
            className: "title"
          }, {
            children: l
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(g, Object.assign({
            className: "date"
          }, {
            children: [dayjs__WEBPACK_IMPORTED_MODULE_9___default()(a).format("YYYY-MM-DD"), " - ", dayjs__WEBPACK_IMPORTED_MODULE_9___default()(o).format("YYYY-MM-DD")]
          }))]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, r ? Object.assign({
          className: "coupon-pick-default"
        }, {
          children: "不能用"
        }) : Object.assign({
          className: "choose"
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(m, {
            disabled: r,
            value: c
          })
        }))]
      }))
    }));
  }),
  Aa = function Aa(_ref74) {
    var t = _ref74.refreshNum,
      n = _ref74.goodsNum,
      c = _ref74.skuId,
      l = _ref74.shoppingGoodsId;
    var _i79 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      o = _i79.View,
      r = _i79.Text,
      d = _i79.Popup,
      g = _i79.SmoothRadio,
      m = _i79.ScrollView,
      _R = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useOrderGood)({
        refreshNum: t,
        goodsNum: n,
        skuId: c,
        shoppingGoodsId: l
      }),
      h = _R.amount,
      p = _R.shoppingGoodsList,
      _z = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useOrderCoupon)(p),
      b = _z.coupon,
      u = _z.visible,
      N = _z.setVisible,
      O = _z.selectCoupon,
      j = _z.onChange;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(o, Object.assign({
        className: "coupon-select",
        onClick: function onClick() {
          return N(0 !== b.length);
        }
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
          className: "label"
        }, {
          children: "优惠券"
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(o, Object.assign({
          className: "info"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
            className: "label"
          }, {
            children: O ? "\u5DF2\u9009\u62E9: ".concat(O) : 0 === b.length ? "暂无可用优惠券" : "请选择优惠券"
          })), 0 === b.length ? null : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
            src: ze,
            alt: "",
            className: "icon"
          })]
        }))]
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
        popupVisible: u,
        popupHandler: N
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
          className: "goodsDetail-coupon-popup"
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ss, Object.assign({
            bottomHeight: "300"
          }, {
            children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(m, {
              children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
                onChange: j
              }, {
                children: b.map(function (e, s) {
                  return /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.createElement)(Sa, Object.assign({
                    disable: h < e.discAmount
                  }, e, {
                    key: s
                  }));
                })
              }))
            })
          }))
        }))
      }))]
    });
  },
  Ba = function Ba(_ref75) {
    var _ref75$shippingMethod = _ref75.shippingMethod,
      a = _ref75$shippingMethod === void 0 ? 1 : _ref75$shippingMethod;
    var _i80 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      t = _i80.View;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
      className: "info placeOrder-blcWrap",
      style: 1 === a ? {
        display: "block"
      } : {
        display: "none"
      }
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
        className: "express placeOrder-blcItem"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
          className: "label"
        }, {
          children: "配送方式"
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
          className: "value"
        }, {
          children: "快递"
        }))]
      }))
    }));
  },
  Va = function Va(_ref76) {
    var s = _ref76.refreshNum,
      a = _ref76.goodsNum,
      t = _ref76.skuId,
      n = _ref76.shoppingGoodsId;
    var _i81 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      c = _i81.View,
      _R2 = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useOrderGood)({
        refreshNum: s,
        goodsNum: a,
        skuId: t,
        shoppingGoodsId: n
      }),
      l = _R2.list;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
      className: "place-order-goods"
    }, {
      children: l.map(function (s, a) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(qe, Object.assign({}, s), a);
      })
    }));
  },
  Da = function Da(_ref77) {
    var t = _ref77.refreshNum,
      n = _ref77.goodsNum,
      c = _ref77.skuId,
      l = _ref77.shoppingGoodsId;
    var _i82 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      o = _i82.SmoothView,
      r = _i82.View,
      _R3 = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useOrderGood)({
        refreshNum: t,
        goodsNum: n,
        skuId: c,
        shoppingGoodsId: l
      }),
      d = _R3.payState,
      g = _R3.amount,
      m = _R3.disCount,
      _M = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useOrderInfo)(d),
      h = _M.shoppingCountPrice,
      p = _M.freight,
      b = _M.comDisMoney;
    return console.log(15, b + m, "freight", p), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(r, Object.assign({
        className: "price placeOrder-blcWrap"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
          className: "title"
        }, {
          children: "价格明细"
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(r, Object.assign({
          className: "express placeOrder-blcItem"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
            className: "label"
          }, {
            children: "商品总金额"
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
            className: "value"
          }, {
            children: Ke(h)
          }))]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(r, Object.assign({
          className: "coupon placeOrder-blcItem"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
            className: "label"
          }, {
            children: "优惠金额"
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
            className: "value"
          }, {
            children: Ke(b + m)
          }))]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(r, Object.assign({
          className: "express placeOrder-blcItem"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
            className: "label"
          }, {
            children: "运费"
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
            className: "value"
          }, {
            children: Ke(p)
          }))]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(r, Object.assign({
          className: "all placeOrder-blcItem"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
            className: "label"
          }, {
            children: "总计"
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
            className: "value",
            style: {
              color: "#000"
            }
          }, {
            children: Ke(g - m)
          }))]
        }))]
      }))
    });
  },
  Ta = function Ta(_ref78) {
    var a = _ref78.color,
      t = _ref78.buttonColor,
      n = _ref78.borderColor,
      c = _ref78.borderRadius,
      l = _ref78.refreshNum,
      o = _ref78.goodsNum,
      r = _ref78.skuId,
      d = _ref78.shoppingGoodsId;
    var _i83 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      g = _i83.View,
      m = _i83.Text,
      h = _i83.WrapLoading,
      _R4 = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useOrderGood)({
        refreshNum: l,
        goodsNum: o,
        skuId: r,
        shoppingGoodsId: d
      }),
      p = _R4.amount,
      b = _R4.list,
      u = _R4.disCount,
      N = _R4.payState,
      O = _R4.orderStoreInfo,
      j = _R4.ocContractSettlList,
      _F = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useOrderPay)({
        ocContractSettlList: j,
        payState: N,
        list: b
      }, r, o, O),
      C = _F.savePayPrice,
      f = _F.loading;
    return console.log(36, u), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(g, Object.assign({
      className: "placeOrderFooter"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(m, Object.assign({
        className: "price"
      }, {
        children: ["合计: ", Ke(p - u)]
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(h, Object.assign({
        loading: f
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
          className: "btn",
          onClick: C,
          style: {
            color: "".concat(a),
            border: "1px solid ".concat(n),
            backgroundColor: "".concat(t),
            borderRadius: 1 === c ? "40px" : "0px"
          }
        }, {
          children: "生成订单"
        }))
      }))]
    }));
  },
  La = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)(),
  Pa = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref79) {
    var _ref79$position = _ref79.position,
      s = _ref79$position === void 0 ? 10 : _ref79$position,
      a = _ref79.bg,
      t = _ref79.color,
      n = _ref79.fontSize;
    var _i84 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      c = _i84.View,
      _W = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoTop)(),
      l = _W.goTop;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
      className: "backTop",
      onClick: l
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Os, {
        style: {
          display: "inline-block",
          color: t,
          fontSize: n,
          backgroundColor: a,
          position: La ? "fixed" : "relative",
          right: La ? "20px" : "0",
          bottom: La ? "120px" : "0",
          margin: "0 auto ".concat(s, "px"),
          zIndex: 999
        },
        value: "backtop"
      })
    }));
  }),
  Ra = function Ra(_ref80) {
    var a = _ref80.TextLineBgColor,
      t = _ref80.text,
      n = _ref80.contentSize,
      c = _ref80.lineStyle,
      l = _ref80.fontSize,
      o = _ref80.textAlign,
      r = _ref80.fontColor,
      d = _ref80.lineColor,
      g = _ref80.fontWeight,
      m = _ref80.fontStyle,
      h = _ref80.textDecoration;
    var _i85 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      p = _i85.View;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
      className: "textLine",
      style: {
        backgroundColor: a,
        textAlign: o,
        margin: 1 === n ? "0 10px" : ""
      }
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, {
        className: "blc",
        style: {
          borderBottom: "1px ".concat(c, " ").concat(d)
        }
      }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
        className: "txt",
        style: {
          backgroundColor: a,
          fontWeight: g,
          fontStyle: m,
          textDecoration: h,
          fontSize: "".concat(l, "px"),
          color: r
        }
      }, {
        children: t
      }))]
    }));
  },
  za = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref81) {
    var s = _ref81.borderStyle,
      a = _ref81.borderRadius,
      t = _ref81.height,
      n = _ref81.width,
      c = _ref81.backgroundColor,
      l = _ref81.paddingTop,
      o = _ref81.paddingBottom;
    var _i86 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      r = _i86.View;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
      style: {
        paddingTop: l,
        paddingBottom: o
      }
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, {
        style: {
          borderRadius: a + "%",
          borderStyle: s,
          width: n + "%",
          height: t + "px",
          backgroundColor: c,
          marginLeft: "auto",
          marginRight: "auto"
        }
      })
    }));
  }),
  Ma = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref82) {
    var a = _ref82.defaultValue,
      t = _ref82.borderRadius,
      n = _ref82.paddingTop,
      c = _ref82.paddingBottom,
      l = _ref82.selectClassifyNav;
    var _i87 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      r = _i87.View,
      d = _i87.Text,
      g = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useCube)(a, l);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
      style: {
        paddingTop: n,
        paddingBottom: c
      }
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
        className: "classifyNav"
      }, {
        children: g.map(function (a, i) {
          return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(r, Object.assign({
            className: "classifyNavItem",
            onClick: function onClick() {
              var e, s;
              return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)(null === (e = a.link) || void 0 === e ? void 0 : e.value, null === (s = a.link) || void 0 === s ? void 0 : s.params);
            }
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
              src: a.imgUrl,
              alt: "",
              className: "img",
              style: {
                borderRadius: "".concat(t, "px")
              }
            }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, Object.assign({
              className: "label"
            }, {
              children: a.title
            }))]
          }), i);
        })
      }))
    }));
  }),
  Fa = function Fa(_ref83) {
    var s = _ref83.defaultValue,
      a = _ref83.selectClassifyNav,
      t = _ref83.navRadius,
      n = _ref83.navBorderColor,
      c = _ref83.navBgColor,
      l = _ref83.navBoxShadow,
      r = _ref83.imgRadius,
      d = _ref83.imgBoxShadow,
      g = _ref83.layout,
      m = _ref83.marginTop,
      h = _ref83.marginBottom;
    var _i88 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      p = _i88.View,
      b = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useCube)(s, a);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
      className: "classifyNav-one",
      style: {
        gridTemplateColumns: "repeat(".concat(g, ", 1fr)"),
        borderRadius: t,
        border: "1px solid ".concat(n),
        backgroundColor: c,
        boxShadow: l ? "0px 0px 20px 10px #ddd" : "none",
        marginTop: m,
        marginBottom: h
      }
    }, {
      children: b.map(function (s, a) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
          className: "classifyNav-item",
          onClick: function onClick() {
            var e, a;
            return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)(null === (e = s.link) || void 0 === e ? void 0 : e.value, null === (a = s.link) || void 0 === a ? void 0 : a.params);
          }
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
            src: s.imgUrl,
            alt: "",
            className: "classifyNav-item-img",
            style: {
              borderRadius: r,
              boxShadow: d ? "0px 0px 20px 5px #EEE" : "none"
            }
          })
        }), a);
      })
    }));
  },
  Wa = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(Fa),
  Ga = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref84) {
    var s = _ref84.defaultValue,
      a = _ref84.selectClassifyNav,
      t = _ref84.navRadius,
      n = _ref84.navBorderColor,
      c = _ref84.navBgColor,
      l = _ref84.navBoxShadow,
      r = _ref84.fontSize,
      d = _ref84.fontColor,
      g = _ref84.tagBgColor,
      m = _ref84.otherStyle,
      h = _ref84.layout,
      p = _ref84.marginTop,
      b = _ref84.marginBottom;
    var _i89 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      u = _i89.View,
      N = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useCube)(s, a);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(u, Object.assign({
      className: "classifyNav-two",
      style: {
        gridTemplateColumns: "repeat(".concat(h, ", 1fr)"),
        border: "1px solid ".concat(n),
        borderRadius: t,
        backgroundColor: c,
        boxShadow: l ? "0px 0px 20px 5px #EEE" : "none",
        marginTop: p,
        marginBottom: b
      }
    }, {
      children: N.map(function (s, a) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(u, Object.assign({
          className: "classifyNav-two-item",
          onClick: function onClick() {
            var e, a;
            return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)(null === (e = s.link) || void 0 === e ? void 0 : e.value, null === (a = s.link) || void 0 === a ? void 0 : a.params);
          },
          style: {
            width: 4 === h ? "74px" : "60px"
          }
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(u, Object.assign({
            className: ["classifyNav-two-item-title"].concat((0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_11__["default"])(m)).join(" "),
            style: {
              fontSize: r,
              color: d
            }
          }, {
            children: s.title
          }))
        }), a);
      })
    }));
  }),
  Ea = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref85) {
    var s = _ref85.defaultValue,
      a = _ref85.selectClassifyNav,
      t = _ref85.navRadius,
      n = _ref85.navBorderColor,
      c = _ref85.navBgColor,
      l = _ref85.navBoxShadow,
      r = _ref85.imgRadius,
      d = _ref85.imgBoxShadow,
      g = _ref85.fontSize,
      m = _ref85.fontColor,
      h = _ref85.tagBgColor,
      p = _ref85.otherStyle,
      b = _ref85.layout,
      u = _ref85.marginTop,
      N = _ref85.marginBottom;
    var _i90 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      O = _i90.View,
      j = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useCube)(s, a);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, Object.assign({
      className: "classifyNav-three",
      style: {
        gridTemplateColumns: "repeat(".concat(b, ", 1fr)"),
        border: "1px solid ".concat(n),
        borderRadius: t,
        backgroundColor: c,
        boxShadow: l ? "0px 0px 20px 5px #EEE" : "none",
        marginTop: u,
        marginBottom: N
      }
    }, {
      children: j.map(function (s, a) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, Object.assign({
          className: "classifyNav-three-item",
          onClick: function onClick() {
            var e, a;
            return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)(null === (e = s.link) || void 0 === e ? void 0 : e.value, null === (a = s.link) || void 0 === a ? void 0 : a.params);
          },
          style: {
            backgroundImage: "url(".concat(s.imgUrl, ")"),
            borderRadius: r,
            boxShadow: d ? "0px 0px 20px 5px #EEE" : "none",
            width: 4 === b ? "74px" : "60px",
            height: 4 === b ? "74px" : "60px"
          }
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, Object.assign({
            className: "classifyNav-three-item-tag",
            style: {
              backgroundColor: h
            }
          }, {
            children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, Object.assign({
              className: ["classifyNav-three-item-txt"].concat((0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_11__["default"])(p)).join(" "),
              style: {
                fontSize: g,
                color: m
              }
            }, {
              children: s.title
            }))
          }))
        }), a);
      })
    }));
  }),
  Ha = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref86) {
    var _ref86$defaultValue = _ref86.defaultValue,
      a = _ref86$defaultValue === void 0 ? [] : _ref86$defaultValue,
      _ref86$classCode = _ref86.classCode,
      t = _ref86$classCode === void 0 ? "" : _ref86$classCode,
      n = _ref86.margin,
      _ref86$circular = _ref86.circular,
      c = _ref86$circular === void 0 ? !1 : _ref86$circular,
      l = _ref86.cell,
      _ref86$showSales = _ref86.showSales,
      o = _ref86$showSales === void 0 ? !0 : _ref86$showSales,
      _ref86$gap = _ref86.gap,
      r = _ref86$gap === void 0 ? 10 : _ref86$gap,
      _ref86$goods = _ref86.goods,
      d = _ref86$goods === void 0 ? [] : _ref86$goods,
      g = _ref86.markedPrice,
      m = _ref86.paddingTop,
      h = _ref86.paddingBottom,
      p = _ref86.paddingLeft,
      b = _ref86.paddingRight,
      _ref86$goodsName = _ref86.goodsName,
      u = _ref86$goodsName === void 0 ? !0 : _ref86$goodsName,
      _ref86$goodsPrice = _ref86.goodsPrice,
      N = _ref86$goodsPrice === void 0 ? !0 : _ref86$goodsPrice,
      _ref86$goodsCar = _ref86.goodsCar,
      O = _ref86$goodsCar === void 0 ? !0 : _ref86$goodsCar,
      _ref86$goodsBorder = _ref86.goodsBorder,
      j = _ref86$goodsBorder === void 0 ? !0 : _ref86$goodsBorder,
      _ref86$goodsShadow = _ref86.goodsShadow,
      C = _ref86$goodsShadow === void 0 ? !1 : _ref86$goodsShadow,
      _ref86$marginGap = _ref86.marginGap,
      f = _ref86$marginGap === void 0 ? 10 : _ref86$marginGap;
    var _ne33 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(a),
      _ne34 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_12__["default"])(_ne33, 2),
      y = _ne34[0],
      x = _ne34[1],
      k = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(),
      _i91 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      w = _i91.View,
      v = _i91.Text;
    return (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
      console.log(53, qj_b2c_api__WEBPACK_IMPORTED_MODULE_5__.find, k.current, d), (0,lodash_es__WEBPACK_IMPORTED_MODULE_18__["default"])(k.current, d) || (k.current = d, (0,lodash_es__WEBPACK_IMPORTED_MODULE_16__["default"])(d) ? x(a) : Ye(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_13__["default"])().mark(function _callee5() {
        var _e5;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_13__["default"])().wrap(function _callee5$(_context5) {
          while (1) switch (_context5.prev = _context5.next) {
            case 0:
              _context5.prev = 0;
              _context5.next = 3;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_5__.find)({
                goodsCode: d.toString(),
                distinctField: "goodsNo"
              });
            case 3:
              _e5 = _context5.sent;
              console.log(63, _e5), x(_e5.list);
              _context5.next = 10;
              break;
            case 7:
              _context5.prev = 7;
              _context5.t0 = _context5["catch"](0);
              x(a);
            case 10:
            case "end":
              return _context5.stop();
          }
        }, _callee5, null, [[0, 7]]);
      })));
    }, [d]), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(w, Object.assign({
      style: {
        paddingTop: m,
        paddingBottom: h
      }
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(w, Object.assign({
        className: classnames__WEBPACK_IMPORTED_MODULE_4___default()((0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_19__["default"])({}, "goods-".concat(t), !0)),
        style: {
          display: "grid",
          gap: f,
          marginBottom: n,
          gridTemplateColumns: "repeat(".concat(l, ", 1fr)"),
          paddingLeft: p,
          paddingRight: b
        }
      }, {
        children: y.map(function (a, t) {
          return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(w, Object.assign({
            style: {
              overflow: "hidden",
              borderRadius: c ? "8px" : "0px",
              border: j ? "1px solid #000000" : ""
            },
            onClick: function onClick() {
              return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("goodDetail", {
                skuCode: a.skuCode
              });
            },
            className: ["goods " + (C ? "outer-shadow" : "")].join(" ")
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(w, {
              className: "goods-img",
              style: {
                backgroundImage: "url(".concat(a.dataPic, ")")
              }
            }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(w, Object.assign({
              className: "space"
            }, {
              children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(w, Object.assign({
                className: "titleType",
                style: {
                  display: u ? "block" : "none"
                }
              }, {
                children: a.goodsName
              })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(w, Object.assign({
                className: "subTitle"
              }, {
                children: a.brandName
              })), o && (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(w, Object.assign({
                className: "sales"
              }, {
                children: ["已售:", a.goodsSalesvolume, "件"]
              })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(w, Object.assign({
                className: "price"
              }, {
                children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(w, {
                  children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(v, Object.assign({
                    className: "subPrice",
                    style: {
                      display: N ? "inline" : "none"
                    }
                  }, {
                    children: "¥"
                  })), N ? a.pricesetNprice : "", 1 === g && (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(v, Object.assign({
                    className: "markedPrice"
                  }, {
                    children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(v, Object.assign({
                      className: "subPrice"
                    }, {
                      children: "¥"
                    })), a.pricesetMakeprice]
                  }))]
                }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(w, Object.assign({
                  className: "anticon",
                  style: {
                    display: O ? "block" : "none"
                  }
                }, {
                  children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Os, {
                    style: {
                      fontSize: 30,
                      color: "#f00"
                    },
                    value: "cart"
                  })
                }))]
              }))]
            }))]
          }), t);
        })
      }))
    }));
  }),
  Ya = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref87) {
    var a = _ref87.defaultValue,
      t = _ref87.goods,
      n = _ref87.price,
      c = _ref87.marketPrice,
      l = _ref87.cart,
      o = _ref87.wrapRadius,
      r = _ref87.wrapBorderColor,
      d = _ref87.wrapBgColor,
      g = _ref87.wrapShadow,
      m = _ref87.goodsRadius,
      h = _ref87.goodsBgColor,
      p = _ref87.goodsGap,
      b = _ref87.marginTop,
      u = _ref87.marginBottom,
      N = _ref87.marginLeft,
      O = _ref87.marginRight;
    var _i92 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      j = _i92.View,
      _G = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoods)({
        defaultValue: a,
        goods: t
      }),
      C = _G.list;
    return console.log(12, C), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(j, Object.assign({
      className: "goodsSlider",
      style: {
        borderRadius: o,
        borderColor: r,
        backgroundColor: d,
        boxShadow: g ? "0px 0px 20px 5px #EEE" : "none",
        marginTop: b,
        marginBottom: u,
        marginLeft: N,
        marginRight: O
      }
    }, {
      children: C.map(function (a, t) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(j, Object.assign({
          className: "goodsSliderItem",
          style: {
            borderRadius: m,
            backgroundColor: h,
            marginRight: "".concat(p, "px")
          },
          onClick: function onClick() {
            return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("goodDetail", {
              skuCode: a.skuCode
            });
          }
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(j, {
            className: "img",
            style: {
              backgroundImage: "url(".concat(a.dataPic, ")")
            }
          }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(j, Object.assign({
            className: "board"
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(j, Object.assign({
              className: "title"
            }, {
              children: a.goodsName
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(j, Object.assign({
              className: "info"
            }, {
              children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(j, Object.assign({
                className: "lPart"
              }, {
                children: [n ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(j, Object.assign({
                  className: "price"
                }, {
                  children: ["￥", a.pricesetNprice]
                })) : null, c ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(j, Object.assign({
                  className: "marketPrice"
                }, {
                  children: ["￥", a.pricesetMakeprice]
                })) : null]
              })), l ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(j, Object.assign({
                className: "rPart"
              }, {
                children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Os, {
                  style: {
                    fontSize: 26,
                    color: "#f00"
                  },
                  value: "cart"
                })
              })) : null]
            }))]
          }))]
        }), t);
      })
    }));
  }),
  Ua = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)(),
  Qa = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref88) {
    var a = _ref88.defaultValue,
      t = _ref88.goods,
      n = _ref88.GoodsSlideshowBg,
      c = _ref88.marketPrice,
      l = _ref88.goodsName,
      o = _ref88.salesNum,
      r = _ref88.price,
      d = _ref88.goodsRadius,
      g = _ref88.goodsBorder,
      m = _ref88.goodsShadow,
      h = _ref88.btnText,
      p = _ref88.btnBg,
      b = _ref88.btnColor,
      u = _ref88.btnRadius;
    var _G2 = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoods)({
        defaultValue: a,
        goods: t
      }),
      N = _G2.list,
      _i93 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      O = _i93.SmoothSwiper,
      j = _i93.View,
      C = _i93.Image,
      _ne35 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0),
      _ne36 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_12__["default"])(_ne35, 2),
      f = _ne36[0],
      y = _ne36[1];
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(j, Object.assign({
      className: "goodsSlideshow"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(C, {
        src: n,
        className: "bg",
        mode: "widthFix"
      }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(O, {
        indicatorDots: !1,
        imgHeight: {
          width: 190,
          height: 410
        },
        defaultIndex: 1,
        data: N,
        style: {},
        type: 1,
        autoplay: !1,
        autoplayInterval: 5e3,
        onChange: function onChange(e) {
          y(e.detail.current);
        },
        previousMargin: 40,
        nextMargin: 40,
        slideSize: 70,
        trackOffset: 15,
        render: function render(a) {
          return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(j, Object.assign({
            className: ["goodsSlideshowItem", "" + (a.goodsCode === N[f].goodsCode && Ua ? "active" : "")].join(" "),
            style: {
              borderRadius: d,
              borderStyle: g ? "solid" : "none",
              boxShadow: m ? "0px 0px 20px 10px #ddd" : ""
            },
            onClick: function onClick() {
              return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("goodDetail", {
                skuCode: a.skuCode
              });
            }
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(C, {
              className: "logo",
              src: a.dataPic,
              mode: "widthFix"
            }), l ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(j, Object.assign({
              className: "goodsName"
            }, {
              children: a.goodsShowname
            })) : null, o ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(j, Object.assign({
              className: "salesNum"
            }, {
              children: ["销量：", a.goodsSalesvolume]
            })) : null, r ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(j, Object.assign({
              className: "price"
            }, {
              children: ["￥", a.pricesetNprice]
            })) : null, c ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(j, Object.assign({
              className: "marketPrice"
            }, {
              children: ["￥", a.pricesetMakeprice]
            })) : null, (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(j, Object.assign({
              className: "btn",
              style: {
                backgroundColor: p,
                color: b,
                borderRadius: u
              }
            }, {
              children: h
            }))]
          }));
        }
      })]
    }));
  }),
  Ka = function Ka(_ref89) {
    var s = _ref89.skuCode,
      a = _ref89.autoplay,
      t = _ref89.vertical;
    var _E = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoodDetail)(s),
      _E$rsGoodsFileDomainL = _E.rsGoodsFileDomainList,
      i = _E$rsGoodsFileDomainL === void 0 ? [] : _E$rsGoodsFileDomainL,
      n = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useBanner)(i);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Ge, {
      selectImg: n,
      type: 1,
      autoplay: a,
      vertical: t,
      imgHeight: {
        height: 375,
        width: 375
      }
    });
  },
  qa = function qa(a) {
    var _i94 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      t = _i94.SmoothView,
      n = _i94.View,
      _Y = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoodCollection)(a),
      c = _Y.handleCollect,
      l = _Y.collection;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(n, Object.assign({
      onClick: c
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
        src: Re,
        alt: "",
        className: "icon"
      }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
        className: "txt"
      }, {
        children: (0,lodash_es__WEBPACK_IMPORTED_MODULE_16__["default"])(l.dataObj) ? "收藏" : "已收藏"
      }))]
    }));
  },
  Za = function Za(_ref90) {
    var a = _ref90.skuCode,
      t = _ref90.priceShow,
      n = _ref90.collectionShow;
    var _i95 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      c = _i95.View,
      l = _i95.SmoothView,
      _E2 = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoodDetail)(a),
      o = _E2.goodsName,
      r = _E2.pricesetNprice,
      d = _E2.dataPic;
    return (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoodFootprint)(a), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(c, Object.assign({
      className: "goodsDetail-topInfo"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(c, Object.assign({
        className: "lPart"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, Object.assign({
          className: "name"
        }, {
          children: o
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, Object.assign({
          className: "price",
          style: {
            display: t ? "block" : "none"
          }
        }, {
          children: Ke(r)
        }))]
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
        className: "rPart",
        style: {
          display: n ? "flex" : "none"
        }
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(qa, {
          goodsName: o,
          pricesetNprice: r,
          dataPic: d,
          skuCode: a
        })
      }))]
    }));
  },
  Xa = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (a) {
    var t = a.collectionShow,
      n = a.shareShow,
      _i96 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      c = _i96.View,
      _Y2 = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoodCollection)(a),
      l = _Y2.handleCollect,
      o = _Y2.collection,
      _Q = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoodsShare)(),
      r = _Q.handleShare;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(c, Object.assign({
      className: "handleBar"
    }, {
      children: [t ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
        className: "collection",
        onClick: l,
        style: {
          borderRight: n ? "1px solid #ddd" : "none"
        }
      }, {
        children: (0,lodash_es__WEBPACK_IMPORTED_MODULE_16__["default"])(o.dataObj) ? "收藏" : "已收藏"
      })) : null, n ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
        className: "share",
        onClick: r
      }, {
        children: "分享"
      })) : null]
    }));
  }),
  $a = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref91) {
    var a = _ref91.skuCode,
      t = _ref91.priceShow,
      n = _ref91.collectionShow,
      c = _ref91.shareShow;
    var _i97 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      l = _i97.View,
      o = _i97.SmoothView,
      _E3 = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoodDetail)(a),
      r = _E3.goodsName,
      d = _E3.pricesetNprice,
      g = _E3.dataPic;
    return (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoodFootprint)(a), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(l, Object.assign({
      className: "goodsDetail-info-one"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
        className: "price",
        style: {
          display: t ? "block" : "none"
        }
      }, {
        children: Ke(d)
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
        className: "title"
      }, {
        children: r
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Xa, {
        collectionShow: n,
        shareShow: c,
        goodsName: r,
        pricesetNprice: d,
        dataPic: g,
        skuCode: a
      })]
    }));
  }),
  Ja = function Ja() {
    var _i98 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      e = _i98.Text,
      a = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoodSkuStore)(function (e) {
        return e.count;
      }),
      t = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoodSkuStore)(function (e) {
        return e.spec;
      });
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(e, Object.assign({
      className: "label"
    }, {
      children: ["已选择 数量: ", a, " 规格: ", t.toString()]
    }));
  },
  _a = function _a() {
    var _i99 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      t = _i99.View,
      n = _i99.Text,
      _K = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.popupImplement)(),
      c = _K.openPopup;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
        className: "goodsDetail-size",
        onClick: c
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
          className: "label"
        }, {
          children: "规格"
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
          className: "info"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Ja, {}), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
            src: ze,
            alt: "",
            className: "icon"
          })]
        }))]
      }))
    });
  },
  et = function et(_ref92) {
    var a = _ref92.skuCode;
    var _i100 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      t = _i100.View,
      n = _i100.Text,
      c = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.usePromotion)(a);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
      className: "goodsDetail-promotion"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
        className: "label"
      }, {
        children: "促销"
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
        className: "group"
      }, {
        children: c.length ? c.map(function (_ref93, a) {
          var s = _ref93.discName;
          return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
            className: "item"
          }, {
            children: s
          }), a);
        }) : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
          className: "noPromotion"
        }, {
          children: "暂无促销活动"
        }))
      }))]
    }));
  },
  st = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref94) {
    var a = _ref94.promotionBegintime,
      t = _ref94.pbName,
      n = _ref94.discName,
      c = _ref94.promotionCode,
      l = _ref94.promotionName,
      o = _ref94.couponOnceNums,
      r = _ref94.couponOnceNumd,
      d = _ref94.promotionEndtime;
    var _i101 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      g = _i101.View,
      m = _i101.Text,
      _X = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useAddCoupon)(),
      h = _X.save,
      p = _X.isPick,
      b = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(function () {
        return o - r;
      }, [o, r]);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
      className: "couponItem"
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(g, Object.assign({
        className: "coupon-content"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(g, Object.assign({
          className: "price"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
            className: "symbol"
          }, {
            children: t
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
            className: "num"
          }, {
            children: n
          }))]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(g, Object.assign({
          className: "info"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(m, Object.assign({
            className: "title"
          }, {
            children: l
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(m, Object.assign({
            className: "date"
          }, {
            children: [dayjs__WEBPACK_IMPORTED_MODULE_9___default()(a).format("YYYY-MM-DD"), " - ", dayjs__WEBPACK_IMPORTED_MODULE_9___default()(d).format("YYYY-MM-DD")]
          }))]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, b > 0 ? Object.assign({
          className: p ? "coupon-pick-default" : "coupon-pick",
          onClick: function onClick() {
            return h({
              promotionCode: c,
              couponAmount: 1
            });
          }
        }, {
          children: p ? "已领取" : "领取"
        }) : Object.assign({
          className: "coupon-pick-default"
        }, {
          children: "已领完"
        }))]
      }))
    }));
  }),
  at = function at(_ref95) {
    var t = _ref95.skuCode;
    var _i102 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      n = _i102.View,
      c = _i102.Text,
      l = _i102.Popup,
      _$ = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useCoupon)(t),
      o = _$.coupon,
      r = _$.visible,
      d = _$.setVisible;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(n, Object.assign({
        className: "goodsDetail-coupon",
        onClick: function onClick() {
          return d(!0);
        }
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
          className: "label"
        }, {
          children: "优惠券"
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(n, Object.assign({
          className: "info"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
            className: "label"
          }, {
            children: "请选择优惠券"
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
            src: ze,
            alt: "",
            className: "icon"
          })]
        }))]
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, Object.assign({
        popupVisible: r,
        popupHandler: d
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
          className: "goodsDetail-coupon-popup"
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ss, {
            children: o.map(function (e, s) {
              return /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.createElement)(st, Object.assign({}, e, {
                key: s
              }));
            })
          })
        }))
      }))]
    });
  },
  tt = function tt(_ref96) {
    var a = _ref96.item;
    var _i103 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      t = _i103.View,
      n = _i103.Image;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
      className: "rateItem"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
        className: "topInfo"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
          className: "lPart"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, {
            src: a.userImgurl,
            className: "avatar"
          }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
            className: "userInfo"
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
              className: "name"
            }, {
              children: a.userName
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Is, {
              readOnly: !0,
              size: 14,
              count: a.evaluateScopeReList.length
            })]
          }))]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
          className: "rPart"
        }, {
          children: "".concat(new Date(a.gmtCreate).getFullYear(), "-").concat(new Date(a.gmtCreate).getMonth() + 1, "-").concat(new Date(a.gmtCreate).getDate())
        }))]
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
        className: "size"
      }, {
        children: a.skuName
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
        className: "content"
      }, {
        children: a.evaluateGoodsContent
      }))]
    }));
  },
  it = function it(_ref97) {
    var a = _ref97.evaluateArr;
    var _i104 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      t = _i104.View,
      n = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(a);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
      className: "goodsDetailEvaluate"
    }, {
      children: n.current.length ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
          className: "topInfo"
        }, {
          children: ["评价 (", n.current.length, ")"]
        })), n.current.slice(0, 5).map(function (s, a) {
          return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(tt, {
            item: s
          }, a);
        })]
      }) : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Ps, {
        style: {
          margin: "100px auto"
        },
        url: "https://brushes.oss-cn-shanghai.aliyuncs.com/static/mini/noEvaluate.png",
        title: "还没有评价, 期待您的评价"
      })
    }));
  },
  nt = function nt(_ref98) {
    var s = _ref98.goodsRemark;
    var _i105 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      a = _i105.View,
      t = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(function () {
        return s.replace(/<style>[\s\S]*<\/style>/gi, "").replace(/<img/gi, '<img class="mystyle" mode="widthFix"').replace(/<!--[\s\S]*-->/gi, "");
      }, [s]);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(a, Object.assign({
      className: "goodsDetail-info"
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        dangerouslySetInnerHTML: {
          __html: t || ""
        }
      })
    }));
  },
  ct = function ct(_ref99) {
    var t = _ref99.tabActive,
      n = _ref99.setTabActive,
      c = _ref99.evaluateShow,
      l = _ref99.evaluateImgShow,
      o = _ref99.evaluateImg;
    var _i106 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      r = _i106.Text;
    console.log(15, c, l, o);
    var d = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(function () {
      return l ? [{
        title: "商品详情",
        id: "1"
      }, {
        title: "评价",
        id: "2"
      }] : [{
        title: "商品详情",
        id: "1"
      }];
    }, [c]);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: d.map(function (a, i) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(r, Object.assign({
            className: "tabsItem " + (t === i ? "active" : ""),
            onClick: function onClick() {
              return n(i);
            }
          }, {
            children: [a.title, (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, {
              className: "line"
            })]
          }))
        }, i);
      })
    });
  },
  lt = function lt(_ref100) {
    var a = _ref100.skuCode,
      t = _ref100.evaluateShow,
      n = _ref100.evaluateImgShow,
      c = _ref100.evaluateImg;
    var _i107 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      l = _i107.View,
      _ne37 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0),
      _ne38 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_12__["default"])(_ne37, 2),
      o = _ne38[0],
      r = _ne38[1],
      _E4 = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoodDetail)(a),
      d = _E4.goodsRemark,
      g = _E4.goodsCode,
      m = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useEvaluate)(g);
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(l, Object.assign({
      className: "goodsDetailTab"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, Object.assign({
        className: "tabs"
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ct, {
          tabActive: o,
          setTabActive: r,
          evaluateShow: t,
          evaluateImgShow: n,
          evaluateImg: c
        })
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, Object.assign({
        className: "group"
      }, {
        children: 0 === o ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(nt, {
          goodsRemark: d
        }) : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(it, {
          evaluateArr: m,
          evaluateImgShow: n,
          evaluateImg: c
        })
      }))]
    }));
  },
  ot = function ot(_ref101) {
    var a = _ref101.skuName,
      t = _ref101.handleChooseSize,
      n = _ref101.spec,
      c = _ref101.skuOption,
      l = _ref101.index;
    var _i108 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      o = _i108.View,
      r = _i108.Text;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(o, Object.assign({
      className: "sizeArr"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r, Object.assign({
        className: "title"
      }, {
        children: a
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
        className: "sizeArrItemWrap"
      }, {
        children: c.map(function (s, a) {
          return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
            className: "sizeItem " + (n[l] === s.specValueValue ? "active" : ""),
            onClick: t.bind(null, s.specValueValue, l)
          }, {
            children: s.specValueValue
          }), a);
        })
      }))]
    }));
  },
  rt = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref102) {
    var a = _ref102.handleStep;
    var _i109 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      t = _i109.View,
      n = _i109.NumStep,
      c = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoodSkuStore)(function (e) {
        return e.count;
      });
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
      className: "countWrap"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
        className: "label"
      }, {
        children: "购买数量"
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, {
        count: c,
        handleStep: a
      })]
    }));
  }),
  dt = function dt(_ref103) {
    var t = _ref103.skuInfo,
      n = _ref103.handleChooseSize;
    var _t$goodsShowname = t.goodsShowname,
      c = _t$goodsShowname === void 0 ? {} : _t$goodsShowname,
      l = t.pricesetNprice,
      o = t.dataPic,
      r = t.skuList,
      _i110 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      d = _i110.Image,
      g = _i110.View,
      m = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoodSkuStore)(function (e) {
        return e.spec;
      });
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(g, Object.assign({
        className: "goodsInfo"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
          className: "lPart"
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, {
            src: o,
            alt: "",
            className: "goodsImg"
          })
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(g, Object.assign({
          className: "rPart"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
            className: "name"
          }, {
            children: c
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
            className: "price"
          }, {
            children: Ke(l)
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(g, Object.assign({
            className: "chosen"
          }, {
            children: ["已选择: ", m.toString()]
          }))]
        }))]
      })), r.map(function (s, a) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ot, {
          spec: m,
          handleChooseSize: n,
          index: a,
          skuName: s.skuName,
          skuOption: s.skuOption
        }, a);
      })]
    });
  },
  gt = function gt(_ref104) {
    var t = _ref104.cashImpl,
      n = _ref104.addShoppingImpl,
      c = _ref104.addCardImpl;
    var _i111 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      l = _i111.Text,
      o = _i111.View,
      r = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoodSkuStore)(function (e) {
        return e.isNeedButton;
      });
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: r ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
        className: "btnWrap",
        onClick: n
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(l, Object.assign({
          className: "btn"
        }, {
          children: "确认"
        }))
      })) : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(o, Object.assign({
        className: "goods-detail-btn-group popup-buy-button"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
          className: "btn addCart",
          onClick: c
        }, {
          children: "加入购物车"
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(o, Object.assign({
          className: "btn buy",
          onClick: t
        }, {
          children: "立即购买"
        }))]
      }))
    });
  },
  mt = function mt(_ref105) {
    var a = _ref105.goodsCode,
      t = _ref105.skuInfo;
    var _i112 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      n = _i112.View,
      c = _i112.Popup,
      _ref106 = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useAddShopping)(a, t),
      l = _ref106.handleChooseSize,
      o = _ref106.handleStep,
      r = _ref106.addCardImpl,
      d = _ref106.cashImpl,
      g = _ref106.addShoppingImpl,
      m = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoodSkuStore)(function (e) {
        return e.popupVisible;
      }),
      _K2 = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.popupImplement)(),
      h = _K2.closePopup;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(c, Object.assign({
      popupVisible: m,
      popupHandler: h
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(n, Object.assign({
        className: "goodsDetail-size-popup"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(n, Object.assign({
          className: "content"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(dt, {
            skuInfo: t,
            handleChooseSize: l
          }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(rt, {
            handleStep: o
          })]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(gt, {
          cashImpl: d,
          addShoppingImpl: g,
          addCardImpl: r
        })]
      }))
    }));
  },
  ht = function ht(_ref107) {
    var t = _ref107.skuCode,
      n = _ref107.serverShow,
      c = _ref107.cartShow,
      l = _ref107.lPartColor,
      o = _ref107.lPartBgColor,
      r = _ref107.lPartStyle,
      d = _ref107.rPartColor,
      g = _ref107.rPartBgColor,
      m = _ref107.rPartStyle;
    var _i113 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      h = _i113.Text,
      p = _i113.View,
      b = _i113.IconMobile,
      _ee = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoodSku)(t),
      u = _ee.skuInfo,
      N = _ee.goodsCode,
      _Qe2 = Qe(),
      O = _Qe2.servicePopup,
      _K3 = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.popupImplement)(),
      j = _K3.addCardPopup,
      C = _K3.buyOpenPopup;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
        className: "goodsDetailHandleBar"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
          className: "linkGroup server",
          onClick: O,
          style: {
            display: n ? "block" : "none"
          }
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, {
            value: "kefu",
            style: {
              fontSize: 22,
              display: "block"
            }
          }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(h, Object.assign({
            className: "txt"
          }, {
            children: "客服"
          }))]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
          className: "linkGroup cart",
          onClick: function onClick() {
            return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("shopping");
          },
          style: {
            display: c ? "block" : "none"
          }
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, {
            value: "gouwuche",
            style: {
              fontSize: 22,
              display: "block"
            }
          }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(h, Object.assign({
            className: "txt"
          }, {
            children: "购物车"
          }))]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
          className: "goods-detail-btn-group"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
            className: "btn addCart",
            onClick: j,
            style: {
              color: l,
              backgroundColor: o,
              borderTopLeftRadius: r,
              borderBottomLeftRadius: r
            }
          }, {
            children: "加入购物车"
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
            onClick: C,
            className: "btn buy",
            style: {
              color: d,
              backgroundColor: g,
              borderTopRightRadius: m,
              borderBottomRightRadius: m
            }
          }, {
            children: "立即购买"
          }))]
        }))]
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(mt, {
        goodsCode: N,
        skuInfo: u
      })]
    });
  },
  pt = function pt(_ref108) {
    var t = _ref108.skuCode,
      n = _ref108.serverShow,
      c = _ref108.cartShow,
      l = _ref108.lBtnBorderColor,
      o = _ref108.lBtnFontColor,
      r = _ref108.lBtnColor,
      d = _ref108.lBtnStyle,
      g = _ref108.rBtnBorderColor,
      m = _ref108.rBtnFontColor,
      h = _ref108.rBtnColor,
      p = _ref108.rBtnStyle;
    var _i114 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      b = _i114.Text,
      u = _i114.View,
      N = _i114.IconMobile,
      _ee2 = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useGoodSku)(t),
      O = _ee2.skuInfo,
      j = _ee2.goodsCode,
      _Qe3 = Qe(),
      C = _Qe3.servicePopup,
      _K4 = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.popupImplement)(),
      f = _K4.addCardPopup,
      y = _K4.buyOpenPopup;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(u, Object.assign({
        className: "goodsDetailHandleBarOne"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(u, Object.assign({
          className: "linkGroup server",
          onClick: C,
          style: {
            display: n ? "block" : "none"
          }
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(N, {
            value: "kefu",
            style: {
              fontSize: 22,
              display: "block"
            }
          }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, Object.assign({
            className: "txt"
          }, {
            children: "客服"
          }))]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(u, Object.assign({
          className: "linkGroup cart",
          onClick: function onClick() {
            return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("shopping");
          },
          style: {
            display: c ? "block" : "none"
          }
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(N, {
            value: "gouwuche",
            style: {
              fontSize: 22,
              display: "block"
            }
          }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, Object.assign({
            className: "txt"
          }, {
            children: "购物车"
          }))]
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(u, Object.assign({
          className: "goods-detail-one-btn-group"
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(u, Object.assign({
            className: "btn addCart",
            onClick: f,
            style: {
              border: "1px solid ".concat(l),
              color: o,
              backgroundColor: r,
              borderRadius: 1 === d ? "20px" : "0"
            }
          }, {
            children: "加入购物车"
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(u, Object.assign({
            onClick: y,
            className: "btn buy",
            style: {
              border: "1px solid ".concat(g),
              color: m,
              backgroundColor: h,
              borderRadius: 1 === p ? "20px" : "0"
            }
          }, {
            children: "立即购买"
          }))]
        }))]
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(mt, {
        goodsCode: j,
        skuInfo: O
      })]
    });
  },
  bt = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref109) {
    var a = _ref109.defaultValue,
      t = _ref109.coupons,
      n = _ref109.bg,
      c = _ref109.borderColor,
      l = _ref109.btnColor,
      o = _ref109.typeColor,
      r = _ref109.titleColor,
      d = _ref109.ruleColor,
      g = _ref109.timeColor,
      m = _ref109.paddingTop,
      h = _ref109.paddingBottom;
    var _i115 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      p = _i115.View,
      _se = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useAllCoupon)({
        defaultValue: a,
        coupons: t
      }),
      b = _se.list,
      u = _se.takeCoupon,
      N = _se.got;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
      style: {
        paddingTop: "".concat(m, "px"),
        paddingBottom: "".concat(h, "px")
      }
    }, {
      children: b.map(function (a, t) {
        var i = (0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(a, "pbName"),
          m = (0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(a, "pmPromotionDiscountList"),
          h = (0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(m.at(-1), "discName"),
          b = (0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(a, "promotionName"),
          O = dayjs__WEBPACK_IMPORTED_MODULE_9___default()((0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(a, "promotionBegintime")).format("YYYY-MM-DD"),
          j = dayjs__WEBPACK_IMPORTED_MODULE_9___default()((0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(a, "promotionEndtime")).format("YYYY-MM-DD"),
          C = (0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(a, "promotionCode");
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
          className: "OneLineOneBlc",
          style: {
            backgroundColor: n,
            borderColor: c
          }
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
            className: "lPart"
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
              className: "intro"
            }, {
              children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
                className: "type",
                style: {
                  color: o
                }
              }, {
                children: i
              })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
                className: "rule",
                style: {
                  color: d
                }
              }, {
                children: h
              }))]
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
              className: "info"
            }, {
              children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
                className: "title",
                style: {
                  color: r
                }
              }, {
                children: b
              })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(p, Object.assign({
                className: "validity",
                style: {
                  color: g
                }
              }, {
                children: [O, " - ", j]
              }))]
            }))]
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
            className: "rPart",
            style: {
              backgroundColor: l
            }
          }, {
            children: -1 === a.availabledate ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
              className: "txt"
            }, {
              children: "已 领 取"
            })) : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(p, Object.assign({
              className: "txt",
              onClick: function onClick() {
                return u({
                  promotionCode: C,
                  couponAmount: 1
                });
              }
            }, {
              children: N ? "已 领 取" : "立 即 领 取"
            }))
          }))]
        }), t);
      })
    }));
  }),
  ut = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref110) {
    var a = _ref110.defaultValue,
      t = _ref110.coupons,
      n = _ref110.bg,
      c = _ref110.borderColor,
      l = _ref110.btnColor,
      o = _ref110.typeColor,
      r = _ref110.ruleColor,
      d = _ref110.titleColor,
      g = _ref110.timeColor,
      m = _ref110.gap,
      h = _ref110.paddingTop,
      p = _ref110.paddingBottom;
    var _i116 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      b = _i116.View,
      _se2 = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useAllCoupon)({
        defaultValue: a,
        coupons: t
      }),
      u = _se2.list,
      N = _se2.takeCoupon,
      O = _se2.got;
    return console.log(39, u), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, Object.assign({
      className: "oneLineTwoBlc",
      style: {
        paddingTop: h,
        paddingBottom: p,
        paddingLeft: "10px",
        paddingRight: "10px",
        gap: m
      }
    }, {
      children: u.map(function (a, t) {
        var i = (0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(a, "pbName"),
          m = (0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(a, "pmPromotionDiscountList"),
          h = (0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(m.at(-1), "discName"),
          p = (0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(a, "promotionName"),
          u = dayjs__WEBPACK_IMPORTED_MODULE_9___default()((0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(a, "promotionBegintime")).format("YYYY-MM-DD"),
          j = dayjs__WEBPACK_IMPORTED_MODULE_9___default()((0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(a, "promotionEndtime")).format("YYYY-MM-DD"),
          C = (0,lodash_es__WEBPACK_IMPORTED_MODULE_15__["default"])(a, "promotionCode");
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(b, Object.assign({
          className: "oneLineTwoBlcItem",
          style: {
            backgroundColor: n,
            borderColor: c
          }
        }, {
          children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(b, Object.assign({
            className: "lPart"
          }, {
            children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, Object.assign({
              className: "type",
              style: {
                color: o
              }
            }, {
              children: i
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, Object.assign({
              className: "rule",
              style: {
                color: r
              }
            }, {
              children: h
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, Object.assign({
              className: "info",
              style: {
                color: d
              }
            }, {
              children: p
            })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(b, Object.assign({
              className: "validity",
              style: {
                color: g
              }
            }, {
              children: [u, " - ", j]
            }))]
          })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, Object.assign({
            className: "rPart",
            style: {
              backgroundColor: l
            }
          }, {
            children: -1 === a.availabledate ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, Object.assign({
              className: "txt"
            }, {
              children: "已 领 取"
            })) : (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(b, Object.assign({
              className: "txt",
              onClick: function onClick() {
                return N({
                  promotionCode: C,
                  couponAmount: 1
                });
              }
            }, {
              children: O ? "已 领 取" : "立 即 领 取"
            }))
          }))]
        }), t);
      })
    }));
  }),
  Nt = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (a) {
    var _a$type = a.type,
      t = _a$type === void 0 ? 1 : _a$type,
      _a$coupons = a.coupons,
      n = _a$coupons === void 0 ? [] : _a$coupons,
      c = He(a, ["type", "coupons"]);
    var _i117 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      l = _i117.View;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(l, Object.assign({
      className: "getCouponOne"
    }, {
      children: [1 === t ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(bt, Object.assign({
        coupons: n
      }, c)) : null, 2 === t ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ut, Object.assign({
        coupons: n
      }, c)) : null]
    }));
  }),
  Ot = [{
    label: "全部",
    val: "0002,0006"
  }, {
    label: "满减",
    val: "0002"
  }, {
    label: "满折",
    val: "0006"
  }],
  jt = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref111) {
    var s = _ref111.activeColor,
      a = _ref111.setParams,
      t = _ref111.params;
    var _i118 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      n = _i118.View;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
      className: "promotionListTab"
    }, {
      children: Ot.map(function (i, c) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(n, Object.assign({
          className: "promotionListTabItem",
          onClick: function onClick() {
            return a(i.val);
          },
          style: {
            color: i.val === t ? s : "#000"
          }
        }, {
          children: i.label
        }), c);
      })
    }));
  }),
  Ct = function Ct(_ref112) {
    var a = _ref112.data;
    var _i119 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      t = _i119.View,
      n = a.pbName,
      c = a.promotionName,
      l = a.pmPromotionDiscountList,
      o = a.promotionBegintime,
      r = a.promotionEndtime;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
      className: "promotionItem"
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
        className: "lPart"
      }, {
        children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, {
          className: "round"
        }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
          className: "tagBg"
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
            className: "txt"
          }, {
            children: ["官方", n]
          }))
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
          className: "rule"
        }, {
          children: l.at(-1).discName
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
          className: "title"
        }, {
          children: c
        })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(t, Object.assign({
          className: "time"
        }, {
          children: [dayjs__WEBPACK_IMPORTED_MODULE_9___default()(o).format("YYYY-MM-DD"), " ~ ", dayjs__WEBPACK_IMPORTED_MODULE_9___default()(r).format("YYYY-MM-DD")]
        }))]
      })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, Object.assign({
        className: "rPart"
      }, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(t, {
          className: "sideBorder"
        })
      }))]
    }));
  },
  ft = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function (_ref113) {
    var a = _ref113.activeColor,
      t = _ref113.paddingTop,
      n = _ref113.paddingBottom;
    var _ne39 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(Ot[0].val),
      _ne40 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_12__["default"])(_ne39, 2),
      c = _ne40[0],
      l = _ne40[1],
      _ae = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_1__.useMarketingPromotion)({
        params: c
      }),
      o = _ae.list,
      r = _ae.getData,
      _i120 = (0,_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_10__.useComponent)(),
      d = _i120.View,
      g = _i120.ScrollView;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(d, Object.assign({
      style: {
        padding: "".concat(t, "px 0 ").concat(n, "px")
      }
    }, {
      children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(jt, {
        activeColor: a,
        setParams: l,
        params: c
      }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(d, {
        children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ss, Object.assign({
          id: "listWrap"
        }, {
          children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(g, Object.assign({
            onScroll: function onScroll() {
              return r();
            }
          }, {
            children: o.map(function (s, a) {
              return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Ct, {
                data: s
              }, a);
            })
          }))
        }))
      })]
    }));
  }),
  yt = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(function () {
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: "123"
    });
  });


/***/ }),

/***/ "./src/account/components/accountForm/components/accountItem/index.tsx":
/*!*****************************************************************************!*\
  !*** ./src/account/components/accountForm/components/accountItem/index.tsx ***!
  \*****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccountItem": function() { return /* binding */ AccountItem; }
/* harmony export */ });
/* harmony import */ var antd_mobile__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! antd-mobile */ "./node_modules/antd-mobile/es/index.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "webpack/container/remote/react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);


var AccountItem = function AccountItem(_ref) {
  var _ref$txt = _ref.txt,
    txt = _ref$txt === void 0 ? '账号' : _ref$txt;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(antd_mobile__WEBPACK_IMPORTED_MODULE_0__.Form.Item, {
    name: "account",
    rules: [{
      required: true,
      message: "".concat(txt, "\u4E0D\u80FD\u4E3A\u7A7A")
    }],
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(antd_mobile__WEBPACK_IMPORTED_MODULE_0__.Input, {
      clearable: true,
      placeholder: "\u8BF7\u8F93\u5165".concat(txt)
    })
  });
};

/***/ }),

/***/ "./src/account/components/accountForm/components/codeItem/components/codeWrap/index.tsx":
/*!**********************************************************************************************!*\
  !*** ./src/account/components/accountForm/components/codeItem/components/codeWrap/index.tsx ***!
  \**********************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CodeWrap": function() { return /* binding */ CodeWrap; }
/* harmony export */ });
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js */ "./node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/container/remote/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/plugin-platform-weapp/dist/components-react.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/utils */ "./src/utils/index.ts");
/* harmony import */ var qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! qj-b2c-api */ "./node_modules/qj-b2c-api/dist/index.js");
/* harmony import */ var _brushes_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @brushes/utils */ "./node_modules/@brushes/utils/dist/index.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-runtime */ "webpack/container/remote/react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);










var seconds = 60;
var CodeWrap = function CodeWrap(_ref) {
  var form = _ref.form,
    type = _ref.type;
  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false),
    _useState2 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_useState, 2),
    timeFlag = _useState2[0],
    setTimeFlag = _useState2[1];
  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(seconds),
    _useState4 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_useState3, 2),
    time = _useState4[0],
    setTime = _useState4[1];
  var timeRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false),
    _useState6 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_useState5, 2),
    lock = _useState6[0],
    setLock = _useState6[1];
  var getMobile = /*#__PURE__*/function () {
    var _ref2 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_6__["default"])( /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_7__["default"])().mark(function _callee() {
      var mobile, pass, phone, checkResult, result;
      return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_7__["default"])().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            if (!lock) {
              _context.next = 2;
              break;
            }
            return _context.abrupt("return");
          case 2:
            mobile = form.getFieldValue('mobile');
            if (mobile) {
              _context.next = 6;
              break;
            }
            (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.taroMessage)('请填写手机号', 'error');
            return _context.abrupt("return");
          case 6:
            pass = type === 'mobileLogin' ? true : _utils__WEBPACK_IMPORTED_MODULE_1__.mobileRex.test(mobile);
            if (pass) {
              _context.next = 12;
              break;
            }
            (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.taroMessage)('请填写正确的手机号', 'error');
            return _context.abrupt("return");
          case 12:
            setLock(true);
            _context.prev = 13;
            phone = {
              userPhone: mobile
            };
            if (!(type === 'reg')) {
              _context.next = 22;
              break;
            }
            _context.next = 18;
            return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.checkUserPhone)(phone);
          case 18:
            checkResult = _context.sent;
            if (checkResult.success) {
              _context.next = 22;
              break;
            }
            (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.taroMessage)(checkResult.msg, 'error');
            return _context.abrupt("return");
          case 22:
            _context.next = 24;
            return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.sendPhone)(phone);
          case 24:
            result = _context.sent;
            console.log(26, result);
            setTimeFlag(true);
            setTime(seconds);
            _context.next = 33;
            break;
          case 30:
            _context.prev = 30;
            _context.t0 = _context["catch"](13);
            console.log(_context.t0);
          case 33:
            _context.prev = 33;
            setLock(false);
            return _context.finish(33);
          case 36:
          case "end":
            return _context.stop();
        }
      }, _callee, null, [[13, 30, 33, 36]]);
    }));
    return function getMobile() {
      return _ref2.apply(this, arguments);
    };
  }();
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
    if (time && time !== 0) timeRef.current = setTimeout(function () {
      setTime(time - 1);
    }, 1000);
    if (time === 0) setTimeFlag(false);
    return function () {
      clearTimeout(timeRef.current);
    };
  }, [time]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_8__.View, {
    children: timeFlag ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_tarojs_components__WEBPACK_IMPORTED_MODULE_8__.View, {
      children: ["\u5012\u8BA1\u65F6 ", time, " \u79D2"]
    }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_8__.View, {
      onClick: getMobile,
      children: "\u83B7\u53D6\u9A8C\u8BC1\u7801"
    })
  });
};

/***/ }),

/***/ "./src/account/components/accountForm/components/codeItem/components/index.tsx":
/*!*************************************************************************************!*\
  !*** ./src/account/components/accountForm/components/codeItem/components/index.tsx ***!
  \*************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CodeWrap": function() { return /* reexport safe */ _codeWrap__WEBPACK_IMPORTED_MODULE_0__.CodeWrap; }
/* harmony export */ });
/* harmony import */ var _codeWrap__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./codeWrap */ "./src/account/components/accountForm/components/codeItem/components/codeWrap/index.tsx");


/***/ }),

/***/ "./src/account/components/accountForm/components/codeItem/index.tsx":
/*!**************************************************************************!*\
  !*** ./src/account/components/accountForm/components/codeItem/index.tsx ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CodeItem": function() { return /* binding */ CodeItem; }
/* harmony export */ });
/* harmony import */ var antd_mobile__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! antd-mobile */ "./node_modules/antd-mobile/es/index.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components */ "./src/account/components/accountForm/components/codeItem/components/index.tsx");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-runtime */ "webpack/container/remote/react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);



var CodeItem = function CodeItem(_ref) {
  var _ref$txt = _ref.txt,
    txt = _ref$txt === void 0 ? '验证码' : _ref$txt,
    form = _ref.form,
    type = _ref.type;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(antd_mobile__WEBPACK_IMPORTED_MODULE_0__.Form.Item, {
    name: "code",
    extra: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(_components__WEBPACK_IMPORTED_MODULE_1__.CodeWrap, {
      form: form,
      type: type
    }),
    rules: [{
      required: true,
      message: "".concat(txt, "\u4E0D\u80FD\u4E3A\u7A7A")
    }],
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(antd_mobile__WEBPACK_IMPORTED_MODULE_0__.Input, {
      maxLength: 6,
      clearable: true,
      placeholder: "\u8BF7\u8F93\u5165".concat(txt)
    })
  });
};

/***/ }),

/***/ "./src/account/components/accountForm/components/index.ts":
/*!****************************************************************!*\
  !*** ./src/account/components/accountForm/components/index.ts ***!
  \****************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccountItem": function() { return /* reexport safe */ _accountItem__WEBPACK_IMPORTED_MODULE_3__.AccountItem; },
/* harmony export */   "CodeItem": function() { return /* reexport safe */ _codeItem__WEBPACK_IMPORTED_MODULE_1__.CodeItem; },
/* harmony export */   "MobileItem": function() { return /* reexport safe */ _mobileItem__WEBPACK_IMPORTED_MODULE_0__.MobileItem; },
/* harmony export */   "PasswordItem": function() { return /* reexport safe */ _passwordItem__WEBPACK_IMPORTED_MODULE_2__.PasswordItem; },
/* harmony export */   "ReadOnlyItem": function() { return /* reexport safe */ _readOnlyItem__WEBPACK_IMPORTED_MODULE_4__.ReadOnlyItem; },
/* harmony export */   "SubmitBtn": function() { return /* reexport safe */ _submitBtn__WEBPACK_IMPORTED_MODULE_5__.SubmitBtn; }
/* harmony export */ });
/* harmony import */ var _mobileItem__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mobileItem */ "./src/account/components/accountForm/components/mobileItem/index.tsx");
/* harmony import */ var _codeItem__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./codeItem */ "./src/account/components/accountForm/components/codeItem/index.tsx");
/* harmony import */ var _passwordItem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./passwordItem */ "./src/account/components/accountForm/components/passwordItem/index.tsx");
/* harmony import */ var _accountItem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./accountItem */ "./src/account/components/accountForm/components/accountItem/index.tsx");
/* harmony import */ var _readOnlyItem__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./readOnlyItem */ "./src/account/components/accountForm/components/readOnlyItem/index.tsx");
/* harmony import */ var _submitBtn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./submitBtn */ "./src/account/components/accountForm/components/submitBtn/index.tsx");







/***/ }),

/***/ "./src/account/components/accountForm/components/mobileItem/index.tsx":
/*!****************************************************************************!*\
  !*** ./src/account/components/accountForm/components/mobileItem/index.tsx ***!
  \****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MobileItem": function() { return /* binding */ MobileItem; }
/* harmony export */ });
/* harmony import */ var antd_mobile__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! antd-mobile */ "./node_modules/antd-mobile/es/index.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/utils */ "./src/utils/index.ts");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-runtime */ "webpack/container/remote/react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);



var MobileItem = function MobileItem(_ref) {
  var _ref$txt = _ref.txt,
    txt = _ref$txt === void 0 ? '手机号' : _ref$txt;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(antd_mobile__WEBPACK_IMPORTED_MODULE_0__.Form.Item, {
    name: "mobile",
    rules: [{
      required: true,
      message: "".concat(txt, "\u4E0D\u80FD\u4E3A\u7A7A")
    }, {
      pattern: _utils__WEBPACK_IMPORTED_MODULE_1__.mobileRex,
      message: "\u8BF7\u8F93\u5165\u6B63\u786E".concat(txt)
    }],
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(antd_mobile__WEBPACK_IMPORTED_MODULE_0__.Input, {
      maxLength: 11,
      clearable: true,
      placeholder: "\u8BF7\u8F93\u5165".concat(txt)
    })
  });
};

/***/ }),

/***/ "./src/account/components/accountForm/components/passwordItem/index.tsx":
/*!******************************************************************************!*\
  !*** ./src/account/components/accountForm/components/passwordItem/index.tsx ***!
  \******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PasswordItem": function() { return /* binding */ PasswordItem; }
/* harmony export */ });
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/container/remote/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/plugin-platform-weapp/dist/components-react.js");
/* harmony import */ var antd_mobile__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd-mobile */ "./node_modules/antd-mobile/es/index.js");
/* harmony import */ var _brushes_simulate_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @brushes/simulate-component */ "./node_modules/@brushes/simulate-component/dist/index.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-runtime */ "webpack/container/remote/react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);






var PasswordItem = function PasswordItem(_ref) {
  var _ref$txt = _ref.txt,
    txt = _ref$txt === void 0 ? '密码' : _ref$txt;
  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true),
    _useState2 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_useState, 2),
    pwdType = _useState2[0],
    setPwdType = _useState2[1];
  var checkPwd = function checkPwd(_, value) {
    if (value.length > 5 && value.length < 13) {
      return Promise.resolve();
    }
    return Promise.reject(new Error("\u8BF7\u8F93\u51656-12\u4F4D".concat(txt)));
  };
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(antd_mobile__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
    name: "password",
    rules: [{
      required: true,
      message: "".concat(txt, "\u4E0D\u80FD\u4E3A\u7A7A")
    }, {
      validator: checkPwd
    }],
    extra: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_4__.View, {
      onClick: function onClick() {
        return setPwdType(!pwdType);
      },
      children: pwdType ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_5__.IconMobile, {
        value: "yincang"
      }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_5__.IconMobile, {
        value: "liulan"
      })
    }),
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(antd_mobile__WEBPACK_IMPORTED_MODULE_1__.Input, {
      placeholder: "\u8BF7\u8F93\u5165".concat(txt),
      clearable: true,
      type: pwdType ? 'password' : 'text'
    })
  });
};

/***/ }),

/***/ "./src/account/components/accountForm/components/readOnlyItem/index.tsx":
/*!******************************************************************************!*\
  !*** ./src/account/components/accountForm/components/readOnlyItem/index.tsx ***!
  \******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReadOnlyItem": function() { return /* binding */ ReadOnlyItem; }
/* harmony export */ });
/* harmony import */ var antd_mobile__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! antd-mobile */ "./node_modules/antd-mobile/es/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/container/remote/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-runtime */ "webpack/container/remote/react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);



var ReadOnlyItem = function ReadOnlyItem(_ref) {
  var originPhone = _ref.originPhone,
    form = _ref.form;
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    form.setFieldValue('mobile', originPhone);
  }, [originPhone]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(antd_mobile__WEBPACK_IMPORTED_MODULE_0__.Form.Item, {
    name: "mobile",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(antd_mobile__WEBPACK_IMPORTED_MODULE_0__.Input, {
      placeholder: originPhone,
      readOnly: true
    })
  });
};

/***/ }),

/***/ "./src/account/components/accountForm/components/submitBtn/index.tsx":
/*!***************************************************************************!*\
  !*** ./src/account/components/accountForm/components/submitBtn/index.tsx ***!
  \***************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SubmitBtn": function() { return /* binding */ SubmitBtn; }
/* harmony export */ });
/* harmony import */ var antd_mobile__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! antd-mobile */ "./node_modules/antd-mobile/es/index.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "webpack/container/remote/react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);


var SubmitBtn = function SubmitBtn(_ref) {
  var btnText = _ref.btnText;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(antd_mobile__WEBPACK_IMPORTED_MODULE_0__.Button, {
    block: true,
    shape: "rounded",
    size: "large",
    type: "submit",
    style: {
      '--background-color': '#000000',
      '--text-color': '#FFFFFF'
    },
    children: btnText
  });
};

/***/ }),

/***/ "./src/account/components/accountForm/index.tsx":
/*!******************************************************!*\
  !*** ./src/account/components/accountForm/index.tsx ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccountForm": function() { return /* binding */ AccountForm; }
/* harmony export */ });
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/plugin-platform-weapp/dist/components-react.js");
/* harmony import */ var antd_mobile__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! antd-mobile */ "./node_modules/antd-mobile/es/index.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components */ "./src/account/components/accountForm/components/index.ts");
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../hooks */ "./src/account/hooks/index.ts");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-runtime */ "webpack/container/remote/react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);






var AccountForm = function AccountForm(_ref) {
  var type = _ref.type,
    btnText = _ref.btnText,
    txt = _ref.txt,
    originPhone = _ref.originPhone;
  var _useAccountForm = (0,_hooks__WEBPACK_IMPORTED_MODULE_2__.useAccountForm)(type),
    form = _useAccountForm.form,
    onFinish = _useAccountForm.onFinish;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_4__.View, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(antd_mobile__WEBPACK_IMPORTED_MODULE_0__.Form, {
      form: form,
      footer: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(_components__WEBPACK_IMPORTED_MODULE_1__.SubmitBtn, {
        btnText: btnText
      }),
      onFinish: onFinish,
      children: [['accountLogin'].includes(type) ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(_components__WEBPACK_IMPORTED_MODULE_1__.AccountItem, {}) : null, ['confirmPhone'].includes(type) ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(_components__WEBPACK_IMPORTED_MODULE_1__.ReadOnlyItem, {
        originPhone: originPhone,
        form: form
      }) : null, ['forgetPwd', 'reg', 'mobileLogin', 'bindPhone'].includes(type) ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(_components__WEBPACK_IMPORTED_MODULE_1__.MobileItem, {}) : null, ['reg', 'mobileLogin', 'forgetPwd', 'confirmPhone', 'bindPhone'].includes(type) ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(_components__WEBPACK_IMPORTED_MODULE_1__.CodeItem, {
        form: form,
        type: type
      }) : null, ['reg', 'accountLogin', 'forgetPwd'].includes(type) ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(_components__WEBPACK_IMPORTED_MODULE_1__.PasswordItem, {
        txt: txt
      }) : null]
    })
  });
};

/***/ }),

/***/ "./src/account/components/agreementEntry/index.tsx":
/*!*********************************************************!*\
  !*** ./src/account/components/agreementEntry/index.tsx ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AgreementEntry": function() { return /* binding */ AgreementEntry; }
/* harmony export */ });
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/plugin-platform-weapp/dist/components-react.js");
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../hooks */ "./src/account/hooks/index.ts");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "webpack/container/remote/react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);





var AgreementEntry = function AgreementEntry() {
  var _useAgreement = (0,_hooks__WEBPACK_IMPORTED_MODULE_0__.useAgreement)(),
    goDetail = _useAgreement.goDetail;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__.View, {
    className: "agreement",
    children: ["\u6CE8\u518C\u548C\u767B\u5F55\u5373\u4EE3\u8868\u540C\u610F \u300A", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__.View, {
      className: "link",
      onClick: goDetail.bind(null, 'xieyi'),
      children: "\u7528\u6237\u534F\u8BAE"
    }), "\u300B \u548C \u300A", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__.View, {
      className: "link",
      onClick: goDetail.bind(null, 'yinsi'),
      children: "\u9690\u79C1\u653F\u7B56"
    }), "\u300B"]
  });
};

/***/ }),

/***/ "./src/account/components/index.ts":
/*!*****************************************!*\
  !*** ./src/account/components/index.ts ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccountForm": function() { return /* reexport safe */ _accountForm__WEBPACK_IMPORTED_MODULE_1__.AccountForm; },
/* harmony export */   "AgreementEntry": function() { return /* reexport safe */ _agreementEntry__WEBPACK_IMPORTED_MODULE_2__.AgreementEntry; },
/* harmony export */   "LinkReg": function() { return /* reexport safe */ _linkReg__WEBPACK_IMPORTED_MODULE_3__.LinkReg; },
/* harmony export */   "TopLogo": function() { return /* reexport safe */ _topLogo__WEBPACK_IMPORTED_MODULE_0__.TopLogo; }
/* harmony export */ });
/* harmony import */ var _topLogo__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./topLogo */ "./src/account/components/topLogo/index.tsx");
/* harmony import */ var _accountForm__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./accountForm */ "./src/account/components/accountForm/index.tsx");
/* harmony import */ var _agreementEntry__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./agreementEntry */ "./src/account/components/agreementEntry/index.tsx");
/* harmony import */ var _linkReg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./linkReg */ "./src/account/components/linkReg/index.tsx");





/***/ }),

/***/ "./src/account/components/linkReg/index.tsx":
/*!**************************************************!*\
  !*** ./src/account/components/linkReg/index.tsx ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LinkReg": function() { return /* binding */ LinkReg; }
/* harmony export */ });
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/plugin-platform-weapp/dist/components-react.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @tarojs/taro */ "webpack/container/remote/@tarojs/taro");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "webpack/container/remote/react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



var LinkReg = function LinkReg() {
  var goReg = function goReg() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().navigateTo({
      url: 'account/register/index'
    });
  };
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__.View, {
    onClick: goReg,
    style: {
      paddingRight: '10px'
    },
    children: "\u6CE8\u518C"
  });
};

/***/ }),

/***/ "./src/account/components/topLogo/index.tsx":
/*!**************************************************!*\
  !*** ./src/account/components/topLogo/index.tsx ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TopLogo": function() { return /* binding */ TopLogo; }
/* harmony export */ });
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/plugin-platform-weapp/dist/components-react.js");
/* harmony import */ var _logo_png__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./logo.png */ "./src/account/components/topLogo/logo.png");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "webpack/container/remote/react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);




var TopLogo = function TopLogo() {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__.View, {
    className: "topLogo",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__.View, {
      className: "logo",
      style: {
        backgroundImage: "url(".concat(_logo_png__WEBPACK_IMPORTED_MODULE_0__, ")")
      }
    })
  });
};

/***/ }),

/***/ "./src/account/constans.ts":
/*!*********************************!*\
  !*** ./src/account/constans.ts ***!
  \*********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "accountConst": function() { return /* binding */ accountConst; }
/* harmony export */ });
var accountConst = {
  oldUserPhone: ''
};

/***/ }),

/***/ "./src/account/hooks/index.ts":
/*!************************************!*\
  !*** ./src/account/hooks/index.ts ***!
  \************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "stackLength": function() { return /* reexport safe */ _useAccountForm__WEBPACK_IMPORTED_MODULE_0__.stackLength; },
/* harmony export */   "useAccountForm": function() { return /* reexport safe */ _useAccountForm__WEBPACK_IMPORTED_MODULE_0__.useAccountForm; },
/* harmony export */   "useAgreement": function() { return /* reexport safe */ _useAgreement__WEBPACK_IMPORTED_MODULE_1__.useAgreement; },
/* harmony export */   "useAuth": function() { return /* reexport safe */ _useAuth__WEBPACK_IMPORTED_MODULE_2__.useAuth; },
/* harmony export */   "useBindPhone": function() { return /* reexport safe */ _useBindPhone__WEBPACK_IMPORTED_MODULE_3__.useBindPhone; }
/* harmony export */ });
/* harmony import */ var _useAccountForm__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./useAccountForm */ "./src/account/hooks/useAccountForm/index.ts");
/* harmony import */ var _useAgreement__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./useAgreement */ "./src/account/hooks/useAgreement/index.ts");
/* harmony import */ var _useAuth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./useAuth */ "./src/account/hooks/useAuth/index.ts");
/* harmony import */ var _useBindPhone__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./useBindPhone */ "./src/account/hooks/useBindPhone.ts");






/***/ }),

/***/ "./src/account/hooks/useAccountForm/index.ts":
/*!***************************************************!*\
  !*** ./src/account/hooks/useAccountForm/index.ts ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "stackLength": function() { return /* binding */ stackLength; },
/* harmony export */   "useAccountForm": function() { return /* binding */ useAccountForm; }
/* harmony export */ });
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js */ "./node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/container/remote/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd_mobile__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd-mobile */ "./node_modules/antd-mobile/es/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @tarojs/taro */ "webpack/container/remote/@tarojs/taro");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var qj_b2c_api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! qj-b2c-api */ "./node_modules/qj-b2c-api/dist/index.js");
/* harmony import */ var _brushes_request__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @brushes/request */ "./node_modules/@brushes/request/dist/index.js");
/* harmony import */ var _brushes_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @brushes/utils */ "./node_modules/@brushes/utils/dist/index.js");
/* harmony import */ var _account_constans__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/account/constans */ "./src/account/constans.ts");
/* harmony import */ var qj_mobile_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! qj-mobile-store */ "../../qj/lerna-repo/packages/qj-mobile-store/dist/index.js");











var stackLength = function stackLength() {
  var arr = _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default().getCurrentPages();
  var obj = {
    pageIndex: 0
  };
  for (var i = 0; i < arr.length; i++) {
    if (arr[i]['$taroPath'].indexOf('account/') >= 0) {
      if (i === 0) {
        obj.pageIndex = 0;
      } else {
        obj.pageIndex = arr.length - i;
      }
      break;
    }
  }
  return obj.pageIndex;
};
var useAccountForm = function useAccountForm(type) {
  var _Form$useForm = antd_mobile__WEBPACK_IMPORTED_MODULE_1__.Form.useForm(),
    _Form$useForm2 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_8__["default"])(_Form$useForm, 1),
    form = _Form$useForm2[0];
  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false),
    _useState2 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_8__["default"])(_useState, 2),
    submitLock = _useState2[0],
    setSubmitLock = _useState2[1];
  var onFinish = /*#__PURE__*/function () {
    var _ref = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_9__["default"])( /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_10__["default"])().mark(function _callee(formVal) {
      return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_10__["default"])().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            if (!submitLock) {
              _context.next = 2;
              break;
            }
            return _context.abrupt("return");
          case 2:
            _context.t0 = type;
            _context.next = _context.t0 === 'reg' ? 5 : _context.t0 === 'mobileLogin' ? 8 : _context.t0 === 'accountLogin' ? 11 : _context.t0 === 'forgetPwd' ? 14 : _context.t0 === 'confirmPhone' ? 17 : _context.t0 === 'bindPhone' ? 20 : 23;
            break;
          case 5:
            _context.next = 7;
            return regSubmit(formVal);
          case 7:
            return _context.abrupt("break", 23);
          case 8:
            _context.next = 10;
            return mobileLoginSubmit(formVal);
          case 10:
            return _context.abrupt("break", 23);
          case 11:
            _context.next = 13;
            return accountLoginSubmit(formVal);
          case 13:
            return _context.abrupt("break", 23);
          case 14:
            _context.next = 16;
            return forgetPwdSubmit(formVal);
          case 16:
            return _context.abrupt("break", 23);
          case 17:
            _context.next = 19;
            return confirmPhoneSubmit(formVal);
          case 19:
            return _context.abrupt("break", 23);
          case 20:
            _context.next = 22;
            return bindPhoneSubmit(formVal);
          case 22:
            return _context.abrupt("break", 23);
          case 23:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }));
    return function onFinish(_x) {
      return _ref.apply(this, arguments);
    };
  }();
  var regSubmit = /*#__PURE__*/function () {
    var _ref2 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_9__["default"])( /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_10__["default"])().mark(function _callee2(formVal) {
      var params;
      return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_10__["default"])().wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            params = {
              userPhone: formVal.mobile,
              code: formVal.code,
              userPwsswd: formVal.password,
              userinfoType: 1,
              userName: formVal.mobile
            };
            _context2.prev = 1;
            setSubmitLock(true);
            _context2.next = 5;
            return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_3__.saveUmuserPhone)(params);
          case 5:
            _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default().navigateBack({
              delta: 1
            });
            _context2.next = 11;
            break;
          case 8:
            _context2.prev = 8;
            _context2.t0 = _context2["catch"](1);
            console.log(27, _context2.t0);
          case 11:
            _context2.prev = 11;
            setSubmitLock(false);
            return _context2.finish(11);
          case 14:
          case "end":
            return _context2.stop();
        }
      }, _callee2, null, [[1, 8, 11, 14]]);
    }));
    return function regSubmit(_x2) {
      return _ref2.apply(this, arguments);
    };
  }();
  var mobileLoginSubmit = /*#__PURE__*/function () {
    var _ref3 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_9__["default"])( /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_10__["default"])().mark(function _callee3(formVal) {
      var params, result;
      return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_10__["default"])().wrap(function _callee3$(_context3) {
        while (1) switch (_context3.prev = _context3.next) {
          case 0:
            params = {
              userPhone: formVal.mobile,
              code: formVal.code,
              userinfoType: 1
            };
            _context3.prev = 1;
            setSubmitLock(true);
            _context3.next = 5;
            return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_3__.saveUmuserPhoneVCode)(params);
          case 5:
            result = _context3.sent;
            (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_5__.setStorage)('saas-token', result.dataObj.ticketTokenid);
            _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default().navigateBack({
              delta: stackLength(),
              success: function success(res) {
                console.log('调用前', res);
                (0,_brushes_request__WEBPACK_IMPORTED_MODULE_4__.errorCallback)();
              }
            });
            _context3.next = 13;
            break;
          case 10:
            _context3.prev = 10;
            _context3.t0 = _context3["catch"](1);
            console.log(27, _context3.t0);
          case 13:
            _context3.prev = 13;
            setSubmitLock(false);
            return _context3.finish(13);
          case 16:
          case "end":
            return _context3.stop();
        }
      }, _callee3, null, [[1, 10, 13, 16]]);
    }));
    return function mobileLoginSubmit(_x3) {
      return _ref3.apply(this, arguments);
    };
  }();
  var accountLoginSubmit = /*#__PURE__*/function () {
    var _ref4 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_9__["default"])( /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_10__["default"])().mark(function _callee4(formVal) {
      var params, result;
      return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_10__["default"])().wrap(function _callee4$(_context4) {
        while (1) switch (_context4.prev = _context4.next) {
          case 0:
            params = {
              loginName: formVal.account,
              passwd: formVal.password,
              code: 1234
            };
            _context4.prev = 1;
            setSubmitLock(true);
            _context4.next = 5;
            return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_3__.login)(params);
          case 5:
            result = _context4.sent;
            (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_5__.setStorage)('saas-token', result.dataObj.ticketTokenid);
            _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default().navigateBack({
              delta: stackLength(),
              success: function success() {
                (0,_brushes_request__WEBPACK_IMPORTED_MODULE_4__.errorCallback)();
              }
            });
            _context4.next = 13;
            break;
          case 10:
            _context4.prev = 10;
            _context4.t0 = _context4["catch"](1);
            console.log(27, _context4.t0);
          case 13:
            _context4.prev = 13;
            setSubmitLock(false);
            return _context4.finish(13);
          case 16:
          case "end":
            return _context4.stop();
        }
      }, _callee4, null, [[1, 10, 13, 16]]);
    }));
    return function accountLoginSubmit(_x4) {
      return _ref4.apply(this, arguments);
    };
  }();
  var forgetPwdSubmit = /*#__PURE__*/function () {
    var _ref5 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_9__["default"])( /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_10__["default"])().mark(function _callee5(formVal) {
      var params;
      return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_10__["default"])().wrap(function _callee5$(_context5) {
        while (1) switch (_context5.prev = _context5.next) {
          case 0:
            console.log(70, formVal);
            params = {
              userPhone: formVal.mobile,
              code: formVal.code,
              userPwsswd: formVal.password
            };
            _context5.prev = 2;
            setSubmitLock(true);
            _context5.next = 6;
            return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_3__.updateUmuserPw)(params);
          case 6:
            _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default().navigateBack({
              delta: 1
            });
            _context5.next = 12;
            break;
          case 9:
            _context5.prev = 9;
            _context5.t0 = _context5["catch"](2);
            console.log(27, _context5.t0);
          case 12:
            _context5.prev = 12;
            setSubmitLock(false);
            return _context5.finish(12);
          case 15:
          case "end":
            return _context5.stop();
        }
      }, _callee5, null, [[2, 9, 12, 15]]);
    }));
    return function forgetPwdSubmit(_x5) {
      return _ref5.apply(this, arguments);
    };
  }();
  var confirmPhoneSubmit = /*#__PURE__*/function () {
    var _ref6 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_9__["default"])( /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_10__["default"])().mark(function _callee6(formVal) {
      var params, result;
      return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_10__["default"])().wrap(function _callee6$(_context6) {
        while (1) switch (_context6.prev = _context6.next) {
          case 0:
            params = {
              userPhone: formVal.mobile,
              code: formVal.code
            };
            _context6.prev = 1;
            _context6.next = 4;
            return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_3__.checkVerificationMa)(params);
          case 4:
            result = _context6.sent;
            if (result.success) {
              console.log(148, result);
              _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default().navigateTo({
                url: "".concat(qj_mobile_store__WEBPACK_IMPORTED_MODULE_7__.routerMap.bindPhone, "?oldUserPhone=").concat(formVal.mobile)
              });
            }
            _context6.next = 11;
            break;
          case 8:
            _context6.prev = 8;
            _context6.t0 = _context6["catch"](1);
            console.log(_context6.t0);
          case 11:
          case "end":
            return _context6.stop();
        }
      }, _callee6, null, [[1, 8]]);
    }));
    return function confirmPhoneSubmit(_x6) {
      return _ref6.apply(this, arguments);
    };
  }();
  var bindPhoneSubmit = /*#__PURE__*/function () {
    var _ref7 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_9__["default"])( /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_10__["default"])().mark(function _callee7(formVal) {
      var params, result;
      return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_10__["default"])().wrap(function _callee7$(_context7) {
        while (1) switch (_context7.prev = _context7.next) {
          case 0:
            params = {
              newUserPhone: formVal.mobile,
              code: formVal.code,
              oldUserPhone: _account_constans__WEBPACK_IMPORTED_MODULE_6__.accountConst.oldUserPhone
            };
            _context7.prev = 1;
            _context7.next = 4;
            return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_3__.updateUserPhoneByUserPhone)(params);
          case 4:
            result = _context7.sent;
            if (result.success) {
              _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default().showToast({
                title: '绑定成功',
                icon: 'success',
                duration: 2000,
                success: function success() {
                  setTimeout(function () {
                    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default().navigateBack({
                      delta: 3
                    });
                  }, 2000);
                }
              });
            }
            _context7.next = 11;
            break;
          case 8:
            _context7.prev = 8;
            _context7.t0 = _context7["catch"](1);
            console.log(_context7.t0);
          case 11:
          case "end":
            return _context7.stop();
        }
      }, _callee7, null, [[1, 8]]);
    }));
    return function bindPhoneSubmit(_x7) {
      return _ref7.apply(this, arguments);
    };
  }();
  var goRegister = function goRegister() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default().navigateTo({
      url: qj_mobile_store__WEBPACK_IMPORTED_MODULE_7__.routerMap.register
    });
  };
  var goAccountLogin = function goAccountLogin() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default().navigateTo({
      url: qj_mobile_store__WEBPACK_IMPORTED_MODULE_7__.routerMap.accountLogin
    });
  };
  var goMobileLogin = function goMobileLogin() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default().navigateTo({
      url: qj_mobile_store__WEBPACK_IMPORTED_MODULE_7__.routerMap.mobileLogin
    });
  };
  var goForgetPwd = function goForgetPwd() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default().navigateTo({
      url: qj_mobile_store__WEBPACK_IMPORTED_MODULE_7__.routerMap.forgetPwd
    });
  };
  return {
    form: form,
    onFinish: onFinish,
    goRegister: goRegister,
    goAccountLogin: goAccountLogin,
    goMobileLogin: goMobileLogin,
    goForgetPwd: goForgetPwd
  };
};

/***/ }),

/***/ "./src/account/hooks/useAgreement/index.ts":
/*!*************************************************!*\
  !*** ./src/account/hooks/useAgreement/index.ts ***!
  \*************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "useAgreement": function() { return /* binding */ useAgreement; }
/* harmony export */ });
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js */ "./node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var qj_b2c_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! qj-b2c-api */ "./node_modules/qj-b2c-api/dist/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/container/remote/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @tarojs/taro */ "webpack/container/remote/@tarojs/taro");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash-es */ "./node_modules/lodash-es/get.js");







var useAgreement = function useAgreement(type) {
  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(''),
    _useState2 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_useState, 2),
    agreementData = _useState2[0],
    setAgreementData = _useState2[1];
  var proappCode = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)('');
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])( /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_5__["default"])().mark(function _callee() {
      var result, resultArr, i;
      return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_5__["default"])().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            setProappCode();
            _context.next = 3;
            return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_0__.queryProappConfigByChannel)();
          case 3:
            result = _context.sent;
            resultArr = (0,lodash_es__WEBPACK_IMPORTED_MODULE_6__["default"])(result, 'list');
            i = 0;
          case 6:
            if (!(i < resultArr.length)) {
              _context.next = 13;
              break;
            }
            if (!(resultArr[i].proappCode === proappCode.current && resultArr[i].proappConfigType === type)) {
              _context.next = 10;
              break;
            }
            setAgreementData(resultArr[i].proappConfigText2);
            return _context.abrupt("break", 13);
          case 10:
            i++;
            _context.next = 6;
            break;
          case 13:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }))();
  }, []);
  var setProappCode = function setProappCode() {
    var platform = "weapp";
    switch (platform) {
      case 'h5':
        proappCode.current = '003';
        break;
      case 'weapp':
        proappCode.current = '025';
        break;
    }
  };
  var goDetail = function goDetail(agreeType) {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default().navigateTo({
      url: "/account/agreement/index?type=".concat(agreeType)
    });
  };
  return {
    agreementData: agreementData,
    goDetail: goDetail
  };
};

/***/ }),

/***/ "./src/account/hooks/useAuth/index.ts":
/*!********************************************!*\
  !*** ./src/account/hooks/useAuth/index.ts ***!
  \********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "useAuth": function() { return /* binding */ useAuth; }
/* harmony export */ });
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js */ "./node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/container/remote/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @tarojs/taro */ "webpack/container/remote/@tarojs/taro");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! qj-b2c-api */ "./node_modules/qj-b2c-api/dist/index.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! lodash-es */ "./node_modules/lodash-es/get.js");
/* harmony import */ var _brushes_request__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @brushes/request */ "./node_modules/@brushes/request/dist/index.js");
/* harmony import */ var _account_hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/account/hooks */ "./src/account/hooks/index.ts");









var useAuth = function useAuth() {
  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(''),
    _useState2 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_useState, 2),
    bg = _useState2[0],
    setBg = _useState2[1];
  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(''),
    _useState4 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_useState3, 2),
    logo = _useState4[0],
    setLogo = _useState4[1];
  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true),
    _useState6 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_useState5, 2),
    agree = _useState6[0],
    setAgree = _useState6[1];
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
    getInfo();
  }, []);
  var getInfo = /*#__PURE__*/function () {
    var _ref = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_6__["default"])( /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_7__["default"])().mark(function _callee() {
      var res, result;
      return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_7__["default"])().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            _context.next = 3;
            return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryProappEnvPage)();
          case 3:
            res = _context.sent;
            result = res.list[0];
            setBg("https://www.".concat(result.proappEnvDomain).concat(result.proappEnvIndexc));
            setLogo("https://www.".concat(result.proappEnvDomain).concat(result.proappEnvLogo));
            _context.next = 12;
            break;
          case 9:
            _context.prev = 9;
            _context.t0 = _context["catch"](0);
            console.log(_context.t0);
          case 12:
          case "end":
            return _context.stop();
        }
      }, _callee, null, [[0, 9]]);
    }));
    return function getInfo() {
      return _ref.apply(this, arguments);
    };
  }();
  var agreeFunc = function agreeFunc(e) {
    if (e.detail.value.length) {
      setAgree(true);
    } else {
      setAgree(false);
    }
  };
  var getPhone = /*#__PURE__*/function () {
    var _ref2 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_6__["default"])( /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_7__["default"])().mark(function _callee3(e) {
      return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_7__["default"])().wrap(function _callee3$(_context3) {
        while (1) switch (_context3.prev = _context3.next) {
          case 0:
            _tarojs_taro__WEBPACK_IMPORTED_MODULE_1___default().login({
              success: function () {
                var _success = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_6__["default"])( /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_7__["default"])().mark(function _callee2(res) {
                  var warrantyResult, _get, register, userInfo, userOpenid, result, user;
                  return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_7__["default"])().wrap(function _callee2$(_context2) {
                    while (1) switch (_context2.prev = _context2.next) {
                      case 0:
                        _context2.next = 2;
                        return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.warrantyLogin)({
                          'js_code': res.code
                        });
                      case 2:
                        warrantyResult = _context2.sent;
                        _get = (0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(warrantyResult, 'dataObj'), register = _get.register, userInfo = _get.userInfo, userOpenid = _get.userOpenid;
                        if (!(register === 'true')) {
                          _context2.next = 10;
                          break;
                        }
                        _context2.next = 7;
                        return registerImpl(e, userOpenid);
                      case 7:
                        result = _context2.sent;
                        setAuthImpl(result.dataObj.ticketTokenid);
                        return _context2.abrupt("return");
                      case 10:
                        user = JSON.parse(userInfo);
                        setAuthImpl(user.ticketTokenid);
                      case 12:
                      case "end":
                        return _context2.stop();
                    }
                  }, _callee2);
                }));
                function success(_x2) {
                  return _success.apply(this, arguments);
                }
                return success;
              }()
            });
          case 1:
          case "end":
            return _context3.stop();
        }
      }, _callee3);
    }));
    return function getPhone(_x) {
      return _ref2.apply(this, arguments);
    };
  }();
  var registerImpl = function registerImpl(e, userOpenid) {
    return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.saveUmuserPhoneNoCodeByWX)({
      code: e.detail.code,
      userOpenid: userOpenid
    });
  };
  var setAuthImpl = function setAuthImpl(token) {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_1___default().setStorageSync('saas-token', token);
    callback();
  };
  var callback = function callback() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_1___default().navigateBack({
      delta: (0,_account_hooks__WEBPACK_IMPORTED_MODULE_4__.stackLength)(),
      success: function success() {
        (0,_brushes_request__WEBPACK_IMPORTED_MODULE_3__.errorCallback)();
      }
    });
  };
  return {
    bg: bg,
    logo: logo,
    agreeFunc: agreeFunc,
    setAgree: setAgree,
    agree: agree,
    getPhone: getPhone
  };
};

/***/ }),

/***/ "./src/account/hooks/useBindPhone.ts":
/*!*******************************************!*\
  !*** ./src/account/hooks/useBindPhone.ts ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "useBindPhone": function() { return /* binding */ useBindPhone; }
/* harmony export */ });
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js */ "./node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/container/remote/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var qj_b2c_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! qj-b2c-api */ "./node_modules/qj-b2c-api/dist/index.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lodash-es */ "./node_modules/lodash-es/get.js");






var useBindPhone = function useBindPhone() {
  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(''),
    _useState2 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState, 2),
    originPhone = _useState2[0],
    setOriginPhone = _useState2[1];
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
    getOriginPhone();
  }, []);
  var getOriginPhone = /*#__PURE__*/function () {
    var _ref = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])( /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_4__["default"])().mark(function _callee() {
      var result, phone;
      return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_4__["default"])().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_1__.INDEX_MEM)();
          case 2:
            result = _context.sent;
            phone = (0,lodash_es__WEBPACK_IMPORTED_MODULE_5__["default"])(result, 'userInfo.userPhone');
            setOriginPhone(phone);
          case 5:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }));
    return function getOriginPhone() {
      return _ref.apply(this, arguments);
    };
  }();
  return {
    originPhone: originPhone
  };
};

/***/ }),

/***/ "./src/components/baseWrapCommon.tsx":
/*!*******************************************!*\
  !*** ./src/components/baseWrapCommon.tsx ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BaseWrapCommon": function() { return /* binding */ BaseWrapCommon; }
/* harmony export */ });
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/container/remote/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @tarojs/taro */ "webpack/container/remote/@tarojs/taro");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/plugin-platform-weapp/dist/components-react.js");
/* harmony import */ var _components_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/index */ "./src/components/index.tsx");
/* harmony import */ var _custom_tab_web_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/custom-tab-web/index */ "./src/custom-tab-web/index.tsx");
/* harmony import */ var qj_mobile_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! qj-mobile-store */ "../../qj/lerna-repo/packages/qj-mobile-store/dist/index.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-runtime */ "webpack/container/remote/react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);










var BaseWrapCommonInner = function BaseWrapCommonInner(props) {
  var _useRouter = (0,_tarojs_taro__WEBPACK_IMPORTED_MODULE_1__.useRouter)(),
    path = _useRouter.path,
    params = _useRouter.params;
  var _useApplicationContex = (0,qj_mobile_store__WEBPACK_IMPORTED_MODULE_4__.useApplicationContext)(),
    _useApplicationContex2 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_6__["default"])(_useApplicationContex, 1),
    _useApplicationContex3 = _useApplicationContex2[0].scrollTop,
    scrollTop = _useApplicationContex3 === void 0 ? 0 : _useApplicationContex3;
  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(''),
    _useState2 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_6__["default"])(_useState, 2),
    title = _useState2[0],
    setTitle = _useState2[1];
  var _useMemo = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
      var windowH = _tarojs_taro__WEBPACK_IMPORTED_MODULE_1___default().getSystemInfoSync().windowHeight;
      var menuOpcode = _tarojs_taro__WEBPACK_IMPORTED_MODULE_1___default().getStorageSync('menuOpcode');
      var safeArea = _tarojs_taro__WEBPACK_IMPORTED_MODULE_1___default().getStorageSync('safeArea');
      var tabBarH = _tarojs_taro__WEBPACK_IMPORTED_MODULE_1___default().getStorageSync('tabBarHeight');
      return {
        windowH: windowH,
        safeArea: safeArea,
        tabBarH: tabBarH,
        menuOpcode: menuOpcode
      };
    }, []),
    safeArea = _useMemo.safeArea,
    tabBarH = _useMemo.tabBarH,
    menuOpcode = _useMemo.menuOpcode,
    windowH = _useMemo.windowH;
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
    var routerMap = _tarojs_taro__WEBPACK_IMPORTED_MODULE_1___default().getStorageSync('routerMap');
    var _ref = routerMap[menuOpcode] || {},
      _ref$text = _ref.text,
      text = _ref$text === void 0 ? '首页' : _ref$text;
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_1___default().setNavigationBarTitle({
      title: text
    });
    setTitle(text);
  }, []);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_7__.ScrollView, {
      scrollY: true,
      enhanced: true,
      scrollTop: scrollTop,
      scrollWithAnimation: true,
      scrollAnimationDuration: "800",
      "show-scrollbar": false,
      style: {
        height: "calc(".concat(windowH, "px - ").concat(safeArea, "px - ").concat(props.base ? tabBarH : 0, "px)")
      },
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(_components_index__WEBPACK_IMPORTED_MODULE_2__["default"], (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_8__["default"])({
        navigationBarTitle: title,
        route: path
      }, params))
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(_custom_tab_web_index__WEBPACK_IMPORTED_MODULE_3__["default"], {
      base: props.base || false
    })]
  });
};
var BaseWrapCommon = function BaseWrapCommon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(qj_mobile_store__WEBPACK_IMPORTED_MODULE_4__.ApplicationContext, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(BaseWrapCommonInner, (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_8__["default"])({}, props))
  });
};

/***/ }),

/***/ "./src/components/custom-common/index.tsx":
/*!************************************************!*\
  !*** ./src/components/custom-common/index.tsx ***!
  \************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/container/remote/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/plugin-platform-weapp/dist/components-react.js");
/* harmony import */ var _brushes_taro_hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @brushes/taro-hooks */ "../../2023-qj/qj-request-tools/packages/taro-hooks/dist/index.js");
/* harmony import */ var _brushes_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @brushes/utils */ "./node_modules/@brushes/utils/dist/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @tarojs/taro */ "webpack/container/remote/@tarojs/taro");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-runtime */ "webpack/container/remote/react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);








var TabBar = function TabBar() {
  var _useRouter = (0,_tarojs_taro__WEBPACK_IMPORTED_MODULE_3__.useRouter)(),
    path = _useRouter.path;
  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('#b8b8b8'),
    _useState2 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_useState, 1),
    color = _useState2[0];
  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('#000000'),
    _useState4 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_useState3, 1),
    selectedColor = _useState4[0];
  var menuList = (0,_brushes_taro_hooks__WEBPACK_IMPORTED_MODULE_1__.useMenu)();
  var switchTab = function switchTab(menuOpcode) {
    (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_2__.navigatorHandler)(menuOpcode);
  };
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_tarojs_components__WEBPACK_IMPORTED_MODULE_6__.CoverView, {
    className: "tab-bar",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_6__.CoverView, {
      className: "tab-bar-border"
    }), menuList.map(function (item, index) {
      return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_tarojs_components__WEBPACK_IMPORTED_MODULE_6__.CoverView, {
        className: "tab-bar-item",
        onClick: function onClick() {
          return switchTab(item.menuOpcode);
        },
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_6__.CoverImage, {
          className: "tab-bar-item-img",
          src: path.includes(item.pagePath) ? item.selectedIconPath : item.iconPath
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_6__.CoverView, {
          className: "tab-bar-item-view",
          style: {
            color: path.includes(item.pagePath) ? selectedColor : color
          },
          children: item.text
        })]
      }, index);
    })]
  });
};
/* harmony default export */ __webpack_exports__["default"] = (TabBar);

/***/ }),

/***/ "./src/components/dynamicComponent.tsx":
/*!*********************************************!*\
  !*** ./src/components/dynamicComponent.tsx ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_objectWithoutProperties_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectWithoutProperties.js */ "./node_modules/@babel/runtime/helpers/esm/objectWithoutProperties.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash-es */ "./node_modules/lodash-es/get.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash-es */ "./node_modules/lodash-es/noop.js");
/* harmony import */ var s_material_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! s-material-react */ "../../qj/qj-mobile-react/packages/s-material-react/dist/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/container/remote/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _brushes_taro_hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @brushes/taro-hooks */ "../../2023-qj/qj-request-tools/packages/taro-hooks/dist/index.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-runtime */ "webpack/container/remote/react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);


var _excluded = ["component_devil_type", "withPageStore"],
  _excluded2 = ["component_devil_type"],
  _excluded3 = ["type", "props"],
  _excluded4 = ["node", "topPage"];






var ComponentWithContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(function (_ref) {
  var component_devil_type = _ref.component_devil_type,
    withPageStore = _ref.withPageStore,
    rest = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_objectWithoutProperties_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_ref, _excluded);
  var MaterialsComponent = (0,lodash_es__WEBPACK_IMPORTED_MODULE_4__["default"])(s_material_react__WEBPACK_IMPORTED_MODULE_5__, component_devil_type, lodash_es__WEBPACK_IMPORTED_MODULE_6__["default"]);
  var storeProps = (0,_brushes_taro_hooks__WEBPACK_IMPORTED_MODULE_1__.useDataSourceWithContext)(withPageStore);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(MaterialsComponent, (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_7__["default"])((0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_7__["default"])({}, rest), storeProps));
});
var ComponentNoContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(function (_ref2) {
  var component_devil_type = _ref2.component_devil_type,
    rest = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_objectWithoutProperties_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_ref2, _excluded2);
  var MaterialsComponent = (0,lodash_es__WEBPACK_IMPORTED_MODULE_4__["default"])(s_material_react__WEBPACK_IMPORTED_MODULE_5__, component_devil_type, lodash_es__WEBPACK_IMPORTED_MODULE_6__["default"]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(MaterialsComponent, (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_7__["default"])({}, rest));
});
var ComponentItem = function ComponentItem(_ref3) {
  var type = _ref3.type,
    props = _ref3.props,
    rest = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_objectWithoutProperties_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_ref3, _excluded3);
  var _useDataSource = (0,_brushes_taro_hooks__WEBPACK_IMPORTED_MODULE_1__.useDataSource)(type, props, rest),
    propsType = _useDataSource.propsType,
    withPageStore = _useDataSource.withPageStore;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: withPageStore.size > 0 ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(ComponentWithContext, (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_7__["default"])({}, propsType)) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(ComponentNoContext, (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_7__["default"])({}, propsType))
  });
};
var DynamicComponent = function DynamicComponent(_ref4) {
  var node = _ref4.node,
    topPage = _ref4.topPage,
    rest = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_objectWithoutProperties_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_ref4, _excluded4);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: node.map(function (_ref5) {
      var id = _ref5.id,
        _ref5$props = _ref5.props,
        props = _ref5$props === void 0 ? {} : _ref5$props,
        type = _ref5.type;
      return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)(ComponentItem, (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_7__["default"])({
        type: type,
        props: props
      }, rest), id);
    })
  });
};
/* harmony default export */ __webpack_exports__["default"] = (DynamicComponent);

/***/ }),

/***/ "./src/components/header.tsx":
/*!***********************************!*\
  !*** ./src/components/header.tsx ***!
  \***********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/container/remote/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _brushes_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @brushes/utils */ "./node_modules/@brushes/utils/dist/index.js");
/* harmony import */ var _brushes_simulate_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @brushes/simulate-component */ "./node_modules/@brushes/simulate-component/dist/index.js");
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/plugin-platform-weapp/dist/components-react.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @tarojs/taro */ "webpack/container/remote/@tarojs/taro");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/utils */ "./src/utils/index.ts");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-runtime */ "webpack/container/remote/react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);










var env = _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default().getEnv();
var HeaderJsx = function HeaderJsx(_ref) {
  var slot = _ref.slot,
    navigationBarTitle = _ref.navigationBarTitle;
  var _useRouter = (0,_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__.useRouter)(),
    path = _useRouter.path;
  var isHiddenHeader = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
    if (env === 'WEAPP') return true;
    return /^\/pages/.test(path);
  }, [path]);
  var navigator = function navigator() {
    var flag = (0,_utils__WEBPACK_IMPORTED_MODULE_3__.isTopPage)();
    if (flag) {
      (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_1__.navigatorHandler)('index');
      return;
    }
    (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_1__.navigatorBackImpl)(-1);
  };
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
    children: isHiddenHeader ? null : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_tarojs_components__WEBPACK_IMPORTED_MODULE_5__.View, {
      className: "header",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_brushes_simulate_component__WEBPACK_IMPORTED_MODULE_6__.IconMobile, {
        style: {
          fontSize: 20
        },
        value: "xiangzuo",
        onClick: navigator
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_5__.View, {
        className: "title",
        children: navigationBarTitle
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_tarojs_components__WEBPACK_IMPORTED_MODULE_5__.View, {
        children: slot
      })]
    })
  });
};
/* harmony default export */ __webpack_exports__["default"] = (HeaderJsx);

/***/ }),

/***/ "./src/components/index.tsx":
/*!**********************************!*\
  !*** ./src/components/index.tsx ***!
  \**********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_objectWithoutProperties_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectWithoutProperties.js */ "./node_modules/@babel/runtime/helpers/esm/objectWithoutProperties.js");
/* harmony import */ var _brushes_taro_hooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @brushes/taro-hooks */ "../../2023-qj/qj-request-tools/packages/taro-hooks/dist/index.js");
/* harmony import */ var _components_header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/header */ "./src/components/header.tsx");
/* harmony import */ var _dynamicComponent__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./dynamicComponent */ "./src/components/dynamicComponent.tsx");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-runtime */ "webpack/container/remote/react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);


var _excluded = ["route", "navigationBarTitle"];





var CommonJsx = function CommonJsx(_ref) {
  var route = _ref.route,
    navigationBarTitle = _ref.navigationBarTitle,
    rest = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_objectWithoutProperties_js__WEBPACK_IMPORTED_MODULE_4__["default"])(_ref, _excluded);
  var _usePageConfig = (0,_brushes_taro_hooks__WEBPACK_IMPORTED_MODULE_0__.usePageConfig)(route),
    node = _usePageConfig.node,
    initialValue = _usePageConfig.initialValue;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(_brushes_taro_hooks__WEBPACK_IMPORTED_MODULE_0__.TaroContextProvider, {
    initialValue: initialValue,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(_components_header__WEBPACK_IMPORTED_MODULE_1__["default"], {
      navigationBarTitle: navigationBarTitle
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(_dynamicComponent__WEBPACK_IMPORTED_MODULE_2__["default"], (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_5__["default"])({
      node: node
    }, rest))]
  });
};
/* harmony default export */ __webpack_exports__["default"] = (CommonJsx);

/***/ }),

/***/ "./src/custom-tab-web/index.tsx":
/*!**************************************!*\
  !*** ./src/custom-tab-web/index.tsx ***!
  \**************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _components_custom_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/custom-common */ "./src/components/custom-common/index.tsx");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/container/remote/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @tarojs/taro */ "webpack/container/remote/@tarojs/taro");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-runtime */ "webpack/container/remote/react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);





var TabBarWeb = function TabBarWeb(_ref) {
  var base = _ref.base;
  var isShow = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
    var isWeb = _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default().getEnv() === 'WEB';
    return isWeb && base;
  }, [base]);
  if (!isShow) return;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(_components_custom_common__WEBPACK_IMPORTED_MODULE_0__["default"], {});
};
/* harmony default export */ __webpack_exports__["default"] = (TabBarWeb);

/***/ }),

/***/ "./src/routerMap/append.ts":
/*!*********************************!*\
  !*** ./src/routerMap/append.ts ***!
  \*********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "appendPath": function() { return /* binding */ appendPath; }
/* harmony export */ });
var appendPath = ["package/one/index", "package/two/index", "package/three/index", "package/four/index", "package/five/index", "package/six/index", "package/seven/index", "package/eight/index", "package/nine/index", "package/ten/index", "package/eleven/index", "package/twelve/index", "package/thirteen/index", "package/fourteen/index", "package/fifteen/index", "package/sixteen/index", "package/seventeen/index", "package/eighteen/index", "package/nineteen/index", "package/twenty/index", "package/twenty-one/index", "package/twenty-two/index", "package/twenty-three/index", "package/twenty-four/index", "package/twenty-five/index", "package/twenty-six/index", "package/twenty-seven/index", "package/twenty-eight/index", "package/twenty-nine/index", "package/thirty/index", "package/thirty-one/index", "package/thirty-two/index", "package/thirty-three/index", "package/thirty-four/index", "package/thirty-five/index", "package/thirty-six/index", "package/thirty-seven/index", "package/thirty-eight/index", "package/thirty-nine/index"];

/***/ }),

/***/ "./src/routerMap/basic.ts":
/*!********************************!*\
  !*** ./src/routerMap/basic.ts ***!
  \********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "tabBarList": function() { return /* binding */ tabBarList; }
/* harmony export */ });
var tabBarList = [{
  pagePath: 'pages/index/index',
  text: '首页'
}, {
  pagePath: 'pages/classify/index',
  text: '分类'
}, {
  pagePath: 'pages/shopping/index',
  text: '购物车'
}, {
  pagePath: 'pages/my/index',
  text: '我的'
}, {
  pagePath: 'pages/dynamicTab/index',
  text: '自定义页面'
}];

/***/ }),

/***/ "./src/utils/auth.ts":
/*!***************************!*\
  !*** ./src/utils/auth.ts ***!
  \***************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export login */
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js */ "./node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @tarojs/taro */ "webpack/container/remote/@tarojs/taro");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var qj_b2c_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! qj-b2c-api */ "./node_modules/qj-b2c-api/dist/index.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash-es */ "./node_modules/lodash-es/get.js");





function checkSession() {
  return _checkSession.apply(this, arguments);
}
function _checkSession() {
  _checkSession = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_3__["default"])().mark(function _callee() {
    return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_3__["default"])().wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          return _context.abrupt("return", new Promise(function (resolve, reject) {
            _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().checkSession({
              success: function success() {
                return resolve(true);
              },
              fail: function fail() {
                return resolve(false);
              }
            });
          }));
        case 1:
        case "end":
          return _context.stop();
      }
    }, _callee);
  }));
  return _checkSession.apply(this, arguments);
}
function bindSeller() {
  return _bindSeller.apply(this, arguments);
} // 检测登录状态，返回 true / false
function _bindSeller() {
  _bindSeller = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_3__["default"])().mark(function _callee2() {
    var token, referrer;
    return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_3__["default"])().wrap(function _callee2$(_context2) {
      while (1) switch (_context2.prev = _context2.next) {
        case 0:
          token = _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().getStorageSync('saas-token');
          referrer = _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().getStorageSync('referrer');
          if (token) {
            _context2.next = 4;
            break;
          }
          return _context2.abrupt("return");
        case 4:
          if (referrer) {
            _context2.next = 6;
            break;
          }
          return _context2.abrupt("return");
        case 6:
        case "end":
          return _context2.stop();
      }
    }, _callee2);
  }));
  return _bindSeller.apply(this, arguments);
}
function checkHasLogined() {
  return _checkHasLogined.apply(this, arguments);
}
function _checkHasLogined() {
  _checkHasLogined = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_3__["default"])().mark(function _callee3() {
    var token, loggined;
    return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_3__["default"])().wrap(function _callee3$(_context3) {
      while (1) switch (_context3.prev = _context3.next) {
        case 0:
          token = _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().getStorageSync('saas-token');
          if (token) {
            _context3.next = 3;
            break;
          }
          return _context3.abrupt("return", false);
        case 3:
          _context3.next = 5;
          return checkSession();
        case 5:
          loggined = _context3.sent;
          if (loggined) {
            _context3.next = 9;
            break;
          }
          _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().removeStorageSync('saas-token');
          return _context3.abrupt("return", false);
        case 9:
          return _context3.abrupt("return", true);
        case 10:
        case "end":
          return _context3.stop();
      }
    }, _callee3);
  }));
  return _checkHasLogined.apply(this, arguments);
}
function wxaCode() {
  return _wxaCode.apply(this, arguments);
}
function _wxaCode() {
  _wxaCode = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_3__["default"])().mark(function _callee4() {
    return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_3__["default"])().wrap(function _callee4$(_context4) {
      while (1) switch (_context4.prev = _context4.next) {
        case 0:
          return _context4.abrupt("return", new Promise(function (resolve, reject) {
            _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().login({
              success: function success(res) {
                return resolve(res.code);
              },
              fail: function fail() {
                _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().showToast({
                  title: '获取code失败',
                  icon: 'none'
                });
                return resolve('获取code失败');
              }
            });
          }));
        case 1:
        case "end":
          return _context4.stop();
      }
    }, _callee4);
  }));
  return _wxaCode.apply(this, arguments);
}
function login(bindImpl) {
  return new Promise(function (resolve, reject) {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().login({
      success: function success(result) {
        (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_1__.warrantyLogin)({
          js_code: result.code
        }).then(function (res) {
          // 异常情况
          if (!res.dataObj) {
            // 登录错误
            _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().showToast({
              title: '无法登录',
              icon: "error",
              duration: 1500
            });
            reject();
            return;
          }
          var isReister = (0,lodash_es__WEBPACK_IMPORTED_MODULE_4__["default"])(res, 'dataObj.register', "");
          var userOpenid = (0,lodash_es__WEBPACK_IMPORTED_MODULE_4__["default"])(res, 'dataObj.userOpenid', "");
          _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().setStorageSync('userOpenid', userOpenid);
          if (isReister === "true") {
            // 去绑定
            bindImpl();
            return;
          }
          var token = (0,lodash_es__WEBPACK_IMPORTED_MODULE_4__["default"])(res, 'dataObj.userInfo', "{}");
          _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().setStorageSync('saas-token', token);
          resolve('');
        });
      }
    });
  });
}
function authorize() {
  return _authorize.apply(this, arguments);
}
function _authorize() {
  _authorize = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_3__["default"])().mark(function _callee5() {
    return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_3__["default"])().wrap(function _callee5$(_context5) {
      while (1) switch (_context5.prev = _context5.next) {
        case 0:
          return _context5.abrupt("return", new Promise(function (resolve, reject) {
            _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().login({
              success: function success(res) {
                var code = res.code;
                var referrer = ''; // 推荐人
                var referrer_storge = wx.getStorageSync('referrer');
                if (referrer_storge) {
                  referrer = referrer_storge;
                }
                // 下面开始调用注册接口
                var extConfigSync = wx.getExtConfigSync();
                if (extConfigSync.subDomain) {
                  WXAPI.wxappServiceAuthorize({
                    code: code,
                    referrer: referrer
                  }).then(function (res) {
                    if (res.code == 0) {
                      wx.setStorageSync('token', res.data.token);
                      wx.setStorageSync('uid', res.data.uid);
                      resolve(res);
                    } else {
                      wx.showToast({
                        title: res.msg,
                        icon: 'none'
                      });
                      reject(res.msg);
                    }
                  });
                } else {
                  WXAPI.authorize({
                    code: code,
                    referrer: referrer
                  }).then(function (res) {
                    if (res.code == 0) {
                      wx.setStorageSync('token', res.data.token);
                      wx.setStorageSync('uid', res.data.uid);
                      resolve(res);
                    } else {
                      wx.showToast({
                        title: res.msg,
                        icon: 'none'
                      });
                      reject(res.msg);
                    }
                  });
                }
              },
              fail: function fail(err) {
                reject(err);
              }
            });
          }));
        case 1:
        case "end":
          return _context5.stop();
      }
    }, _callee5);
  }));
  return _authorize.apply(this, arguments);
}
function loginOut() {
  _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().removeStorageSync('token');
  _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().removeStorageSync('uid');
}
function checkAndAuthorize(_x) {
  return _checkAndAuthorize.apply(this, arguments);
}
function _checkAndAuthorize() {
  _checkAndAuthorize = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_3__["default"])().mark(function _callee6(scope) {
    return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_3__["default"])().wrap(function _callee6$(_context6) {
      while (1) switch (_context6.prev = _context6.next) {
        case 0:
          return _context6.abrupt("return", new Promise(function (resolve, reject) {
            _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().getSetting({
              success: function success(res) {
                if (!res.authSetting[scope]) {
                  _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().authorize({
                    scope: scope,
                    success: function success() {
                      resolve(); // 无返回参数
                    },
                    fail: function fail(e) {
                      console.error(e);
                      // if (e.errMsg.indexof('auth deny') != -1) {
                      //   wx.showToast({
                      //     title: e.errMsg,
                      //     icon: 'none'
                      //   })
                      // }
                      _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().showModal({
                        title: '无权操作',
                        content: '需要获得您的授权',
                        showCancel: false,
                        confirmText: '立即授权',
                        confirmColor: '#e64340',
                        success: function success(res) {
                          _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().openSetting();
                        },
                        fail: function fail(e) {
                          console.error(e);
                          reject(e);
                        }
                      });
                    }
                  });
                } else {
                  resolve(); // 无返回参数
                }
              },
              fail: function fail(e) {
                console.error(e);
                reject(e);
              }
            });
          }));
        case 1:
        case "end":
          return _context6.stop();
      }
    }, _callee6);
  }));
  return _checkAndAuthorize.apply(this, arguments);
}
var mobileRex = /^1[3456789]\d{9}$/;
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({
  checkHasLogined: checkHasLogined,
  // wxaCode: wxaCode,
  // login: login,
  // loginOut: loginOut,
  checkAndAuthorize: checkAndAuthorize,
  // authorize: authorize,
  // bindSeller: bindSeller
  mobileRex: mobileRex
});

/***/ }),

/***/ "./src/utils/index.ts":
/*!****************************!*\
  !*** ./src/utils/index.ts ***!
  \****************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "isTopPage": function() { return /* reexport safe */ _router__WEBPACK_IMPORTED_MODULE_3__.isTopPage; },
/* harmony export */   "mobileRex": function() { return /* reexport safe */ _validator__WEBPACK_IMPORTED_MODULE_1__.mobileRex; },
/* harmony export */   "safeArea": function() { return /* reexport safe */ _safeArea__WEBPACK_IMPORTED_MODULE_2__.safeArea; }
/* harmony export */ });
/* harmony import */ var _auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth */ "./src/utils/auth.ts");
/* harmony import */ var _validator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./validator */ "./src/utils/validator.ts");
/* harmony import */ var _safeArea__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./safeArea */ "./src/utils/safeArea.ts");
/* harmony import */ var _router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./router */ "./src/utils/router.ts");





/***/ }),

/***/ "./src/utils/router.ts":
/*!*****************************!*\
  !*** ./src/utils/router.ts ***!
  \*****************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "isTopPage": function() { return /* binding */ isTopPage; }
/* harmony export */ });
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @tarojs/taro */ "webpack/container/remote/@tarojs/taro");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_0__);

var isTopPage = function isTopPage() {
  var pageLength = _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().getCurrentPages().length;
  return pageLength === 1;
};

/***/ }),

/***/ "./src/utils/safeArea.ts":
/*!*******************************!*\
  !*** ./src/utils/safeArea.ts ***!
  \*******************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "safeArea": function() { return /* binding */ safeArea; }
/* harmony export */ });
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @tarojs/taro */ "webpack/container/remote/@tarojs/taro");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_0__);

var safeArea = function safeArea() {
  try {
    var _systemInfo$safeArea;
    var systemInfo = _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().getSystemInfoSync();
    var screenHeight = systemInfo.screenHeight;
    var safeHeight = ((_systemInfo$safeArea = systemInfo.safeArea) === null || _systemInfo$safeArea === void 0 ? void 0 : _systemInfo$safeArea.bottom) || systemInfo.screenHeight;
    var screenWidth = systemInfo.screenWidth;
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().setStorageSync('safeArea', screenHeight - safeHeight);
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default().setStorageSync('tabBarHeight', Math.floor(50 * screenWidth / 375));
  } catch (e) {
    console.log(e);
  }
};

/***/ }),

/***/ "./src/utils/validator.ts":
/*!********************************!*\
  !*** ./src/utils/validator.ts ***!
  \********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "mobileRex": function() { return /* binding */ mobileRex; }
/* harmony export */ });
/* unused harmony export checkMobile */
var checkMobile = function checkMobile(_, value) {
  if (/^1[3456789]\d{9}$/.test(value)) {
    return Promise.resolve();
  }
  return Promise.reject({
    required: true,
    message: "请输入正确手机号"
  });
};
var mobileRex = /^1[3456789]\d{9}$/;

/***/ }),

/***/ "./src/account/components/topLogo/logo.png":
/*!*************************************************!*\
  !*** ./src/account/components/topLogo/logo.png ***!
  \*************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";
module.exports = __webpack_require__.p + "account/components/topLogo/logo.png";

/***/ }),

/***/ "?67c0":
/*!********************************!*\
  !*** ./util.inspect (ignored) ***!
  \********************************/
/***/ (function() {

/* (ignored) */

/***/ }),

/***/ "?aa67":
/*!********************************!*\
  !*** ./util.inspect (ignored) ***!
  \********************************/
/***/ (function() {

/* (ignored) */

/***/ }),

/***/ "?4f7e":
/*!********************************!*\
  !*** ./util.inspect (ignored) ***!
  \********************************/
/***/ (function() {

/* (ignored) */

/***/ }),

/***/ "../../2023-qj/qj-request-tools/packages/optimize/dist/index.js":
/*!**********************************************************************!*\
  !*** ../../2023-qj/qj-request-tools/packages/optimize/dist/index.js ***!
  \**********************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "cacheParams": function() { return /* binding */ i; },
/* harmony export */   "get": function() { return /* binding */ h; },
/* harmony export */   "post": function() { return /* binding */ f; },
/* harmony export */   "postFormData": function() { return /* reexport safe */ _brushes_request__WEBPACK_IMPORTED_MODULE_0__.postFormData; },
/* harmony export */   "removeRequestCacheByKey": function() { return /* binding */ c; }
/* harmony export */ });
/* unused harmony export requestCache */
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js");
/* harmony import */ var _brushes_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @brushes/request */ "../../2023-qj/qj-request-tools/packages/request/dist/index.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash-es */ "../../2023-qj/qj-request-tools/node_modules/lodash-es/get.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash-es */ "../../2023-qj/qj-request-tools/node_modules/lodash-es/omit.js");






var o = new Map(),
  a = "clearIoCache-true",
  n = function n(e, t) {
    var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    var c = (0,lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"])(n, "needCache", !1),
      i = (0,lodash_es__WEBPACK_IMPORTED_MODULE_2__["default"])(n, ["needCache"]) || {};
    if (!c) return e(t, i);
    if (n.hasOwnProperty(a)) return void function (e) {
      var _iterator = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(o),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var _t = _step.value;
          var _t2 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_4__["default"])(_t, 1),
            _r = _t2[0];
          if (_r.includes(e)) {
            o.delete(_r);
            break;
          }
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }(t);
    var f = t + JSON.stringify(i);
    return o.has(f) || o.set(f, e(t, i)), o.get(f);
  },
  c = function c(e) {
    return e((0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_5__["default"])({}, a, !0));
  },
  i = function i() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return Object.assign(e, {
      needCache: !0
    });
  },
  f = function f(t) {
    var r = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    return n(_brushes_request__WEBPACK_IMPORTED_MODULE_0__.post, t, r);
  },
  h = function h(e) {
    var r = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    return n(_brushes_request__WEBPACK_IMPORTED_MODULE_0__.get, e, r);
  };


/***/ }),

/***/ "../../2023-qj/qj-request-tools/packages/taro-hooks/dist/index.js":
/*!************************************************************************!*\
  !*** ../../2023-qj/qj-request-tools/packages/taro-hooks/dist/index.js ***!
  \************************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TaroContextProvider": function() { return /* binding */ J; },
/* harmony export */   "initApplication": function() { return /* binding */ I; },
/* harmony export */   "useDataSource": function() { return /* binding */ A; },
/* harmony export */   "useDataSourceWithContext": function() { return /* binding */ q; },
/* harmony export */   "useMenu": function() { return /* binding */ j; },
/* harmony export */   "usePageConfig": function() { return /* binding */ T; }
/* harmony export */ });
/* unused harmony exports applicationInfo, fetchMenu, init, loadMenu, useTaroDispatch, useTaroStore */
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js */ "./node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/container/remote/react");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! lodash-es */ "../../2023-qj/qj-request-tools/node_modules/lodash-es/isEmpty.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! lodash-es */ "../../2023-qj/qj-request-tools/node_modules/lodash-es/get.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! lodash-es */ "../../2023-qj/qj-request-tools/node_modules/lodash-es/noop.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! lodash-es */ "../../2023-qj/qj-request-tools/node_modules/lodash-es/pick.js");
/* harmony import */ var _brushes_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @brushes/utils */ "../../2023-qj/qj-request-tools/packages/utils/dist/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @tarojs/taro */ "webpack/container/remote/@tarojs/taro");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-runtime */ "webpack/container/remote/react/jsx-runtime");
/* harmony import */ var use_context_selector__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! use-context-selector */ "../../2023-qj/qj-request-tools/node_modules/use-context-selector/dist/index.modern.js");












function b(t, n, e, o) {
  return new (e || (e = Promise))(function (s, a) {
    function c(t) {
      try {
        i(o.next(t));
      } catch (t) {
        a(t);
      }
    }
    function r(t) {
      try {
        i(o.throw(t));
      } catch (t) {
        a(t);
      }
    }
    function i(t) {
      var n;
      t.done ? s(t.value) : (n = t.value, n instanceof e ? n : new e(function (t) {
        t(n);
      })).then(c, r);
    }
    i((o = o.apply(t, n || [])).next());
  });
}
var y = {};
var v = /*#__PURE__*/function () {
  function v(t) {
    (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_4__["default"])(this, v);
    this.lowCodeGraph = t;
  }
  (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_5__["default"])(v, [{
    key: "init",
    value: function init(t) {
      this.lowCodeGraph = t;
    }
  }]);
  return v;
}();
var P = new Map();
var S = "";
var O = function O() {
  var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : S;
  var n = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : y;
  var e = S = t.toString();
  var o = P.get(e);
  return o || (o = new v(n), P.set(e, o)), o;
};
var _ = {},
  w = {
    tabBar: [],
    subpackage: [],
    menuTreeIo: function menuTreeIo(t) {
      return Promise;
    },
    pageInfoIo: function pageInfoIo(t) {
      return Promise;
    }
  };
var I = function I(t) {
  w = t, _ = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_1__.getTaro)();
};
function j() {
  var _this = this;
  var _t = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]),
    _t2 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_6__["default"])(_t, 2),
    e = _t2[0],
    o = _t2[1];
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
    (function () {
      b(_this, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_7__["default"])().mark(function _callee() {
        var _t3;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_7__["default"])().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.prev = 0;
              _context.t0 = _.getStorageSync("taroMenu");
              if (_context.t0) {
                _context.next = 6;
                break;
              }
              _context.next = 5;
              return C();
            case 5:
              _context.t0 = _context.sent;
            case 6:
              _t3 = _context.t0;
              o(_t3);
              _context.next = 12;
              break;
            case 10:
              _context.prev = 10;
              _context.t1 = _context["catch"](0);
            case 12:
            case "end":
              return _context.stop();
          }
        }, _callee, null, [[0, 10]]);
      }));
    })();
  }, []), e;
}
var C = function C() {
    return b(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_7__["default"])().mark(function _callee2() {
      var _yield$M, _t4;
      return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_7__["default"])().wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            _context2.next = 3;
            return M();
          case 3:
            _yield$M = _context2.sent;
            _t4 = _yield$M.list;
            return _context2.abrupt("return", E(_t4));
          case 8:
            _context2.prev = 8;
            _context2.t0 = _context2["catch"](0);
          case 10:
          case "end":
            return _context2.stop();
        }
      }, _callee2, null, [[0, 8]]);
    }));
  },
  M = function M() {
    return w.menuTreeIo({
      proappCode: "025",
      rows: 50,
      dataState: 2,
      page: 1
    });
  };
function x() {
  return b(this, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_7__["default"])().mark(function _callee3() {
    var _yield$M2, _t5, _n, _G, _e;
    return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_7__["default"])().wrap(function _callee3$(_context3) {
      while (1) switch (_context3.prev = _context3.next) {
        case 0:
          _context3.prev = 0;
          _context3.next = 3;
          return M();
        case 3:
          _yield$M2 = _context3.sent;
          _t5 = _yield$M2.list;
          _n = E(_t5);
          _G = G(_t5);
          _e = _G.routerMap;
          if (!((0,_brushes_utils__WEBPACK_IMPORTED_MODULE_1__.setRouterMap)(_e), [[], void 0, null, ""].includes(_n))) {
            _context3.next = 10;
            break;
          }
          return _context3.abrupt("return", void (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_1__.taroMessage)("租户菜单配置不正确", "error"));
        case 10:
          _.setStorageSync("menuOpcode", _n[0].menuOpcode), _.setStorageSync("taroMenu", _n);
          _context3.next = 15;
          break;
        case 13:
          _context3.prev = 13;
          _context3.t0 = _context3["catch"](0);
        case 15:
        case "end":
          return _context3.stop();
      }
    }, _callee3, null, [[0, 13]]);
  }));
}
var G = function G(t) {
    var n = {},
      e = Object.assign([], w.tabBar);
    return t.forEach(function (t) {
      n[t.menuOpcode] = N(t, e);
    }), {
      routerMap: n
    };
  },
  N = function N(_ref, e) {
    var t = _ref.isColumn,
      n = _ref.tginfoMenuName;
    var o;
    return {
      text: n,
      level: 1 === t ? 1 : 2,
      pagePath: 1 !== t ? w.subpackage.shift() : null === (o = e.shift()) || void 0 === o ? void 0 : o.pagePath
    };
  },
  k = [{
    selectedIconPath: "https://brushes.oss-cn-shanghai.aliyuncs.com/static/mini/tabbar_home_on.png",
    iconPath: "https://brushes.oss-cn-shanghai.aliyuncs.com/static/mini/tabbar_home.png"
  }, {
    selectedIconPath: "https://brushes.oss-cn-shanghai.aliyuncs.com/static/mini/tabbar_cate_on.png",
    iconPath: "https://brushes.oss-cn-shanghai.aliyuncs.com/static/mini/tabbar_cate.png"
  }, {
    selectedIconPath: "https://brushes.oss-cn-shanghai.aliyuncs.com/static/mini/tabbar_cart_on.png",
    iconPath: "https://brushes.oss-cn-shanghai.aliyuncs.com/static/mini/tabbar_cart.png"
  }, {
    selectedIconPath: "https://brushes.oss-cn-shanghai.aliyuncs.com/static/mini/tabbar_my_on.png",
    iconPath: "https://brushes.oss-cn-shanghai.aliyuncs.com/static/mini/tabbar_my.png"
  }, {
    selectedIconPath: "https://brushes.oss-cn-shanghai.aliyuncs.com/static/mini/tabbar_active_on.png",
    iconPath: "https://brushes.oss-cn-shanghai.aliyuncs.com/static/mini/tabbar_active.png"
  }],
  E = function E(t) {
    return t.filter(function (t) {
      return 1 === t.isColumn;
    }).map(function (t, n) {
      return Object.assign(Object.assign(Object.assign({}, k[n]), w.tabBar[n]), {
        level: 1,
        menuOpcode: t.menuOpcode,
        text: t.tginfoMenuName
      });
    });
  };
var T = function T(o) {
  var c = function (e) {
    var _this2 = this;
    var _t6 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]),
      _t7 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_6__["default"])(_t6, 2),
      o = _t7[0],
      c = _t7[1],
      r = O(e);
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
      (function () {
        b(_this2, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_7__["default"])().mark(function _callee4() {
          var t, _n2, n, o, u, p;
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_7__["default"])().wrap(function _callee4$(_context4) {
            while (1) switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return B();
              case 2:
                t = P.get(e);
                if (!(t && !(0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(t.lowCodeGraph))) {
                  _context4.next = 6;
                  break;
                }
                _n2 = t.lowCodeGraph;
                return _context4.abrupt("return", void c(_n2.nodeGraph));
              case 6:
                n = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_1__.getTaro)().getStorageSync("menuOpcode");
                _context4.next = 9;
                return w.pageInfoIo({
                  menuOpcode: n,
                  proappCode: "025",
                  isNew: 1
                });
              case 9:
                o = _context4.sent;
                u = (0,lodash_es__WEBPACK_IMPORTED_MODULE_9__["default"])(o, "modelTagvalueJson", "{}");
                p = JSON.parse(u);
                p.hasOwnProperty("nodeGraph") || ((0,_brushes_utils__WEBPACK_IMPORTED_MODULE_1__.taroMessage)("脏数据, 初始化默认数据", "error"), p = {
                  nodeGraph: [],
                  page: "",
                  version: "",
                  pageConfig: {}
                }), r.init(p), c(p.nodeGraph);
              case 13:
              case "end":
                return _context4.stop();
            }
          }, _callee4);
        }));
      })();
    }, [e]), o;
  }(o);
  return console.log(51, c, o), (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
    var t = {};
    return c.forEach(function (n) {
      var e = (0,lodash_es__WEBPACK_IMPORTED_MODULE_9__["default"])(n, "props.dataSource.pageStore", {});
      Object.assign(t, e);
    }), {
      node: c,
      initialValue: t
    };
  }, [c]);
};
function B() {
  return b(this, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_7__["default"])().mark(function _callee5() {
    var t;
    return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_7__["default"])().wrap(function _callee5$(_context5) {
      while (1) switch (_context5.prev = _context5.next) {
        case 0:
          t = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_1__.getTaro)().getStorageSync("taroMenu") || [];
          _context5.t0 = (0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(t);
          if (!_context5.t0) {
            _context5.next = 5;
            break;
          }
          _context5.next = 5;
          return x();
        case 5:
        case "end":
          return _context5.stop();
      }
    }, _callee5);
  }));
}
var z = (0,use_context_selector__WEBPACK_IMPORTED_MODULE_10__.createContext)([{}, lodash_es__WEBPACK_IMPORTED_MODULE_11__["default"]]);
function J(_ref2) {
  var e = _ref2.initialValue,
    o = _ref2.children;
  var _t8 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(e || {}),
    _t9 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_6__["default"])(_t8, 2),
    s = _t9[0],
    a = _t9[1];
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
    a(e || {});
  }, [e]), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(z.Provider, Object.assign({
    value: [s, a]
  }, {
    children: o
  }));
}
function K(t) {
  return (0,use_context_selector__WEBPACK_IMPORTED_MODULE_10__.useContextSelector)(z, function (n) {
    if (t.size > 1) return n[0];
    {
      var _t$keys = t.keys(),
        _t$keys2 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_6__["default"])(_t$keys, 1),
        _e2 = _t$keys2[0];
      return n[0][_e2];
    }
  }) || {};
}
function V() {
  var t = (0,use_context_selector__WEBPACK_IMPORTED_MODULE_10__.useContextSelector)(z, function (t) {
    return t[1];
  });
  return t || lodash_es__WEBPACK_IMPORTED_MODULE_11__["default"];
}
function q(t) {
  var n = K(t);
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
    if (t.size > 1) {
      var _e3 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_12__["default"])(t.keys()),
        _o = (0,lodash_es__WEBPACK_IMPORTED_MODULE_13__["default"])(n, _e3),
        _s = {};
      return _e3.forEach(function (n) {
        var e = t.get(n);
        _s[e] = _o[n];
      }), _s;
    }
    {
      var _t$values = t.values(),
        _t$values2 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_6__["default"])(_t$values, 1),
        _e4 = _t$values2[0];
      return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_14__["default"])({}, _e4, n);
    }
  }, [n]);
}
function A(n, a, c) {
  var _t10 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0),
    _t11 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_6__["default"])(_t10, 2),
    r = _t11[0],
    i = _t11[1],
    u = V(),
    h = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(""),
    d = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
      var t = (0,lodash_es__WEBPACK_IMPORTED_MODULE_9__["default"])(a, "dataSource.connect", []);
      var n = new Map();
      return t.forEach(function (t) {
        var _s2 = (0,lodash_es__WEBPACK_IMPORTED_MODULE_9__["default"])(t, "prevKey", {}),
          _s2$type = _s2.type,
          e = _s2$type === void 0 ? "" : _s2$type,
          _s2$value = _s2.value,
          o = _s2$value === void 0 ? "" : _s2$value;
        if ("pageStore" === e && !n.has(o)) {
          var _e5 = t.nextKey;
          n.set(o, _e5);
        }
      }), n;
    }, [a]),
    m = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
      return Object.assign(Object.assign({
        withPageStore: d,
        dispatchPageStore: u,
        refreshNum: h.current === n ? r : 0,
        component_devil_type: n
      }, a), c);
    }, [r, u, d]);
  return (0,_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__.useDidShow)(function () {
    var t = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_1__.getPagesRefreshStore)(),
      e = (0,lodash_es__WEBPACK_IMPORTED_MODULE_9__["default"])(t, n, 0);
    0 !== e && ((0,_brushes_utils__WEBPACK_IMPORTED_MODULE_1__.updatePagesRefreshStore)((0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_14__["default"])({}, n, 0)), h.current = n, i(e));
  }), {
    propsType: m,
    withPageStore: d
  };
}


/***/ }),

/***/ "../../qj/lerna-repo/packages/qj-b2c-api/dist/index.js":
/*!*************************************************************!*\
  !*** ../../qj/lerna-repo/packages/qj-b2c-api/dist/index.js ***!
  \*************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "addShoppingGoods": function() { return /* binding */ Ko; },
/* harmony export */   "addShoppingGoodsBySpec": function() { return /* binding */ Wo; },
/* harmony export */   "cancelContractC": function() { return /* binding */ _E; },
/* harmony export */   "checkCollectExit": function() { return /* binding */ I; },
/* harmony export */   "confirmReceive": function() { return /* binding */ fo; },
/* harmony export */   "deleteAddress": function() { return /* binding */ t; },
/* harmony export */   "deleteCollectByCode": function() { return /* binding */ y; },
/* harmony export */   "deleteCollectByCodeStr": function() { return /* binding */ Qo; },
/* harmony export */   "deleteFootprintByCodeStr": function() { return /* binding */ yo; },
/* harmony export */   "deleteShoppingGoodsBatch": function() { return /* binding */ rE; },
/* harmony export */   "find": function() { return /* binding */ L; },
/* harmony export */   "getAddress": function() { return /* binding */ r; },
/* harmony export */   "getContractByCode": function() { return /* binding */ qo; },
/* harmony export */   "getDoclist": function() { return /* binding */ bo; },
/* harmony export */   "getFalgSettingForPaydate": function() { return /* binding */ $o; },
/* harmony export */   "getNotice": function() { return /* binding */ No; },
/* harmony export */   "getResourceGoodsInfoBySkuCode": function() { return /* binding */ d; },
/* harmony export */   "getTotalDiscountPrice": function() { return /* binding */ zo; },
/* harmony export */   "paymentCommit": function() { return /* binding */ J; },
/* harmony export */   "queryAddressBymerberCode": function() { return /* binding */ xo; },
/* harmony export */   "queryCollectPage": function() { return /* binding */ C; },
/* harmony export */   "queryContractPageC": function() { return /* binding */ Z; },
/* harmony export */   "queryCouponListBySkuCode": function() { return /* binding */ OE; },
/* harmony export */   "queryEvaluateGoodsPagetrue": function() { return /* binding */ Fo; },
/* harmony export */   "queryExpressInfo": function() { return /* binding */ Ho; },
/* harmony export */   "queryFootprintPagePlat": function() { return /* binding */ c; },
/* harmony export */   "queryGoodsClassTree": function() { return /* binding */ F; },
/* harmony export */   "queryNoticePage": function() { return /* binding */ ie; },
/* harmony export */   "queryPromotioByCodePage": function() { return /* binding */ wo; },
/* harmony export */   "queryPromotioPage": function() { return /* binding */ mo; },
/* harmony export */   "queryPromotionListByGoodsCode": function() { return /* binding */ D; },
/* harmony export */   "queryShoppingPage": function() { return /* binding */ ko; },
/* harmony export */   "queryShoppingToContract": function() { return /* binding */ sE; },
/* harmony export */   "queryToContract": function() { return /* binding */ Xo; },
/* harmony export */   "queryUseTemplate": function() { return /* binding */ Mo; },
/* harmony export */   "queryUserConByGoods": function() { return /* binding */ TE; },
/* harmony export */   "queryUsercouponPageForC": function() { return /* binding */ u; },
/* harmony export */   "saveAddress": function() { return /* binding */ R; },
/* harmony export */   "saveCollect": function() { return /* binding */ Y; },
/* harmony export */   "saveContract": function() { return /* binding */ Zo; },
/* harmony export */   "saveEvaluateGoods": function() { return /* binding */ ho; },
/* harmony export */   "saveEvaluateShop": function() { return /* binding */ Bo; },
/* harmony export */   "saveFootprint": function() { return /* binding */ Lo; },
/* harmony export */   "saveOrderToPay": function() { return /* binding */ EE; },
/* harmony export */   "saveUsercoupon": function() { return /* binding */ RE; },
/* harmony export */   "syncContractBatchState": function() { return /* binding */ oE; },
/* harmony export */   "syncContractPayState": function() { return /* binding */ A; },
/* harmony export */   "syncContractState": function() { return /* binding */ eE; },
/* harmony export */   "updateAddress": function() { return /* binding */ O; },
/* harmony export */   "updateShoppingGoodsNum": function() { return /* binding */ nE; },
/* harmony export */   "updateShoppingGoodsPmInfo": function() { return /* binding */ SE; }
/* harmony export */ });
/* unused harmony exports INDEX_MEM, LIBARY, balanceRechargeOnline, calculateFreightFare, checkUserPhone, checkUserPhoneByTenant, checkUserPhoneThere, checkVerificationMa, fetchSpeOptByPntCodeNomRel, getContractNumbers, getMiniMobile, getPfsModelTagValue, getPfsModelTagValueByTginfo, getPhoneForPlaRegSc, getProappinfo, getTemporaryToken, getUserInfoAuth, getUserserviceInfo, goodsDetailQuery, goodsQuery, goodsUpdate, login, loginByToken, loginInByCode, loginOut, lowCodeSave, miniLogout, queryAccount, queryBrandRelationPage, queryCheckPaywd, queryClasstreeForUser, queryDoclistPage, queryFilePage, queryFilelistView, queryFreightExpPage, queryImsgPushmsgPage, queryNewTginfoMenuTree, queryOcsconfigList, queryProappConfigByChannel, queryProappEnvPage, queryPromotionPageFullReduction, queryPromotionPageFullReductionManage, queryRechargePageForAtByMem, queryResourceGoodsPagePalt, queryScenePage, querySceneSelectPage, querySceneSproappPage, querySkuNotOnShelf, queryTginfoMenuTree, queryTginfoMenuTreeForTginfo, queryTmProappPageForSc, queryTmscene, queryTmscenePageForSc, queryTmsceneProappPageForSc, queryUsercouponNember, queryUserlogininfoservicePage, regiter, saveProductOrder, saveTmsceneForPlatScNew, saveUmuserPhone, saveUmuserPhoneByWX, saveUmuserPhoneNoCodeByWX, saveUmuserPhoneVCode, saveUserInfoAuth, sendPhone, updateTmsceneTtdeposit, updateUmuserPw, updateUserPaywd, updateUserPhoneByUserPhone, updateUserPsw, uploadGoodsFiles, warrantyLogin */
/* harmony import */ var _brushes_optimize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @brushes/optimize */ "../../2023-qj/qj-request-tools/packages/optimize/dist/index.js");

var n = {
    LOGIN: "web/ml/mlogin/loginIn.json",
    REGISTER: "web/ml/muser/saveUserPhoneForPla.json",
    CHECK_USER_PHONE_THERE: "/web/ml/muser/checkUserPhoneThere.json",
    LOGINOUT: "web/os/osOAuthEnvconfig/queryOsOAuthEnvconfig.json",
    GOODS_QUERY: "web/rs/resourceGoods/queryResGoodsPageByMemCode.json",
    GOODS_UPDATE: "web/rs/resourceGoods/updateAuditOrCannel.json",
    GOODS_DETAIL: "web/rs/resourceGoods/getResourceGoodsInfoBySkuCode.json",
    GOODS_CLASSTREE: "web/rs/classtree/queryClasstreeForUser.json",
    GOODS_BRAND: "web/rs/brandrelation/queryBrandRelationPage.json",
    GOODS_CATEGORE: "web/rs/specOption/fetchSpeOptByPntCodeNomRel.json",
    UPLOAD_FILES: "web/rs/goodsFile/uploadGoodsFiles.json",
    FREIGHT_EXP: "web/wl/freightExp/queryFreightExpPage.json",
    QUERY_SkU_Shelf: "web/rs/sku/querySkuNotOnShelf.json",
    LOW_CODE_SAVE: "web/pfs/pfsmodeltagvalue/updatePfsModelTagValueDomain.json",
    QUERY_TMSCENE: "web/tm/Tmtmscene/queryTmscenePageForSc.json",
    QUERY_ACCOUNTOUTERBYUSER: "web/vd/vdfaccountouter/queryAccountOuterByUser.json",
    QUERY_IMSGPUSHMSGPAGE: "web/mns/mnsblist/queryMnsblistPage.json",
    GET_USER_INFO_AUTH: "web/um/userInfoAuth/getUserInfoAuth.json",
    QUERY_USERLOGININFOSERVICE: "web/log/logservice/queryLogservicePage.json",
    QUERY_CONTRACTPAGEC: "web/oc/contract/queryContractPageC.json",
    QUERYR_ECHARGEPAGEFORATBYMEM: "web/cp/recharge/queryRechargePageForAtByMem.json",
    BALANCE_RECHARGE_ONLINE: "web/cp/recharge/balanceRechargeOnline.json",
    PAYMENT_COMMIT: "web/pte/pay/paymentCommit.json",
    QUERY_TMSCENEPAGEFORSC: "web/tm/Tmtmscene/queryTmscenePageForSc.json",
    QUERY_SCENESPROAPPPAGE: "web/tm/sceneSproapp/querySceneSproappPage.json",
    QUERY_TMPROAPPPAGEFORSC: "web/tm/Tmscene/queryTmProappPageForSc.json",
    CHECK_USERPHONEBYENANT: "web/ml/muser/checkUserPhoneByTenant.json",
    SAVE_TMSCENEFORPLATSCNEW: "web/tm/Tmtmscene/saveTmsceneForPlatScNew.json",
    GET_PROAPPINFO: "web/ml/mlogin/getProappinfo.json",
    QUERY_SCENESELECTPAGE: "web/tm/Tmtmscene/querySceneSelectPage.json",
    QUERY_FILE_LIST_VIEW: "web/fm/file/queryFilelistView.json",
    SAVE_USERINFO_AUTH: "web/um/userInfoAuth/saveUserInfoAuth.json",
    UPDATE_USER_PAYWD: "web/um/userservice/updateUserPaywd.json",
    UPDATE_USER_PSW: "web/um/userservice/updateUserpsw.json",
    SEND_PHONE: "web/ml/muser/sendPhone.json",
    LOGIN_IN_BY_CODE: "web/ml/mlogin/loginInByCode.json",
    CHECK_USER_PHONE: "web/ml/muser/checkUserPhone.json",
    GET_PHONE_FOR_PLA_REG_SC: "web/ml/muser/getPhoneForPlaRegSc.json",
    UPDATE_UMUSER_PSW: "web/ml/muser/updateUmuserPw.json",
    FIND: "web/es/searchengine/find.json",
    QUERY_GOODS_CLASS_TREE: "web/rs/rsGoodsClass/queryGoodsClassTree.json",
    GET_RESOURCE_GOODS_INFO_BY_SKU_CODE: "web/rs/resourceGoods/getResourceGoodsInfoBySkuCode.json",
    QUERY_PROMOTION_LIST_BY_GOODS_CODE: "web/pm/promotion/queryPromotionListByGoodsCode.json",
    CHECK_COLLECT_EXIT: "web/um/collect/checkCollectExit.json",
    SAVE_COLLECT: "web/um/collect/saveCollect.json",
    DELETE_COLLECT_BY_CODE: "web/um/collect/deleteCollectByCode.json",
    GET_PFS_MODEL_TAG_VALUE: "/web/pfs/pfsmodeltagvalue/getPfsModelTagValue.json",
    GET_PFS_MODEL_TAG_VALUE_BY_TG_INFO: "web/pfs/pfsmodeltagvalue/getPfsModelTagValueByTginfo.json",
    SAVE_PRODUCTORDER: "web/tm/Tmtmscene/saveProductOrder.json",
    QUERY_TMSCENEPROAPPPAGE_FORSC: "web/tm/Tmtmscene/queryTmsceneProappPageForSc.json",
    GET_USERSERVICE_INFO: "web/um/userservice/getUserserviceInfo.json",
    QUERY_CHECKPAYWD: "web/um/userservice/queryCheckPaywd.json",
    UPDATE_TMSCENETTDEPOSIT: "web/tm/Tmtmscene/updateTmsceneTtdeposit.json",
    QUERY_SCENEPAGE: "web/tm/Scene/queryScenePage.json",
    QUERY_TG_INFO_MENU_TREE: "web/cms/tginfoMenu/queryTginfoMenuTree.json",
    QUERY_TG_INFO_MENU_TREE_FOR_TG_INFO: "web/cms/tginfoMenu/queryTginfoMenuTreeForTginfo.json",
    SYNC_CONTRACTPAYSTATE: "web/oc/contract/syncContractPayState.json",
    GET_TEMPORARY_TOKEN: "web/ml/mlogin/getTemporaryToken.json",
    LOGIN_WITHOUT_PASSWORD: "web/ml/mlogin/loginWithoutPassword.json",
    QUERY_USERCOUPONNEMBER: "web/pm/usercoupon/queryUsercouponNember.json",
    QUERY_USERCOUPONPAGE_FORC: "web/pm/usercoupon/queryUsercouponPageForC.json",
    QUERY_COLLECTPAGE: "web/um/collect/queryCollectPage.json",
    QUERY_ADDRESS_BYMERBERCODE: "web/um/address/queryAddressBymerberCode.json",
    QUERY_FOOTPRINTPAGEPLAT: "web/um/footprint/queryFootprintPagePlat.json",
    INDEX_MEM: "web/mi/mindex/indexMem.json",
    CHECK_VERIFICATIONMA: "web/um/userservice/checkVerificationMa.json",
    UPDATE_USERPHONE_BYUSERPHONE: "web/um/userservice/updateUserPhoneByUserPhone.json",
    SAVE_ADDRESS: "web/um/address/saveAddress.json",
    DELETE_ADDRESS: "web/um/address/deleteAddress.json",
    UPDATE_ADDRESS: "web/um/address/updateAddress.json",
    GET_ADDRESS: "/web/um/address/getAddress.json",
    GET_CONTRACT_NUMBERS: "/web/oc/contract/getContractNumbers.json",
    QUERY_RESOURCE_GOODS_PAGE_PALT: "/web/rs/resourceGoods/queryResourceGoodsPagePalt.json",
    LOGIN_BY_TOKEN: "web/ml/mlogin/loginByToken.json",
    QUERY_NOTICE_PAGE: "web/cms/notice/queryNoticePage.json",
    QUERY_FILE_PAGE: "web/fm/file/queryFilePage.json",
    QUERY_PROMOTION_PAGE_FULL_REDUCTION: "web/pm/promotion/queryPromotionPageFullReduction.json"
  },
  _ = function _() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.GET_CONTRACT_NUMBERS, o);
  },
  r = function r() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.GET_ADDRESS, o);
  },
  t = function t() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.DELETE_ADDRESS, o);
  },
  O = function O() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.UPDATE_ADDRESS, o);
  },
  R = function R() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.SAVE_ADDRESS, o);
  },
  T = function T() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.UPDATE_USERPHONE_BYUSERPHONE, e);
  },
  P = function P() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.CHECK_VERIFICATIONMA, e);
  },
  S = function S() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.INDEX_MEM, o);
  },
  c = function c() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.QUERY_FOOTPRINTPAGEPLAT, e);
  },
  C = function C() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.QUERY_COLLECTPAGE, e);
  },
  u = function u() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.QUERY_USERCOUPONPAGE_FORC, e);
  },
  a = function a() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.QUERY_USERCOUPONNEMBER, e);
  },
  U = function U() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.GET_TEMPORARY_TOKEN, e);
  },
  A = function A() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.SYNC_CONTRACTPAYSTATE, e);
  },
  m = function m() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.CHECK_USER_PHONE_THERE, e);
  },
  w = function w() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.QUERY_TG_INFO_MENU_TREE_FOR_TG_INFO, e);
  },
  b = function b() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.QUERY_TG_INFO_MENU_TREE, e);
  },
  G = function G() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.QUERY_SCENEPAGE, e);
  },
  N = function N() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.UPDATE_TMSCENETTDEPOSIT, e);
  },
  i = function i() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.QUERY_TMSCENEPROAPPPAGE_FORSC, o);
  },
  l = function l() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.GET_USERSERVICE_INFO, o);
  },
  j = function j() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.QUERY_CHECKPAYWD, e);
  },
  p = function p() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.SAVE_PRODUCTORDER, e);
  },
  g = function g() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.GET_PFS_MODEL_TAG_VALUE_BY_TG_INFO, (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.cacheParams)(e));
  },
  d = function d() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.GET_RESOURCE_GOODS_INFO_BY_SKU_CODE, (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.cacheParams)(o));
  },
  D = function D() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.QUERY_PROMOTION_LIST_BY_GOODS_CODE, o);
  },
  I = function I() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.CHECK_COLLECT_EXIT, o);
  },
  Y = function Y() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.SAVE_COLLECT, o);
  },
  y = function y() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.DELETE_COLLECT_BY_CODE, o);
  },
  L = function L() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.FIND, (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.cacheParams)(o));
  },
  F = function F() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.QUERY_GOODS_CLASS_TREE, (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.cacheParams)(o));
  },
  M = function M() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.GET_PROAPPINFO, o);
  },
  h = function h() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.SAVE_TMSCENEFORPLATSCNEW, e);
  },
  B = function B() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.CHECK_USERPHONEBYENANT, o);
  },
  Q = function Q() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.QUERY_TMPROAPPPAGEFORSC, o);
  },
  f = function f() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.QUERY_SCENESPROAPPPAGE, e);
  },
  q = function q() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.UPDATE_UMUSER_PSW, e);
  },
  H = function H() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.GET_PHONE_FOR_PLA_REG_SC, o);
  },
  v = function v() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.CHECK_USER_PHONE, e);
  },
  V = function V() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.LOGIN_IN_BY_CODE, o);
  },
  W = function W() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.SEND_PHONE, o);
  },
  K = function K() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var E = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "";
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)("".concat(n.QUERY_FILE_LIST_VIEW, "?fileSort=FILE_GD&fileRemark=").concat(E), e);
  },
  k = function k() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.QUERY_FILE_PAGE, e);
  },
  x = function x() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.QUERY_SCENESELECTPAGE, e);
  },
  X = function X() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.QUERY_TMSCENEPAGEFORSC, o);
  },
  $ = function $() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.QUERYR_ECHARGEPAGEFORATBYMEM, e);
  },
  z = function z() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.BALANCE_RECHARGE_ONLINE, e);
  },
  J = function J() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.PAYMENT_COMMIT, e);
  },
  Z = function Z() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.QUERY_CONTRACTPAGEC, e);
  },
  ee = function ee() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.QUERY_USERLOGININFOSERVICE, e);
  },
  oe = function oe() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.GET_USER_INFO_AUTH, e);
  },
  Ee = function Ee() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.QUERY_TMSCENE, o);
  },
  se = function se() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.QUERY_ACCOUNTOUTERBYUSER, o);
  },
  ne = function ne() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.QUERY_IMSGPUSHMSGPAGE, e);
  },
  _e = function _e() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.LOGIN, e);
  },
  re = function re() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.REGISTER, e);
  },
  te = function te() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.LOGINOUT, o);
  },
  Oe = function Oe() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var E = Object.assign({
      rows: 10,
      page: 1
    }, e);
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.GOODS_QUERY, E);
  },
  Re = function Re() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.GOODS_UPDATE, e);
  },
  Te = function Te() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.GOODS_CLASSTREE, o);
  },
  Pe = function Pe() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.GOODS_BRAND, o);
  },
  Se = function Se() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.GOODS_CATEGORE, e);
  },
  ce = function ce() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.postFormData)(n.UPLOAD_FILES, e);
  },
  Ce = function Ce() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.FREIGHT_EXP, e);
  },
  ue = function ue() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.QUERY_SkU_Shelf, e);
  },
  ae = function ae() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.LOW_CODE_SAVE, e);
  },
  Ue = function Ue() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(n.GOODS_DETAIL, o);
  },
  Ae = function Ae() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.UPDATE_USER_PSW, e);
  },
  me = function me() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.UPDATE_USER_PAYWD, e);
  },
  we = function we() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.postFormData)(n.SAVE_USERINFO_AUTH, e);
  },
  be = function be() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.GET_PFS_MODEL_TAG_VALUE, e);
  },
  Ge = function Ge() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.QUERY_RESOURCE_GOODS_PAGE_PALT, e);
  },
  Ne = function Ne() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.LOGIN_BY_TOKEN, e);
  },
  ie = function ie() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.QUERY_NOTICE_PAGE, e);
  },
  le = function le() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(n.QUERY_PROMOTION_PAGE_FULL_REDUCTION, e);
  },
  je = "web/cms/tginfoMenu/queryNewTginfoMenuTree.json",
  pe = "web/ml/mlogin/warrantyLogin.json",
  ge = "web/ml/muser/saveUmuserPhoneByWX.json",
  de = "web/oc/shopping/addShoppingGoodsBySpec.json",
  De = "web/oc/shopping/addShoppingGoods.json",
  Ie = "web/oc/shopping/queryShoppingPage.json",
  Ye = "web/um/address/queryAddressBymerberCode.json",
  ye = "web/oc/shopping/queryToContract.json",
  Le = "web/dd/falgSetting/getFalgSettingForPaydate.json",
  Fe = "web/ur/userrights/getTotalDiscountPrice.json",
  Me = "web/oc/contract/calculateFreightFare.json",
  he = "web/oc/contract/saveContract.json",
  Be = "web/oc/contract/syncContractState.json",
  Qe = "web/oc/contract/syncContractBatchState.json",
  fe = "web/pte/pay/saveOrderToPay.json",
  qe = "web/oc/shopping/queryShoppingToContract.json",
  He = "web/oc/shopping/updateShoppingGoodsNum.json",
  ve = "web/oc/contract/cancelContractC.json",
  Ve = "web/oc/shopping/deleteShoppingGoodsBatch.json",
  We = "web/wl/exporg/queryExpressInfo.json",
  Ke = "web/oc/contract/getContractByCode.json",
  ke = "web/oc/contract/confirmReceive.json",
  xe = "web/um/collect/deleteCollectByCodeStr.json",
  Xe = "web/res/evaluate/saveEvaluateShop.json",
  $e = "web/res/evaluate/saveEvaluateGoods.json",
  ze = "web/res/template/queryUseTemplate.json",
  Je = "web/res/evaluate/queryEvaluateGoodsPagetrue.json",
  Ze = "web/pm/promotion/queryPromotionPageFullReduction.json",
  eo = "web/pm/promotion/queryCouponListBySkuCode.json",
  oo = "web/pm/usercoupon/saveUsercoupon.json",
  Eo = "web/oc/contract/queryUserConByGoods.json",
  so = "web/um/footprint/saveFootprint.json",
  no = "web/um/footprint/deleteFootprintByCodeStr.json",
  _o = "web/ml/muser/saveUmuserPhone.json",
  ro = "web/ml/muser/saveUmuserPhoneVCode.json",
  to = "web/tm/Proapp/queryProappConfigByChannel.json",
  Oo = "/web/ml/mlogin/loginOut.json",
  Ro = "/web/ocs/ocsconfig/queryOcsconfigList.json",
  To = "/web/tm/Proapp/queryProappEnvPage.json",
  Po = "/web/ml/mlogin/getMiniMobile.json",
  So = "/web/ml/muser/saveUmuserPhoneNoCodeByWX.json",
  co = "/web/cms/notice/getNotice.json",
  Co = "/web/cms/doclist/queryDoclistPage.json",
  uo = "web/oc/shopping/updateShoppingGoodsPmInfo.json",
  ao = "/web/cms/doclist/getDoclist.json",
  Uo = "/web/pm/promotion/queryPromotioByCodePage.json",
  Ao = "/web/pm/promotion/queryPromotioPage.json",
  mo = function mo() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(Ao, e);
  },
  wo = function wo() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(Uo, e);
  },
  bo = function bo() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(ao, e);
  },
  Go = function Go() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(Co, e);
  },
  No = function No() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(co, o);
  },
  io = function io() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(So, e);
  },
  lo = function lo() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(Po, e);
  },
  jo = function jo() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(To, o);
  },
  po = function po() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(Ro, o);
  },
  go = function go() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(Oo, e);
  },
  Do = function Do() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(to, o);
  },
  Io = function Io() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(ro, e);
  },
  Yo = function Yo() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(_o, e);
  },
  yo = function yo() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(no, e);
  },
  Lo = function Lo() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(so, (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.cacheParams)(e));
  },
  Fo = function Fo() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(Je, e);
  },
  Mo = function Mo() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(ze, e);
  },
  ho = function ho() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)($e, e);
  },
  Bo = function Bo() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(Xe, e);
  },
  Qo = function Qo() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(xe, e);
  },
  fo = function fo() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(ke, e);
  },
  qo = function qo() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(Ke, o);
  },
  Ho = function Ho() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(We, o);
  },
  vo = function vo() {
    var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.get)(pe, o);
  },
  Vo = function Vo() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(ge, e);
  },
  Wo = function Wo() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(de, e);
  },
  Ko = function Ko() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(De, e);
  },
  ko = function ko() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(Ie, e);
  },
  xo = function xo() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(Ye, (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.cacheParams)(e));
  },
  Xo = function Xo() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(ye, (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.cacheParams)(e));
  },
  $o = function $o() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(Le, e);
  },
  zo = function zo() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(Fe, e);
  },
  Jo = function Jo() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(Me, e);
  },
  Zo = function Zo() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(he, e);
  },
  eE = function eE() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(Be, e);
  },
  oE = function oE() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(Qe, e);
  },
  EE = function EE() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(fe, e);
  },
  sE = function sE() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(qe, (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.cacheParams)(e));
  },
  nE = function nE() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(He, e);
  },
  _E = function _E() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(ve, e);
  },
  rE = function rE() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(Ve, e);
  },
  tE = function tE() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(Ze, e);
  },
  OE = function OE() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(eo, e);
  },
  RE = function RE() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(oo, e);
  },
  TE = function TE() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(Eo, e);
  },
  PE = function PE() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(je, e);
  },
  SE = function SE() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_0__.post)(uo, e);
  };


/***/ }),

/***/ "../../qj/lerna-repo/packages/qj-mobile-store/dist/index.js":
/*!******************************************************************!*\
  !*** ../../qj/lerna-repo/packages/qj-mobile-store/dist/index.js ***!
  \******************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApplicationContext": function() { return /* binding */ le; },
/* harmony export */   "StoreProvider": function() { return /* binding */ no; },
/* harmony export */   "orderStatusImpl": function() { return /* binding */ Uo; },
/* harmony export */   "orderStatusList": function() { return /* binding */ qo; },
/* harmony export */   "popupImplement": function() { return /* binding */ At; },
/* harmony export */   "routerMap": function() { return /* binding */ Io; },
/* harmony export */   "useAddCoupon": function() { return /* binding */ Vt; },
/* harmony export */   "useAddShopping": function() { return /* binding */ Et; },
/* harmony export */   "useAddressItem": function() { return /* binding */ eo; },
/* harmony export */   "useAddressList": function() { return /* binding */ oo; },
/* harmony export */   "useAllCoupon": function() { return /* binding */ de; },
/* harmony export */   "useApplicationContext": function() { return /* binding */ ue; },
/* harmony export */   "useArticleDetail": function() { return /* binding */ re; },
/* harmony export */   "useBanner": function() { return /* binding */ qt; },
/* harmony export */   "useCartItem": function() { return /* binding */ ro; },
/* harmony export */   "useCartList": function() { return /* binding */ ao; },
/* harmony export */   "useCartListNext": function() { return /* binding */ uo; },
/* harmony export */   "useCartOperate": function() { return /* binding */ po; },
/* harmony export */   "useCartTop": function() { return /* binding */ mo; },
/* harmony export */   "useCollectionList": function() { return /* binding */ te; },
/* harmony export */   "useCoupon": function() { return /* binding */ Wt; },
/* harmony export */   "useCouponList": function() { return /* binding */ go; },
/* harmony export */   "useCube": function() { return /* binding */ Jo; },
/* harmony export */   "useEditAddress": function() { return /* binding */ to; },
/* harmony export */   "useEvaluate": function() { return /* binding */ Qt; },
/* harmony export */   "useEvaluateDetail": function() { return /* binding */ oe; },
/* harmony export */   "useExpressInfo": function() { return /* binding */ Yo; },
/* harmony export */   "useFootprint": function() { return /* binding */ ee; },
/* harmony export */   "useGoTop": function() { return /* binding */ pe; },
/* harmony export */   "useGoodCollection": function() { return /* binding */ $t; },
/* harmony export */   "useGoodDetail": function() { return /* binding */ Jt; },
/* harmony export */   "useGoodFootprint": function() { return /* binding */ Yt; },
/* harmony export */   "useGoodSku": function() { return /* binding */ zt; },
/* harmony export */   "useGoodSkuStore": function() { return /* binding */ Dt; },
/* harmony export */   "useGoods": function() { return /* binding */ se; },
/* harmony export */   "useGoodsClassify": function() { return /* binding */ Zo; },
/* harmony export */   "useGoodsList": function() { return /* binding */ Co; },
/* harmony export */   "useGoodsShare": function() { return /* binding */ Xt; },
/* harmony export */   "useMarketingPromotion": function() { return /* binding */ me; },
/* harmony export */   "useNotice": function() { return /* binding */ ne; },
/* harmony export */   "useNoticeDetail": function() { return /* binding */ ce; },
/* harmony export */   "useOrderAddress": function() { return /* binding */ jo; },
/* harmony export */   "useOrderCoupon": function() { return /* binding */ Eo; },
/* harmony export */   "useOrderDetail": function() { return /* binding */ Qo; },
/* harmony export */   "useOrderGood": function() { return /* binding */ Fo; },
/* harmony export */   "useOrderInfo": function() { return /* binding */ Po; },
/* harmony export */   "useOrderList": function() { return /* binding */ Wo; },
/* harmony export */   "useOrderOperate": function() { return /* binding */ zo; },
/* harmony export */   "useOrderPay": function() { return /* binding */ Vo; },
/* harmony export */   "useOrderResult": function() { return /* binding */ So; },
/* harmony export */   "useOrderResultResult": function() { return /* binding */ Ro; },
/* harmony export */   "usePromotion": function() { return /* binding */ _t; },
/* harmony export */   "useStore": function() { return /* binding */ co; }
/* harmony export */ });
/* unused harmony exports addressInitial, computedParams, createStore, detailButton, getGoodDetail, getGoodDetailWithCache, goodListIntialValue, goodListMock, goodStore, initalOrderValue, initialCoupon, initialValue, initialValueOrder, makeStore, orderGoodValue, orderStore, orderType, routerMapArr, useDispatchImpl, useOverdue, usePlaceOrder, useUnused, useUsed, userAddressData */
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js */ "./node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js");
/* harmony import */ var _Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "webpack/container/remote/react/jsx-runtime");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/container/remote/react");
/* harmony import */ var qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! qj-b2c-api */ "../../qj/lerna-repo/packages/qj-b2c-api/dist/index.js");
/* harmony import */ var _brushes_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @brushes/utils */ "../../2023-qj/qj-request-tools/packages/utils/dist/index.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash-es */ "../../qj/lerna-repo/node_modules/lodash-es/get.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! lodash-es */ "../../qj/lerna-repo/node_modules/lodash-es/isEmpty.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! lodash-es */ "../../qj/lerna-repo/node_modules/lodash-es/groupBy.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! lodash-es */ "../../qj/lerna-repo/node_modules/lodash-es/noop.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! lodash-es */ "../../qj/lerna-repo/node_modules/lodash-es/isFunction.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! lodash-es */ "../../qj/lerna-repo/node_modules/lodash-es/set.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! lodash-es */ "../../qj/lerna-repo/node_modules/lodash-es/orderBy.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! lodash-es */ "../../qj/lerna-repo/node_modules/lodash-es/isUndefined.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! lodash-es */ "../../qj/lerna-repo/node_modules/lodash-es/isEqual.js");
/* harmony import */ var _brushes_optimize__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @brushes/optimize */ "../../2023-qj/qj-request-tools/packages/optimize/dist/index.js");
/* provided dependency */ var document = __webpack_require__(/*! @tarojs/runtime */ "webpack/container/remote/@tarojs/runtime")["document"];










function It(c, i) {
  var r = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(null),
    s = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(null);
  return [function (_ref) {
    var o = _ref.children;
    var _e = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(c, i),
      _e2 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_e, 2),
      n = _e2[0],
      d = _e2[1];
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(r.Provider, Object.assign({
      value: d
    }, {
      children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(s.Provider, Object.assign({
        value: n
      }, {
        children: o
      }))
    }));
  }, function () {
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(s);
  }, function () {
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(r);
  }];
}
function kt(t) {
  var o = t;
  var e = new Set();
  return {
    getState: function getState() {
      return o;
    },
    setState: function setState(t) {
      o = t, e.forEach(function (t) {
        return t(o);
      });
    },
    subscribe: function subscribe(t) {
      return e.add(t), function () {
        return e.delete(t);
      };
    }
  };
}
var Mt = kt({
  count: 1,
  isNeedButton: !1,
  popupVisible: !1,
  goodsNum: 1,
  spec: [],
  orderType: 0
});
function Dt() {
  var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : function (t) {
    return t;
  };
  return (0,react__WEBPACK_IMPORTED_MODULE_1__.useSyncExternalStore)(Mt.subscribe, function () {
    return t(Mt.getState());
  });
}
function Bt(t, o, e, n) {
  return new (e || (e = Promise))(function (c, i) {
    function r(t) {
      try {
        d(n.next(t));
      } catch (t) {
        i(t);
      }
    }
    function s(t) {
      try {
        d(n.throw(t));
      } catch (t) {
        i(t);
      }
    }
    function d(t) {
      var o;
      t.done ? c(t.value) : (o = t.value, o instanceof e ? o : new e(function (t) {
        t(o);
      })).then(r, s);
    }
    d((n = n.apply(t, o || [])).next());
  });
}
var jt = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)(),
  Gt = function Gt(t, o) {
    return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee() {
      var e;
      return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            e = {
              specStr: JSON.stringify(t),
              goodsCode: o
            };
            _context.next = 3;
            return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.addShoppingGoodsBySpec)(e);
          case 3:
            return _context.abrupt("return", _context.sent);
          case 4:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }));
  },
  wt = function wt(t, o) {
    return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee2() {
      var e;
      return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            e = {
              skuId: t,
              goodsNum: o,
              isLocalMock: !jt
            };
            _context2.next = 3;
            return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryToContract)(e);
          case 3:
            return _context2.abrupt("return", _context2.sent);
          case 4:
          case "end":
            return _context2.stop();
        }
      }, _callee2);
    }));
  };
function Tt(t) {
  var o = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)();
  return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.getResourceGoodsInfoBySkuCode)({
    skuCode: t,
    isLocalMock: !o
  });
}
function At() {
  var t = function t(_t2) {
    var o = function (t) {
      var o = Mt.getState();
      switch (t.type) {
        case "plus":
          return Object.assign(Object.assign({}, o), {
            count: o.count + 1
          });
        case "minus":
          return Object.assign(Object.assign({}, o), {
            count: o.count - 1
          });
        case "select":
        case "initGoodSku":
        case "popupImpl":
          return Object.assign(Object.assign({}, o), t.payload);
        default:
          return o;
      }
    }(_t2);
    Mt.setState(o);
  };
  return {
    dispatch: t,
    openPopup: function openPopup() {
      t({
        type: "popupImpl",
        payload: {
          popupVisible: !0,
          isNeedButton: !1
        }
      });
    },
    closePopup: function closePopup() {
      t({
        type: "popupImpl",
        payload: {
          popupVisible: !1
        }
      });
    },
    addCardPopup: function addCardPopup() {
      t({
        type: "popupImpl",
        payload: {
          popupVisible: !0,
          orderType: 0,
          isNeedButton: !0
        }
      });
    },
    buyOpenPopup: function buyOpenPopup() {
      t({
        type: "popupImpl",
        payload: {
          popupVisible: !0,
          orderType: 1,
          isNeedButton: !0
        }
      });
    }
  };
}
var xt = new Map(),
  Ft = function Ft(t) {
    var o = xt.get(t);
    return o || (o = Tt(t), xt.set(t, o)), o;
  };
function Et(t, o) {
  var _this = this;
  var e = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(0),
    _At = At(),
    n = _At.dispatch,
    c = _At.closePopup;
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    var t = (0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(o, "spec", []);
    e.current = (0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(o, "goodsNum", 1), (0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(t) || n({
      type: "initGoodSku",
      payload: {
        count: 1,
        spec: t
      }
    });
  }, [o]);
  var s = function s() {
      return Bt(_this, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee4() {
        var _o2, _e3, _n, _i, _at, _at$CartList, _r, _s, _d;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee4$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              _context4.prev = 0;
              _o2 = Mt.getState();
              _e3 = _o2.spec;
              _n = _o2.count;
              _context4.next = 6;
              return Gt(_e3, t);
            case 6:
              _i = _context4.sent;
              _at = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getPagesRefreshStore)();
              _at$CartList = _at.CartList;
              _r = _at$CartList === void 0 ? 0 : _at$CartList;
              (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.updatePagesRefreshStore)({
                CartList: _r + 1
              });
              _s = (0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(_i, "dataObj.skuId");
              _context4.next = 14;
              return function (t, o) {
                return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee3() {
                  var e;
                  return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee3$(_context3) {
                    while (1) switch (_context3.prev = _context3.next) {
                      case 0:
                        e = {
                          skuId: t,
                          goodsNum: o
                        };
                        _context3.next = 3;
                        return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.addShoppingGoods)(e);
                      case 3:
                        return _context3.abrupt("return", _context3.sent);
                      case 4:
                      case "end":
                        return _context3.stop();
                    }
                  }, _callee3);
                }));
              }(_s, _n);
            case 14:
              _d = _context4.sent;
              _context4.next = 17;
              return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.taroMessage)(_d.msg || "添加成功");
            case 17:
              c();
              _context4.next = 24;
              break;
            case 20:
              _context4.prev = 20;
              _context4.t0 = _context4["catch"](0);
              _context4.next = 24;
              return (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.taroMessage)("无法登录", "error");
            case 24:
            case "end":
              return _context4.stop();
          }
        }, _callee4, null, [[0, 20]]);
      }));
    },
    d = function d() {
      return Bt(_this, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee5() {
        var o, e, n, c, i;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee5$(_context5) {
          while (1) switch (_context5.prev = _context5.next) {
            case 0:
              o = Mt.getState();
              e = o.spec;
              n = o.count;
              _context5.next = 5;
              return Gt(e, t);
            case 5:
              c = _context5.sent;
              i = (0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(c, "dataObj.skuId");
              (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("orderDetermine", {
                skuId: i,
                goodsNum: n
              });
            case 8:
            case "end":
              return _context5.stop();
          }
        }, _callee5);
      }));
    };
  return {
    addCardImpl: s,
    cashImpl: d,
    handleChooseSize: function handleChooseSize(t, o) {
      var e = Mt.getState(),
        c = e.spec;
      c[o] = t, n({
        type: "select",
        payload: {
          spec: (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_9__["default"])(c)
        }
      });
    },
    handleStep: function handleStep(t) {
      var _Mt$getState = Mt.getState(),
        o = _Mt$getState.count;
      0 !== o || "minus" !== t ? "plus" !== t || o !== e.current ? n({
        type: t
      }) : (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.taroMessage)("超库存", "none") : (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.taroMessage)("不能小于0", "none");
    },
    addShoppingImpl: function addShoppingImpl() {
      var t = Mt.getState(),
        o = t.orderType;
      0 === o ? s() : d();
    }
  };
}
var Vt = function Vt() {
    var _s2 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!1),
      _s3 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s2, 2),
      t = _s3[0],
      o = _s3[1];
    return {
      save: function save(e) {
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee6() {
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee6$(_context6) {
            while (1) switch (_context6.prev = _context6.next) {
              case 0:
                if (t) {
                  _context6.next = 9;
                  break;
                }
                _context6.prev = 1;
                _context6.next = 4;
                return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.saveUsercoupon)(e);
              case 4:
                o(!0);
                _context6.next = 9;
                break;
              case 7:
                _context6.prev = 7;
                _context6.t0 = _context6["catch"](1);
              case 9:
              case "end":
                return _context6.stop();
            }
          }, _callee6, null, [[1, 7]]);
        }));
      },
      isPick: t
    };
  },
  Rt = {
    rsGoodsFileDomainList: [],
    rsSpecValueDomainList: [],
    goodsRemark: "",
    pricesetNprice: 0,
    goodsName: "",
    dataPic: "",
    goodsShowname: "",
    goodsNum: 0,
    goodsCode: "",
    skuNo: "",
    classtreeCode: "",
    brandCode: "",
    pntreeCode: "",
    memberCode: "",
    rsSkuDomainList: []
  },
  Jt = function Jt(t) {
    var _s4 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(Rt),
      _s5 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s4, 2),
      o = _s5[0],
      e = _s5[1];
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee7() {
        var _o3;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee7$(_context7) {
          while (1) switch (_context7.prev = _context7.next) {
            case 0:
              _context7.prev = 0;
              _context7.next = 3;
              return Tt(t);
            case 3:
              _o3 = _context7.sent;
              e(_o3 || Rt);
              _context7.next = 9;
              break;
            case 7:
              _context7.prev = 7;
              _context7.t0 = _context7["catch"](0);
            case 9:
            case "end":
              return _context7.stop();
          }
        }, _callee7, null, [[0, 7]]);
      }));
    }, []), o;
  },
  qt = function qt(t) {
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
      return t.map(function (t) {
        return {
          imgUrl: t.goodsFileUrl,
          link: ""
        };
      });
    }, [t]);
  },
  Ut = {
    dataObj: ""
  };
function $t(_ref2) {
  var _this2 = this;
  var t = _ref2.skuCode,
    o = _ref2.dataPic,
    e = _ref2.goodsName,
    n = _ref2.pricesetNprice;
  var _s6 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(Ut),
    _s7 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s6, 2),
    c = _s7[0],
    i = _s7[1];
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    d();
  }, []);
  var d = function d() {
      return Bt(_this2, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee8() {
        var o, _t3;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee8$(_context8) {
          while (1) switch (_context8.prev = _context8.next) {
            case 0:
              o = {
                collectType: 0,
                collectOpcode: t
              };
              _context8.prev = 1;
              _context8.next = 4;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.checkCollectExit)(o);
            case 4:
              _t3 = _context8.sent;
              i(_t3);
              _context8.next = 11;
              break;
            case 8:
              _context8.prev = 8;
              _context8.t0 = _context8["catch"](1);
              console.log(_context8.t0);
            case 11:
            case "end":
              return _context8.stop();
          }
        }, _callee8, null, [[1, 8]]);
      }));
    },
    a = function a() {
      return Bt(_this2, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee9() {
        var c;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee9$(_context9) {
          while (1) switch (_context9.prev = _context9.next) {
            case 0:
              c = {
                collectType: 0,
                collectOpcode: t,
                collectOppic: o,
                collectOpcont: e,
                collectOpnum: n,
                goodsOrigin: 0
              };
              _context9.next = 3;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.saveCollect)(c);
            case 3:
              return _context9.abrupt("return", _context9.sent);
            case 4:
            case "end":
              return _context9.stop();
          }
        }, _callee9);
      }));
    },
    l = function l() {
      return Bt(_this2, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee10() {
        var t;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee10$(_context10) {
          while (1) switch (_context10.prev = _context10.next) {
            case 0:
              t = {
                collectType: 0,
                collectCode: c.dataObj || ""
              };
              _context10.next = 3;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.deleteCollectByCode)(t);
            case 3:
              return _context10.abrupt("return", _context10.sent);
            case 4:
            case "end":
              return _context10.stop();
          }
        }, _callee10);
      }));
    };
  return {
    handleCollect: function handleCollect() {
      return Bt(_this2, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee11() {
        var t;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee11$(_context11) {
          while (1) switch (_context11.prev = _context11.next) {
            case 0:
              t = Ut;
              if (!(0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(c.dataObj)) {
                _context11.next = 7;
                break;
              }
              _context11.next = 4;
              return a();
            case 4:
              _context11.t0 = _context11.sent;
              _context11.next = 10;
              break;
            case 7:
              _context11.next = 9;
              return l();
            case 9:
              _context11.t0 = _context11.sent;
            case 10:
              t = _context11.t0;
              i(t);
              (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_4__.removeRequestCacheByKey)(qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryCollectPage);
            case 13:
            case "end":
              return _context11.stop();
          }
        }, _callee11);
      }));
    },
    collection: c
  };
}
function zt(t) {
  var _Jt = Jt(t),
    o = _Jt.rsSpecValueDomainList,
    e = _Jt.dataPic,
    n = _Jt.goodsCode,
    c = _Jt.goodsNum,
    i = _Jt.goodsShowname,
    r = _Jt.pricesetNprice;
  return {
    skuInfo: (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
      var t = function (t) {
          var o = (0,lodash_es__WEBPACK_IMPORTED_MODULE_10__["default"])(t, "specName");
          return o ? Object.keys(o).map(function (t) {
            return {
              skuName: t,
              skuOption: o[t]
            };
          }) : [];
        }(o),
        n = t.map(function (t) {
          return (0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(t, "skuOption[0].specValueValue");
        });
      return {
        dataPic: e,
        goodsShowname: i,
        pricesetNprice: r,
        skuList: t,
        spec: n,
        goodsNum: c
      };
    }, [o]),
    goodsCode: n
  };
}
var Ht = function Ht(t) {
    return {
      skuCode: (0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(t, "rsSkuDomainList[0].skuCode", ""),
      skuNo: t.skuNo,
      classtreeCode: t.classtreeCode,
      brandCode: t.brandCode,
      pntreeCode: t.pntreeCode,
      memberCode: t.memberCode
    };
  },
  Kt = {
    promotionBegintime: "",
    pbName: "",
    discName: "",
    promotionCode: "",
    promotionName: "",
    couponOnceNums: 0,
    couponOnceNumd: 0,
    promotionEndtime: ""
  };
function Wt(t) {
  var _this3 = this;
  var _s8 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]),
    _s9 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s8, 2),
    o = _s9[0],
    e = _s9[1],
    _s10 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!1),
    _s11 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s10, 2),
    n = _s11[0],
    c = _s11[1];
  return (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    (function () {
      Bt(_this3, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee12() {
        var o, n, c;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee12$(_context12) {
          while (1) switch (_context12.prev = _context12.next) {
            case 0:
              _context12.next = 2;
              return Ft(t);
            case 2:
              o = _context12.sent;
              n = Ht(o);
              if (!(0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(o.skuNo)) {
                _context12.next = 6;
                break;
              }
              return _context12.abrupt("return");
            case 6:
              _context12.next = 8;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryCouponListBySkuCode)(n);
            case 8:
              c = _context12.sent;
              e(c);
            case 10:
            case "end":
              return _context12.stop();
          }
        }, _callee12);
      }));
    })();
  }, []), {
    coupon: o,
    visible: n,
    setVisible: c
  };
}
function _t(t) {
  var _this4 = this;
  var _s12 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]),
    _s13 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s12, 2),
    o = _s13[0],
    e = _s13[1];
  return (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    (function () {
      Bt(_this4, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee13() {
        var o, n, c;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee13$(_context13) {
          while (1) switch (_context13.prev = _context13.next) {
            case 0:
              _context13.next = 2;
              return Ft(t);
            case 2:
              o = _context13.sent;
              n = Ht(o);
              if (!(0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(o.skuNo)) {
                _context13.next = 6;
                break;
              }
              return _context13.abrupt("return");
            case 6:
              _context13.next = 8;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryPromotionListByGoodsCode)(n);
            case 8:
              c = _context13.sent;
              e(c);
            case 10:
            case "end":
              return _context13.stop();
          }
        }, _callee13);
      }));
    })();
  }, []), o;
}
var Qt = function Qt(t) {
    var _s14 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]),
      _s15 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s14, 2),
      o = _s15[0],
      e = _s15[1];
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee14() {
        var _o4;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee14$(_context14) {
          while (1) switch (_context14.prev = _context14.next) {
            case 0:
              _context14.prev = 0;
              if (t) {
                _context14.next = 3;
                break;
              }
              return _context14.abrupt("return");
            case 3:
              _context14.next = 5;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryEvaluateGoodsPagetrue)({
                goodsCode: t,
                page: 1,
                rows: 10
              });
            case 5:
              _o4 = _context14.sent;
              e(_o4 || []);
              _context14.next = 11;
              break;
            case 9:
              _context14.prev = 9;
              _context14.t0 = _context14["catch"](0);
            case 11:
            case "end":
              return _context14.stop();
          }
        }, _callee14, null, [[0, 9]]);
      }));
    }, [t]), o;
  },
  Xt = function Xt() {
    return {
      handleShare: function handleShare() {
        if (!(0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)()) return;
        (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getTaro)().showShareMenu({
          withShareTicket: !0,
          success: function success() {
            console.log("share success");
          }
        });
      }
    };
  },
  Yt = function Yt(t) {
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee15() {
        var _o5;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee15$(_context15) {
          while (1) switch (_context15.prev = _context15.next) {
            case 0:
              _context15.prev = 0;
              _context15.next = 3;
              return Tt(t);
            case 3:
              _o5 = _context15.sent;
              (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.saveFootprint)({
                footprintType: 0,
                footprintOpcode: t,
                footprintOppic: _o5.dataPic,
                footprintOpcont: _o5.goodsName,
                footprintOpnum: _o5.pricesetNprice,
                footprintOpurl: ""
              });
              _context15.next = 10;
              break;
            case 7:
              _context15.prev = 7;
              _context15.t0 = _context15["catch"](0);
              console.log(_context15.t0);
            case 10:
            case "end":
              return _context15.stop();
          }
        }, _callee15, null, [[0, 7]]);
      }));
    }, []);
  },
  Zt = "00000017";
function to(t, o, e) {
  var _this5 = this;
  var _o$useForm = o.useForm(),
    _o$useForm2 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_o$useForm, 1),
    n = _o$useForm2[0],
    _s16 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("1"),
    _s17 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s16, 2),
    c = _s17[0],
    i = _s17[1],
    _s18 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!0),
    _s19 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s18, 2),
    d = _s19[0],
    a = _s19[1],
    _s20 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
      provinceCode: "",
      provinceName: "",
      cityCode: "",
      cityName: "",
      areaCode: "",
      areaName: ""
    }),
    _s21 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s20, 2),
    l = _s21[0],
    u = _s21[1];
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    t || !e ? p() : (n.setFieldValue("addressDefault", c), a(!1));
  }, []);
  var p = function p() {
    (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.getAddress)({
      addressId: t,
      isLocalMock: !e
    }).then(function (t) {
      var o = {
        provinceCode: t.provinceCode,
        cityCode: t.cityCode,
        areaCode: t.areaCode,
        provinceName: t.provinceName,
        cityName: t.cityName,
        areaName: t.areaName
      };
      u(o), i(t.addressDefault), n.setFieldValue("addressMember", t.addressMember), n.setFieldValue("addressPhone", t.addressPhone), n.setFieldValue("addressDetail", t.addressDetail), n.setFieldValue("area", o), n.setFieldValue("addressDefault", t.addressDefault), n.validateFields(), a(!1);
    });
  };
  return {
    skullShow: d,
    form: n,
    area: l,
    setArea: u,
    userCode: Zt,
    defaultAddress: c,
    handleArea: function handleArea(t, o) {
      var e = {
        provinceCode: "",
        cityCode: "",
        areaCode: "",
        provinceName: "",
        cityName: "",
        areaName: ""
      };
      if ("weapp" === t) {
        var _t4 = o.detail.code,
          _n2 = o.detail.value;
        e.provinceCode = _t4[0], e.cityCode = _t4[1], e.areaCode = _t4[2], e.provinceName = _n2[0], e.cityName = _n2[1], e.areaName = _n2[2];
      } else "h5" === t && (e.provinceCode = o.provinceCode, e.cityCode = o.cityCode, e.areaCode = o.areaCode, e.provinceName = o.provinceName, e.cityName = o.cityName, e.areaName = o.areaName);
      u(e), n.setFieldValue("area", e), n.validateFields();
    },
    handleDefaultAddress: function handleDefaultAddress(t, o) {
      "h5" === t ? i(o ? "1" : "0") : "weapp" === t && i(o.detail.value ? "1" : "0");
    },
    handleFinish: function handleFinish(o) {
      return Bt(_this5, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee16() {
        var e, _at2, _at2$AddressList, _o6, n;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee16$(_context16) {
          while (1) switch (_context16.prev = _context16.next) {
            case 0:
              o.addressDefault = o.addressDefault ? "1" : "0";
              e = Object.assign(o, o.area);
              delete e.area;
              _context16.prev = 3;
              _context16.next = 6;
              return n = Object.assign(Object.assign({}, e), {
                userCode: Zt
              }), t ? (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.updateAddress)(Object.assign({
                addressId: t
              }, n)) : (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.saveAddress)(n);
            case 6:
              _at2 = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getPagesRefreshStore)(), _at2$AddressList = _at2.AddressList, _o6 = _at2$AddressList === void 0 ? 0 : _at2$AddressList;
              (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.updatePagesRefreshStore)({
                AddressList: ++_o6
              }), (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_4__.removeRequestCacheByKey)(qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryAddressBymerberCode), (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorBackImpl)(-1);
              _context16.next = 12;
              break;
            case 10:
              _context16.prev = 10;
              _context16.t0 = _context16["catch"](3);
            case 12:
            case "end":
              return _context16.stop();
          }
        }, _callee16, null, [[3, 10]]);
      }));
    }
  };
}
function oo(t) {
  var _this6 = this;
  var _s22 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]),
    _s23 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s22, 2),
    o = _s23[0],
    e = _s23[1],
    _s24 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!0),
    _s25 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s24, 2),
    n = _s25[0],
    c = _s25[1];
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    i();
  }, [t]);
  var i = function i() {
      return Bt(_this6, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee17() {
        var t, o;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee17$(_context17) {
          while (1) switch (_context17.prev = _context17.next) {
            case 0:
              t = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)();
              _context17.next = 3;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryAddressBymerberCode)({
                isLocalMock: !t
              });
            case 3:
              o = _context17.sent;
              e(o), c(!1);
            case 5:
            case "end":
              return _context17.stop();
          }
        }, _callee17);
      }));
    },
    d = function d(t, o) {
      var e = o[t];
      return o[t] = o[0], o[t].addressDefault = "0", o[0] = e, o[0].addressDefault = "1", (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_9__["default"])(o);
    };
  return {
    list: o,
    skullShow: n,
    delAddress: function delAddress(t) {
      if (!(0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)()) return;
      (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getTaro)().showModal({
        title: "提示",
        content: "确认删除该地址吗？",
        success: function success(o) {
          return Bt(_this6, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee18() {
            return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee18$(_context18) {
              while (1) switch (_context18.prev = _context18.next) {
                case 0:
                  _context18.t0 = null == o ? void 0 : o.confirm;
                  if (!_context18.t0) {
                    _context18.next = 6;
                    break;
                  }
                  _context18.next = 4;
                  return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.deleteAddress)({
                    addressId: t.addressId
                  });
                case 4:
                  _context18.next = 6;
                  return i();
                case 6:
                case "end":
                  return _context18.stop();
              }
            }, _callee18);
          }));
        }
      });
    },
    setDefault: function setDefault(t, n) {
      return Bt(_this6, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee19() {
        var _c, _r2, _s26, _a, _l, _u, _p, _m, _g, _y, _v, _f, _h;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee19$(_context19) {
          while (1) switch (_context19.prev = _context19.next) {
            case 0:
              if (!("1" !== t.addressDefault)) {
                _context19.next = 7;
                break;
              }
              _c = t.addressMember, _r2 = t.addressPhone, _s26 = t.provinceCode, _a = t.provinceName, _l = t.cityCode, _u = t.cityName, _p = t.areaCode, _m = t.areaName, _g = t.addressDetail, _y = t.addressId, _v = t.addressCode, _f = t.dataState, _h = {
                addressMember: _c,
                addressPhone: _r2,
                provinceCode: _s26,
                provinceName: _a,
                cityCode: _l,
                cityName: _u,
                areaCode: _p,
                areaName: _m,
                addressDetail: _g,
                addressId: _y,
                addressCode: _v,
                dataState: _f,
                addressDefault: "1"
              };
              e(d(n, o));
              _context19.next = 5;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.updateAddress)(_h);
            case 5:
              _context19.next = 7;
              return i();
            case 7:
            case "end":
              return _context19.stop();
          }
        }, _callee19);
      }));
    },
    getAddressList: i
  };
}
function eo(t) {
  return {
    handlerImpl: function handlerImpl() {
      (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.updatePagesRefreshStore)({
        PlaceOrderAddress: t.addressId
      }), (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorBackImpl)(1);
    }
  };
}
var _It = It(function (t, o) {
    switch (o.type) {
      case "select":
        return Object.assign(Object.assign({}, t), {
          select: o.payload
        });
      case "update":
        return Object.assign(Object.assign({}, t), o.payload);
      default:
        return t;
    }
  }, {
    id: "",
    count: 0,
    loading: !1,
    select: []
  }),
  _It2 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_It, 3),
  no = _It2[0],
  co = _It2[1],
  io = _It2[2],
  ro = function ro() {
    var t = io(),
      _co = co(),
      o = _co.select;
    return {
      select: o,
      onChange: function onChange(o) {
        t({
          type: "select",
          payload: o.detail.value
        });
      },
      handleStep: function handleStep(o, e, n) {
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee20() {
          var c;
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee20$(_context20) {
            while (1) switch (_context20.prev = _context20.next) {
              case 0:
                if (!(0 === e && "minus" === n)) {
                  _context20.next = 2;
                  break;
                }
                return _context20.abrupt("return", void (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.taroMessage)("不能小于0", "none"));
              case 2:
                c = "plus" === n ? ++e : --e;
                t({
                  type: "update",
                  payload: {
                    id: o,
                    count: c,
                    loading: !0
                  }
                });
              case 4:
              case "end":
                return _context20.stop();
            }
          }, _callee20);
        }));
      }
    };
  },
  so = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)(),
  ao = function ao(t) {
    var _s27 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]),
      _s28 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s27, 2),
      o = _s28[0],
      e = _s28[1],
      _s29 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0),
      _s30 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s29, 2),
      n = _s30[0],
      c = _s30[1],
      a = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)([]),
      l = io(),
      _co2 = co(),
      u = _co2.select,
      p = _co2.id,
      m = _co2.count,
      g = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
        var t = 0,
          e = 0;
        return o.forEach(function (o) {
          u.includes(o.shoppingGoodsId + "") && (t += o.goodsCamount, e += o.goodsCamount * o.pricesetNprice);
        }), {
          num: t,
          amount: e
        };
      }, [u, o]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee21() {
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee21$(_context21) {
          while (1) switch (_context21.prev = _context21.next) {
            case 0:
              _context21.next = 2;
              return v("isFirst");
            case 2:
            case "end":
              return _context21.stop();
          }
        }, _callee21);
      }));
    }, [t]), (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      p && y(p, m);
    }, [p, m]);
    var y = function y(t, o) {
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee22() {
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee22$(_context22) {
            while (1) switch (_context22.prev = _context22.next) {
              case 0:
                _context22.prev = 0;
                _context22.next = 3;
                return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.updateShoppingGoodsNum)({
                  shoppingGoodsId: t,
                  amount: o,
                  goodWeight: 0
                });
              case 3:
                _context22.next = 5;
                return v();
              case 5:
                _context22.next = 10;
                break;
              case 7:
                _context22.prev = 7;
                _context22.t0 = _context22["catch"](0);
                console.log(_context22.t0);
              case 10:
              case "end":
                return _context22.stop();
            }
          }, _callee22, null, [[0, 7]]);
        }));
      },
      v = function v() {
        var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee23() {
          var _o7, _n3, _i2, _r3;
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee23$(_context23) {
            while (1) switch (_context23.prev = _context23.next) {
              case 0:
                _context23.prev = 0;
                _context23.next = 3;
                return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryShoppingPage)({
                  isLocalMock: !so
                });
              case 3:
                _o7 = _context23.sent;
                _n3 = (0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(_o7, "list", []);
                _i2 = [];
                _r3 = 0;
                _n3.forEach(function (t) {
                  var _vt = (0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(t, "shoppingpackageList[0]", {
                      shoppingGoodsList: [],
                      disMoney: 0
                    }),
                    o = _vt.shoppingGoodsList,
                    _vt$disMoney = _vt.disMoney,
                    e = _vt$disMoney === void 0 ? 0 : _vt$disMoney;
                  _i2.push.apply(_i2, (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_9__["default"])(o)), _r3 += e || 0;
                }), a.current = _i2.map(function (t) {
                  return t.shoppingGoodsId + "";
                }), t && l({
                  type: "select",
                  payload: a.current
                }), l({
                  type: "update",
                  payload: {
                    loading: !1
                  }
                }), c(_r3), e(_i2);
                _context23.next = 13;
                break;
              case 10:
                _context23.prev = 10;
                _context23.t0 = _context23["catch"](0);
                (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.taroMessage)(_context23.t0.msg);
              case 13:
              case "end":
                return _context23.stop();
            }
          }, _callee23, null, [[0, 10]]);
        }));
      };
    return {
      cartList: o,
      initImpl: v,
      disMoney: n,
      amount: g,
      selectAll: function selectAll(t) {
        l({
          type: "select",
          payload: t.detail.value.includes("true") ? a.current : []
        });
      },
      allCart: a,
      toOrderImpl: function toOrderImpl() {
        var _at3 = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getPagesRefreshStore)(),
          _at3$CartList = _at3.CartList,
          t = _at3$CartList === void 0 ? 0 : _at3$CartList;
        (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.updatePagesRefreshStore)({
          CartList: t + 1
        }), (0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_4__.removeRequestCacheByKey)(qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryShoppingToContract), (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("orderDetermine", {
          shoppingGoodsId: u.join(",")
        });
      },
      select: u,
      deleteCart: function deleteCart() {
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee24() {
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee24$(_context24) {
            while (1) switch (_context24.prev = _context24.next) {
              case 0:
                _context24.prev = 0;
                _context24.next = 3;
                return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.deleteShoppingGoodsBatch)({
                  shoppingGoodsIdStr: JSON.stringify(u)
                });
              case 3:
                _context24.next = 5;
                return v();
              case 5:
                _context24.next = 10;
                break;
              case 7:
                _context24.prev = 7;
                _context24.t0 = _context24["catch"](0);
                console.log(_context24.t0);
              case 10:
              case "end":
                return _context24.stop();
            }
          }, _callee24, null, [[0, 7]]);
        }));
      }
    };
  },
  lo = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)(),
  uo = function uo(t, o) {
    var e = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : lodash_es__WEBPACK_IMPORTED_MODULE_11__["default"];
    var _s31 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]),
      _s32 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s31, 2),
      n = _s32[0],
      c = _s32[1],
      _s33 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!1),
      _s34 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s33, 2),
      d = _s34[0],
      a = _s34[1],
      l = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee25() {
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee25$(_context25) {
          while (1) switch (_context25.prev = _context25.next) {
            case 0:
              _context25.next = 2;
              return u("isFirst");
            case 2:
            case "end":
              return _context25.stop();
          }
        }, _callee25);
      }));
    }, [t]), (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee26() {
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee26$(_context26) {
          while (1) switch (_context26.prev = _context26.next) {
            case 0:
              _context26.next = 2;
              return u();
            case 2:
            case "end":
              return _context26.stop();
          }
        }, _callee26);
      }));
    }, [o]);
    var u = function u() {
        var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee27() {
          var _o8;
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee27$(_context27) {
            while (1) switch (_context27.prev = _context27.next) {
              case 0:
                _context27.prev = 0;
                a(!0);
                _context27.next = 4;
                return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryShoppingPage)({
                  isLocalMock: !lo
                });
              case 4:
                _o8 = _context27.sent;
                p(_o8, t);
                _context27.next = 11;
                break;
              case 8:
                _context27.prev = 8;
                _context27.t0 = _context27["catch"](0);
                console.log(_context27.t0);
              case 11:
                _context27.prev = 11;
                a(!1);
                return _context27.finish(11);
              case 14:
              case "end":
                return _context27.stop();
            }
          }, _callee27, null, [[0, 8, 11, 14]]);
        }));
      },
      p = function p(t, o) {
        var e = (0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(t, "list", []),
          n = [];
        e.forEach(function (t) {
          var o = (0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(t, "shoppingpackageList", []);
          n.push.apply(n, (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_9__["default"])(o));
        }), c(n), m(n, o);
      },
      m = function m(t, o) {
        l.current = g(t);
        var n = l.current.map(function (t) {
          return t.shoppingGoodsId + "";
        });
        o ? y({
          detail: {
            value: n
          }
        }) : e(function (t) {
          return Object.assign(Object.assign({}, t), {
            cartInfo: l.current
          });
        });
      },
      g = function g(t) {
        var o = [];
        return t.forEach(function (t) {
          o.push.apply(o, (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_9__["default"])(t.shoppingGoodsList));
        }), o;
      },
      y = function y(t) {
        e(function (o) {
          return console.log(96, o), Object.assign(Object.assign({}, o), {
            cartInfo: l.current,
            cartSelect: t.detail.value
          });
        });
      };
    return {
      cartList: n,
      loading: d,
      onChange: y,
      handleStep: function handleStep(t, o, e) {
        if (0 === o && "minus" === e) return void (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.taroMessage)("不能小于0", "none");
        (function (t, o) {
          Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee28() {
            return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee28$(_context28) {
              while (1) switch (_context28.prev = _context28.next) {
                case 0:
                  _context28.prev = 0;
                  _context28.next = 3;
                  return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.updateShoppingGoodsNum)({
                    shoppingGoodsId: t,
                    amount: o,
                    goodWeight: 0
                  });
                case 3:
                  _context28.next = 5;
                  return u();
                case 5:
                  _context28.next = 10;
                  break;
                case 7:
                  _context28.prev = 7;
                  _context28.t0 = _context28["catch"](0);
                  console.log(_context28.t0);
                case 10:
                case "end":
                  return _context28.stop();
              }
            }, _callee28, null, [[0, 7]]);
          }));
        })(t, "plus" === e ? ++o : --o);
      },
      updatePm: function updatePm(t, o) {
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee29() {
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee29$(_context29) {
            while (1) switch (_context29.prev = _context29.next) {
              case 0:
                _context29.prev = 0;
                _context29.next = 3;
                return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.updateShoppingGoodsPmInfo)({
                  shoppingGoodsId: t,
                  promotionCode: o
                });
              case 3:
                _context29.next = 5;
                return u();
              case 5:
                _context29.next = 10;
                break;
              case 7:
                _context29.prev = 7;
                _context29.t0 = _context29["catch"](0);
                console.log(_context29.t0);
              case 10:
              case "end":
                return _context29.stop();
            }
          }, _callee29, null, [[0, 7]]);
        }));
      }
    };
  };
function po() {
  var _this7 = this;
  var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
  var o = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
  var e = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : lodash_es__WEBPACK_IMPORTED_MODULE_11__["default"];
  var n = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
    var e = 0,
      n = 0;
    return o.forEach(function (o) {
      t.includes(o.shoppingGoodsId + "") && (e += o.goodsCamount, n += o.goodsCamount * o.pricesetNprice);
    }), {
      num: e,
      amount: n,
      disMoney: 0
    };
  }, [t, o]);
  return {
    toOrderImpl: function toOrderImpl() {
      0 !== t.length ? ((0,_brushes_optimize__WEBPACK_IMPORTED_MODULE_4__.removeRequestCacheByKey)(qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryShoppingToContract), (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("orderDetermine", {
        shoppingGoodsId: t.join(",")
      })) : (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.taroMessage)("购物数量不能为空");
    },
    deleteCart: function deleteCart() {
      return Bt(_this7, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee30() {
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee30$(_context30) {
          while (1) switch (_context30.prev = _context30.next) {
            case 0:
              _context30.prev = 0;
              _context30.next = 3;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.deleteShoppingGoodsBatch)({
                shoppingGoodsIdStr: JSON.stringify(t)
              });
            case 3:
              e(function (t) {
                var o = t.cartUpdateCount || 0;
                return Object.assign(Object.assign({}, t), {
                  cartUpdateCount: ++o
                });
              });
              _context30.next = 9;
              break;
            case 6:
              _context30.prev = 6;
              _context30.t0 = _context30["catch"](0);
              console.log(_context30.t0);
            case 9:
            case "end":
              return _context30.stop();
          }
        }, _callee30, null, [[0, 6]]);
      }));
    },
    selectAll: function selectAll(t) {
      e(function (e) {
        return console.log(35, e), Object.assign(Object.assign({}, e), {
          cartSelect: t.detail.value.includes("true") ? (n = o, n.map(function (t) {
            return t.shoppingGoodsId + "";
          })) : []
        });
        var n;
      });
    },
    cartDetail: n
  };
}
function mo() {
  var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : lodash_es__WEBPACK_IMPORTED_MODULE_11__["default"];
  var _s35 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!1),
    _s36 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s35, 2),
    o = _s36[0],
    e = _s36[1];
  return {
    isEditor: o,
    editorImpl: function editorImpl() {
      e(function (o) {
        return t(function (t) {
          return Object.assign(Object.assign({}, t), {
            cartIsEditor: !o
          });
        }), !o;
      });
    }
  };
}
var go = function go() {
    var _s37 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]),
      _s38 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s37, 2),
      t = _s38[0],
      o = _s38[1],
      e = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(0),
      n = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(1),
      c = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(10),
      d = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)([{
        id: 1,
        label: "未使用",
        dataState: 0,
        styleName: "unused",
        text: ""
      }, {
        id: 2,
        label: "已使用",
        dataState: 1,
        styleName: "used"
      }, {
        id: 3,
        label: "已失效",
        dataState: 2,
        styleName: "overdue"
      }]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee31() {
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee31$(_context31) {
          while (1) switch (_context31.prev = _context31.next) {
            case 0:
              _context31.next = 2;
              return a();
            case 2:
            case "end":
              return _context31.stop();
          }
        }, _callee31);
      }));
    }, []);
    var a = function a() {
      return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee32() {
        var _t5;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee32$(_context32) {
          while (1) switch (_context32.prev = _context32.next) {
            case 0:
              console.log("list", t);
              _context32.prev = 1;
              _context32.next = 4;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryUsercouponPageForC)({
                page: n.current,
                rows: c.current,
                dataState: d.current[e.current].dataState,
                pbCode: "0004,0005"
              });
            case 4:
              _t5 = _context32.sent;
              o(function (o) {
                return o.concat(_t5.list || []);
              }), n.current += 1;
              _context32.next = 11;
              break;
            case 8:
              _context32.prev = 8;
              _context32.t0 = _context32["catch"](1);
              console.log(_context32.t0);
            case 11:
            case "end":
              return _context32.stop();
          }
        }, _callee32, null, [[1, 8]]);
      }));
    };
    return {
      config: d,
      coe: e,
      list: t,
      setList: o,
      getList: a,
      switchTab: function switchTab(t) {
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee33() {
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee33$(_context33) {
            while (1) switch (_context33.prev = _context33.next) {
              case 0:
                e.current = t;
                n.current = 1;
                o([]);
                _context33.next = 5;
                return a();
              case 5:
              case "end":
                return _context33.stop();
            }
          }, _callee33);
        }));
      }
    };
  },
  yo = function yo() {
    var _s39 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]),
      _s40 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s39, 2),
      t = _s40[0],
      o = _s40[1],
      e = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(1);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee34() {
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee34$(_context34) {
          while (1) switch (_context34.prev = _context34.next) {
            case 0:
              _context34.next = 2;
              return n();
            case 2:
            case "end":
              return _context34.stop();
          }
        }, _callee34);
      }));
    }, []);
    var n = function n() {
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee35() {
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee35$(_context35) {
            while (1) switch (_context35.prev = _context35.next) {
              case 0:
                e.current = 1;
                o([]);
                _context35.next = 4;
                return c();
              case 4:
              case "end":
                return _context35.stop();
            }
          }, _callee35);
        }));
      },
      c = function c() {
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee36() {
          var _t6;
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee36$(_context36) {
            while (1) switch (_context36.prev = _context36.next) {
              case 0:
                _context36.prev = 0;
                _context36.next = 3;
                return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryUsercouponPageForC)({
                  page: e.current,
                  rows: 100,
                  dataState: 0,
                  pbCode: "0004,0005"
                });
              case 3:
                _t6 = _context36.sent;
                o(_t6.list), e.current += 1;
                _context36.next = 10;
                break;
              case 7:
                _context36.prev = 7;
                _context36.t0 = _context36["catch"](0);
                console.log(_context36.t0);
              case 10:
              case "end":
                return _context36.stop();
            }
          }, _callee36, null, [[0, 7]]);
        }));
      };
    return {
      unusedList: t,
      getData: c,
      init: n
    };
  },
  vo = function vo() {
    var _s41 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]),
      _s42 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s41, 2),
      t = _s42[0],
      o = _s42[1],
      e = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(1);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee37() {
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee37$(_context37) {
          while (1) switch (_context37.prev = _context37.next) {
            case 0:
              _context37.next = 2;
              return n();
            case 2:
            case "end":
              return _context37.stop();
          }
        }, _callee37);
      }));
    }, []);
    var n = function n() {
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee38() {
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee38$(_context38) {
            while (1) switch (_context38.prev = _context38.next) {
              case 0:
                e.current = 1;
                o([]);
                _context38.next = 4;
                return c();
              case 4:
              case "end":
                return _context38.stop();
            }
          }, _callee38);
        }));
      },
      c = function c() {
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee39() {
          var _t7;
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee39$(_context39) {
            while (1) switch (_context39.prev = _context39.next) {
              case 0:
                _context39.prev = 0;
                _context39.next = 3;
                return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryUsercouponPageForC)({
                  page: e.current,
                  rows: 100,
                  dataState: 1,
                  pbCode: "0004,0005"
                });
              case 3:
                _t7 = _context39.sent;
                o(_t7.list), e.current += 1;
                _context39.next = 10;
                break;
              case 7:
                _context39.prev = 7;
                _context39.t0 = _context39["catch"](0);
                console.log(_context39.t0);
              case 10:
              case "end":
                return _context39.stop();
            }
          }, _callee39, null, [[0, 7]]);
        }));
      };
    return {
      usedList: t,
      getData: c,
      init: n
    };
  },
  fo = function fo() {
    var _s43 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]),
      _s44 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s43, 2),
      t = _s44[0],
      o = _s44[1],
      e = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(1);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee40() {
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee40$(_context40) {
          while (1) switch (_context40.prev = _context40.next) {
            case 0:
              _context40.next = 2;
              return n();
            case 2:
            case "end":
              return _context40.stop();
          }
        }, _callee40);
      }));
    }, []);
    var n = function n() {
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee41() {
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee41$(_context41) {
            while (1) switch (_context41.prev = _context41.next) {
              case 0:
                e.current = 1;
                o([]);
                _context41.next = 4;
                return c();
              case 4:
              case "end":
                return _context41.stop();
            }
          }, _callee41);
        }));
      },
      c = function c() {
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee42() {
          var _t8;
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee42$(_context42) {
            while (1) switch (_context42.prev = _context42.next) {
              case 0:
                _context42.prev = 0;
                _context42.next = 3;
                return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryUsercouponPageForC)({
                  page: e.current,
                  rows: 100,
                  dataState: 2,
                  pbCode: "0004,0005"
                });
              case 3:
                _t8 = _context42.sent;
                o(_t8.list), e.current += 1;
                _context42.next = 10;
                break;
              case 7:
                _context42.prev = 7;
                _context42.t0 = _context42["catch"](0);
                console.log(_context42.t0);
              case 10:
              case "end":
                return _context42.stop();
            }
          }, _callee42, null, [[0, 7]]);
        }));
      };
    return {
      overdueList: t,
      getData: c,
      init: n
    };
  };
function ho(t) {
  var o = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
  return o.current = (0,lodash_es__WEBPACK_IMPORTED_MODULE_12__["default"])(t) ? t : lodash_es__WEBPACK_IMPORTED_MODULE_11__["default"], (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(function () {
    return o.current.apply(o, arguments);
  }, [o]);
}
var Co = function Co(t, o, e) {
  var n = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(!0),
    c = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(0),
    _s45 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]),
    _s46 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s45, 2),
    d = _s46[0],
    a = _s46[1],
    _s47 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!1),
    _s48 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s47, 2),
    l = _s48[0],
    u = _s48[1];
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    p();
  }, [e]);
  var p = ho(function () {
      c.current = 0, n.current = !0, a([]), m(e);
    }),
    m = ho(function (_ref3) {
      var _ref3$sortField = _ref3.sortField,
        e = _ref3$sortField === void 0 ? "pricesetNprice" : _ref3$sortField,
        _ref3$order = _ref3.order,
        i = _ref3$order === void 0 ? "" : _ref3$order;
      return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee43() {
        var _r4;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee43$(_context43) {
          while (1) switch (_context43.prev = _context43.next) {
            case 0:
              if (!n.current) {
                _context43.next = 12;
                break;
              }
              ++c.current, u(!0);
              _context43.prev = 2;
              _context43.next = 5;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.find)({
                distinctField: "goodsNo",
                sortField: e,
                order: i,
                goodsType: "00,50",
                page: c.current,
                rows: 10,
                searchParam: o,
                classtreeCode: t
              });
            case 5:
              _r4 = _context43.sent;
              ((0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(_r4.list) || _r4.list.length < 10) && (n.current = !1), u(!1), a(function (t) {
                return t.concat(_r4.list);
              });
              _context43.next = 12;
              break;
            case 9:
              _context43.prev = 9;
              _context43.t0 = _context43["catch"](2);
              --c.current;
            case 12:
            case "end":
              return _context43.stop();
          }
        }, _callee43, null, [[2, 9]]);
      }));
    });
  return {
    loading: l,
    getData: m,
    list: d
  };
};
function So(_ref4) {
  var _this8 = this;
  var t = _ref4.contractBillcode,
    o = _ref4.contractBbillcode;
  var _s49 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!1),
    _s50 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s49, 2),
    e = _s50[0],
    n = _s50[1],
    c = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(""),
    d = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)(),
    _s51 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]),
    _s52 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s51, 2),
    a = _s52[0],
    l = _s52[1],
    u = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)({}),
    p = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)({
      dataBmoney: "",
      contractBillcode: ""
    });
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    (function () {
      Bt(_this8, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee44() {
        var e, _n4, _c2, _i3;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee44$(_context44) {
          while (1) switch (_context44.prev = _context44.next) {
            case 0:
              _context44.prev = 0;
              console.log(25, t);
              _n4 = t ? (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.syncContractState)({
                contractBillcode: t,
                isLocalMock: !d
              }) : (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.syncContractBatchState)({
                contractBbillcode: o,
                isLocalMock: !d
              });
              _context44.next = 5;
              return _n4;
            case 5:
              _c2 = _context44.sent;
              p.current = _c2.dataObj;
              _context44.next = 9;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.saveOrderToPay)({
                contractBillcode: null !== (e = p.current.contractBillcode) && void 0 !== e ? e : "",
                isLocalMock: !d
              });
            case 9:
              _i3 = _context44.sent;
              l(_i3.payChannelList), u.current = _i3;
              _context44.next = 16;
              break;
            case 13:
              _context44.prev = 13;
              _context44.t0 = _context44["catch"](0);
              console.log(_context44.t0);
            case 16:
            case "end":
              return _context44.stop();
          }
        }, _callee44, null, [[0, 13]]);
      }));
    })();
  }, []);
  var m = function m(t, o) {
      return t.find(function (t) {
        return t.fchannelCode === o;
      }) || {};
    },
    g = function g() {
      return Bt(_this8, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee45() {
        var t, o, _ref5, e, i, r, s, d;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee45$(_context45) {
          while (1) switch (_context45.prev = _context45.next) {
            case 0:
              o = null !== (t = p.current.contractBillcode) && void 0 !== t ? t : "";
              (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.setStorage)("contractBillcode", {
                contractBillcode: o
              });
              _ref5 = function () {
                n(!0);
                var _u$current = u.current,
                  t = _u$current.ptradeSeqno,
                  o = _u$current.contractBlance,
                  e = _u$current.payChannelList,
                  _m2 = m(e, c.current),
                  i = _m2.fchannelCode,
                  _m2$faccountOuterNo = _m2.faccountOuterNo,
                  r = _m2$faccountOuterNo === void 0 ? "" : _m2$faccountOuterNo;
                return {
                  ptradeSeqno: t,
                  contractBlance: o,
                  fchannelCode: i,
                  faccountOuterNo: r
                };
              }(), e = _ref5.ptradeSeqno, i = _ref5.contractBlance, r = _ref5.fchannelCode, s = _ref5.faccountOuterNo, d = [{
                faccountIdType: "ACCOUNT",
                fchannelCode: r,
                orderAmount: p.current.dataBmoney,
                faccountId: s
              }];
              _context45.next = 5;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.paymentCommit)({
                ptradeSeqno: e,
                payCommitStr: JSON.stringify(d),
                contractBlance: i
              });
            case 5:
              return _context45.abrupt("return", _context45.sent);
            case 6:
            case "end":
              return _context45.stop();
          }
        }, _callee45);
      }));
    },
    y = function y() {
      return Bt(_this8, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee46() {
        var _t9;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee46$(_context46) {
          while (1) switch (_context46.prev = _context46.next) {
            case 0:
              _context46.prev = 0;
              _context46.next = 3;
              return g();
            case 3:
              _t9 = _context46.sent;
              document.getElementById("v_html").innerHTML = "<div>" + _t9.dataObj.htmlStr + "</div>", document.forms[0].submit();
              _context46.next = 10;
              break;
            case 7:
              _context46.prev = 7;
              _context46.t0 = _context46["catch"](0);
              n(!1);
            case 10:
            case "end":
              return _context46.stop();
          }
        }, _callee46, null, [[0, 7]]);
      }));
    },
    v = function v() {
      return Bt(_this8, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee47() {
        var _t10;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee47$(_context47) {
          while (1) switch (_context47.prev = _context47.next) {
            case 0:
              _context47.prev = 0;
              _context47.next = 3;
              return g();
            case 3:
              _t10 = _context47.sent;
              document.getElementById("v_html").innerHTML = "<div>" + _t10.dataObj.htmlStr + "</div>", document.getElementById("paaspaysubmit").submit();
              _context47.next = 10;
              break;
            case 7:
              _context47.prev = 7;
              _context47.t0 = _context47["catch"](0);
              n(!1);
            case 10:
            case "end":
              return _context47.stop();
          }
        }, _callee47, null, [[0, 7]]);
      }));
    },
    f = function f() {
      return Bt(_this8, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee48() {
        var _t11;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee48$(_context48) {
          while (1) switch (_context48.prev = _context48.next) {
            case 0:
              _context48.prev = 0;
              _context48.next = 3;
              return g();
            case 3:
              _t11 = _context48.sent.dataObj.requestData;
              wx.requestPayment({
                timeStamp: _t11.timeStamp,
                nonceStr: _t11.nonceStr,
                package: _t11.package,
                signType: _t11.signType,
                paySign: _t11.paySign,
                success: function success(t) {
                  var o;
                  var e = null !== (o = p.current.contractBillcode) && void 0 !== o ? o : "";
                  (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("result", {
                    code: e
                  });
                },
                fail: function fail(t) {
                  n(!1);
                },
                complete: function complete(t) {
                  n(!1);
                }
              });
              _context48.next = 10;
              break;
            case 7:
              _context48.prev = 7;
              _context48.t0 = _context48["catch"](0);
              n(!1);
            case 10:
            case "end":
              return _context48.stop();
          }
        }, _callee48, null, [[0, 7]]);
      }));
    };
  return {
    paymentImpl: function paymentImpl() {
      switch (c.current || (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.taroMessage)("请选择支付方式", "none"), c.current) {
        case "wechatmini":
          f();
          break;
        case "wechatwap":
          v();
          break;
        case "alipaywap":
          y();
      }
    },
    channelList: a,
    handleRadio: function handleRadio(t) {
      c.current = t.detail.value;
    },
    contract: p,
    loading: e
  };
}
var bo = {
    provinceName: "",
    cityName: "",
    areaName: "",
    addressDetail: "",
    addressMember: "",
    addressPhone: "",
    addressDefault: ""
  },
  No = {
    contractSettlOpno: 0,
    promotionCodes: null,
    shoppingCountPrice: 0,
    totalDiscountPrice: 0,
    accountsSumPrice: 0,
    discount: 0,
    freight: 0,
    comDisMoney: 0,
    copyComDisMoney: 0
  },
  Oo = {
    dataPic: "",
    goodsName: "",
    goodsCamount: 0,
    skuName: "",
    pricesetNprice: 0
  };
function Lo(_ref6, n, c) {
  var _this9 = this;
  var t = _ref6.skuId,
    o = _ref6.goodsNum,
    e = _ref6.shoppingGoodsId;
  var d = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)([{
      dataPic: "",
      goodsName: "",
      goodsCamount: 0,
      skuName: "",
      pricesetNprice: 0
    }]),
    _s53 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]),
    _s54 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s53, 2),
    a = _s54[0],
    l = _s54[1],
    _s55 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(bo),
    _s56 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s55, 2),
    u = _s56[0],
    m = _s56[1],
    g = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(""),
    y = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)([]),
    v = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)([]),
    f = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)([]),
    _s57 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0),
    _s58 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s57, 2),
    h = _s58[0],
    C = _s58[1],
    S = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)(),
    b = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(No),
    N = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)([]);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    (function () {
      Bt(_this9, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee49() {
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee49$(_context49) {
          while (1) switch (_context49.prev = _context49.next) {
            case 0:
              C(0);
              b.current = {
                contractSettlOpno: 0,
                promotionCodes: null,
                shoppingCountPrice: 0,
                totalDiscountPrice: 0,
                accountsSumPrice: 0,
                discount: 0,
                freight: 0,
                comDisMoney: 0,
                copyComDisMoney: 0
              };
              v.current = [];
              y.current = [];
              if (!e) {
                _context49.next = 9;
                break;
              }
              _context49.next = 7;
              return L(function () {
                return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryShoppingToContract)({
                  shoppingGoodsIdStr: "[".concat(e, "]")
                });
              });
            case 7:
              _context49.next = 11;
              break;
            case 9:
              _context49.next = 11;
              return L(function () {
                return wt(t, o);
              });
            case 11:
            case "end":
              return _context49.stop();
          }
        }, _callee49);
      }));
    })();
  }, [n]);
  var O = function O() {
      return Bt(_this9, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee50() {
        var _t12;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee50$(_context50) {
          while (1) switch (_context50.prev = _context50.next) {
            case 0:
              _context50.prev = 0;
              _context50.next = 3;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryUserConByGoods)({
                pmContractGoodsDomainListStr: JSON.stringify(v.current)
              });
            case 3:
              _t12 = _context50.sent;
              l(_t12);
              _context50.next = 10;
              break;
            case 7:
              _context50.prev = 7;
              _context50.t0 = _context50["catch"](0);
              console.log(74, _context50.t0);
            case 10:
            case "end":
              return _context50.stop();
          }
        }, _callee50, null, [[0, 7]]);
      }));
    },
    L = function L(t) {
      return Bt(_this9, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee51() {
        var _o9, _o10, _o10$, _e4, _o10$2, _n5, _i4;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee51$(_context51) {
          while (1) switch (_context51.prev = _context51.next) {
            case 0:
              _context51.prev = 0;
              _context51.next = 3;
              return Promise.all([(0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryAddressBymerberCode)({
                isLocalMock: !S
              }), t()]);
            case 3:
              _o9 = _context51.sent;
              console.log(134, _o9);
              _o10 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_o9, 2), _o10$ = _o10[0], _e4 = _o10$ === void 0 ? [] : _o10$, _o10$2 = _o10[1], _n5 = _o10$2 === void 0 ? [] : _o10$2, _i4 = c ? _e4.find(function (t) {
                return t.addressId === c;
              }) : _e4.find(function (t) {
                return "1" === t.addressDefault;
              }) || {};
              m(_i4), I(_n5, _i4), c = "";
              _context51.next = 12;
              break;
            case 9:
              _context51.prev = 9;
              _context51.t0 = _context51["catch"](0);
              console.log(_context51.t0);
            case 12:
            case "end":
              return _context51.stop();
          }
        }, _callee51, null, [[0, 9]]);
      }));
    },
    I = function I(t, o) {
      (0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(t) || t.forEach(function (t) {
        t.shoppingpackageList.forEach(function (t) {
          b.current.comDisMoney += t.disMoney, b.current.copyComDisMoney += t.disMoney, t.shoppingGoodsList.forEach(function (o) {
            v.current.push(o), b.current.shoppingCountPrice += o.pricesetNprice * o.goodsCamount, o.contractGoodsGtype = 0, g.current = t.promotionCode, "00" == o.goodsType && (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.getFalgSettingForPaydate)().then(function (t) {});
          }), t.disMoney > 0 && y.current.push({
            contractSettlBlance: 0 == t.promotionInType ? "PM" : "COP",
            contractPmode: "0",
            contractSettlGmoney: Number(t.disMoney.toFixed(2)),
            contractSettlPmoney: Number(t.disMoney.toFixed(2)),
            contractSettlOpno: t.promotionCode,
            contractSettlOpemo: t.promotionName
          }), t.giftList ? (t.shoppingGoodsList.forEach(function (t) {
            t.ginfoCode = t.pmPromotionList.find(function (t) {
              return "0001" == t.pbCode;
            }).promotionCode;
          }), d.current = [].concat((0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_9__["default"])(t.shoppingGoodsList), (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_9__["default"])(t.giftList))) : d.current = t.shoppingGoodsList;
        }), k(), S && (O(), B(o));
      });
    },
    k = function k() {
      var _b$current = b.current,
        t = _b$current.shoppingCountPrice,
        o = _b$current.totalDiscountPrice,
        e = _b$current.discount,
        n = _b$current.comDisMoney,
        c = _b$current.freight;
      C(t - o - e - n + c);
    },
    M = function M() {
      var _b$current2 = b.current,
        t = _b$current2.shoppingCountPrice,
        o = _b$current2.copyComDisMoney,
        e = _b$current2.discount;
      return (t - o - e).toFixed(2);
    },
    D = function D() {
      var _b$current3 = b.current,
        t = _b$current3.shoppingCountPrice,
        o = _b$current3.copyComDisMoney,
        e = _b$current3.freight;
      return (t - o + e).toFixed(2);
    },
    B = function B(e) {
      f.current = function (e) {
        var n = e.addressMember,
          c = e.userName,
          i = e.provinceName,
          r = e.cityName,
          s = e.areaName,
          a = e.addressDetail,
          l = e.areaCode;
        return [{
          contractPaytime: new Date().valueOf(),
          goodsPbillno: 0,
          goodsPmbillno: b.current.promotionCodes,
          contractProperty: "0",
          contractBlance: 0,
          contractPmode: 0,
          contractPumode: "0",
          goodsSupplierName: "",
          goodsSupplierCode: "",
          packageList: [{
            contractGoodsList: d.current,
            shoppingGoodsIdList: [],
            promotionCode: g.current,
            packageRemark: null
          }],
          packageMode: "",
          contractType: "50",
          ocContractSettlList: [],
          contractInmoney: D(),
          contractMoney: M(),
          goodsReceiptMem: n,
          goodsReceiptPhone: c,
          goodsReceiptArrdess: i + r + s + a,
          areaCode: l,
          contractNbillcode: null,
          skuIdList: t ? [{
            skuId: +t,
            goodsNum: +o
          }] : [],
          giftSkuIdList: []
        }];
      }(e);
      var n = {
        rsSkuListStr: JSON.stringify(f.current)
      };
      var c;
      (c = n, Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee52() {
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee52$(_context52) {
          while (1) switch (_context52.prev = _context52.next) {
            case 0:
              _context52.next = 2;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.getTotalDiscountPrice)(c);
            case 2:
              return _context52.abrupt("return", _context52.sent);
            case 3:
            case "end":
              return _context52.stop();
          }
        }, _callee52);
      }))).then(function (t) {
        b.current.totalDiscountPrice = t.dataObj.totalDiscountPrice, b.current.contractSettlOpno = t.dataObj.contractSettlOpno, k();
      });
    };
  return {
    savePayPrice: function savePayPrice() {
      if ((0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(u)) return;
      (function () {
        var _b$current4 = b.current,
          t = _b$current4.contractSettlOpno,
          o = _b$current4.totalDiscountPrice;
        t && 0 != o && y.current.push({
          contractSettlBlance: "UR",
          contractPmode: "0",
          contractSettlPmoney: o,
          contractSettlOpno: t
        });
      })(), (0,lodash_es__WEBPACK_IMPORTED_MODULE_13__["default"])(f.current, "[0].ocContractSettlList", [].concat((0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_9__["default"])(y.current), (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_9__["default"])(N.current)));
      var t = {
        orderDomainStr: JSON.stringify(f.current)
      };
      (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.saveContract)(t).then(function (t) {
        (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("paymentMode", {
          code: t.dataObj.contractBillcode
        });
      });
    },
    address: u,
    list: d,
    payState: b,
    coupon: a,
    confirm: function confirm(t) {
      var o = t.couponAmount,
        e = t.usercouponCode,
        n = t.promotionCode,
        c = t.discAmount;
      N.current = [{
        contractSettlBlance: "COP",
        contractPmode: "0",
        contractSettlGmoney: +o,
        contractSettlPmoney: +c,
        contractSettlOpno: e,
        contractSettlOpemo: n
      }], b.current.discount = c, k();
    },
    amount: h
  };
}
function Po(t) {
  var _d2 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
      var o = {
        shoppingCountPrice: 0,
        freight: 0,
        comDisMoney: 0
      };
      return t.forEach(function (t) {
        var e = t.shoppingCountPrice,
          n = t.freight,
          c = t.comDisMoney;
        o.shoppingCountPrice += e, o.freight += n, o.comDisMoney += c;
      }), o;
    }, [t]),
    o = _d2.shoppingCountPrice,
    e = _d2.freight,
    n = _d2.comDisMoney;
  return {
    shoppingCountPrice: o,
    freight: e,
    comDisMoney: n
  };
}
var Io = {
    register: "/account/register/index",
    accountLogin: "/account/accountLogin/index",
    mobileLogin: "/account/mobileLogin/index",
    forgetPwd: "/account/forgetPwd/index",
    agreement: "/account/agreement/index",
    auth: "/account/auth/index",
    confirmPhone: "/account/confirmPhone/index",
    bindPhone: "/account/bindPhone/index"
  },
  ko = ["pages/index/index"],
  Mo = {
    addressId: "",
    addressInfo: {}
  },
  Do = {
    provinceName: "",
    cityName: "",
    areaName: "",
    addressDetail: "",
    addressMember: "",
    addressPhone: "",
    addressDefault: "",
    addressId: "",
    areaCode: "",
    userName: ""
  },
  Bo = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)();
function jo(t) {
  var _this10 = this;
  var _s59 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(Do),
    _s60 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s59, 2),
    o = _s60[0],
    e = _s60[1];
  return (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    (function () {
      Bt(_this10, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee53() {
        var _o11, _n6;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee53$(_context53) {
          while (1) switch (_context53.prev = _context53.next) {
            case 0:
              _context53.prev = 0;
              _context53.next = 3;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryAddressBymerberCode)({
                isLocalMock: !Bo,
                needCache: !0
              });
            case 3:
              _o11 = _context53.sent;
              _n6 = function () {
                var e = (0,lodash_es__WEBPACK_IMPORTED_MODULE_14__["default"])(_o11, "addressDefault", "asc"),
                  n = e.find(function (o) {
                    return t === o.addressId;
                  }) || {};
                return (0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(n) ? e.at(-1) : n;
              }();
              Mo.addressInfo = _n6, e(_n6);
              _context53.next = 10;
              break;
            case 8:
              _context53.prev = 8;
              _context53.t0 = _context53["catch"](0);
            case 10:
            case "end":
              return _context53.stop();
          }
        }, _callee53, null, [[0, 8]]);
      }));
    })();
  }, [t]), o;
}
var Go = {
    contractSettlBlance: "",
    contractPmode: "",
    contractSettlGmoney: null,
    contractSettlPmoney: null,
    contractSettlOpno: "",
    contractSettlOpemo: ""
  },
  wo = {
    current: Go,
    listeners: [],
    subscribe: function subscribe(t) {
      return wo.listeners.push(t), function () {
        wo.listeners = wo.listeners.filter(function (o) {
          return o !== t;
        });
      };
    },
    getSnapshot: function getSnapshot() {
      return wo.current;
    },
    reduce: function reduce(t, o) {
      return "select" === o.type ? Object.assign(Object.assign({}, t), o.payload) : t;
    },
    dispatch: function dispatch(t) {
      var o = wo.current;
      wo.current = wo.reduce(o, t);
      var _iterator = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_15__["default"])(wo.listeners),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var _t13 = _step.value;
          _t13();
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }
  },
  To = {
    shoppingGoodsId: "",
    goodsNum: 0,
    skuId: "",
    refreshNum: 0
  },
  Ao = {
    dataPic: "",
    goodsName: "",
    goodsCamount: 0,
    skuName: "",
    pricesetNprice: 0
  },
  xo = {
    contractSettlOpno: 0,
    shoppingCountPrice: 0,
    totalDiscountPrice: 0,
    accountsSumPrice: 0,
    discount: 0,
    freight: 0,
    comDisMoney: 0,
    copyComDisMoney: 0,
    shoppingType: "",
    promotionCode: "",
    promotionCodes: ""
  },
  Fo = function Fo(_ref7) {
    var t = _ref7.shoppingGoodsId,
      o = _ref7.goodsNum,
      e = _ref7.skuId;
    var _s61 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([Ao]),
      _s62 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s61, 2),
      n = _s62[0],
      a = _s62[1],
      _s63 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]),
      _s64 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s63, 2),
      l = _s64[0],
      u = _s64[1],
      _s65 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]),
      _s66 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s65, 2),
      p = _s66[0],
      m = _s66[1],
      g = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)([]),
      _s67 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0),
      _s68 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s67, 2),
      y = _s68[0],
      v = _s68[1],
      f = (0,react__WEBPACK_IMPORTED_MODULE_1__.useSyncExternalStore)(wo.subscribe, wo.getSnapshot);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee54() {
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee54$(_context54) {
          while (1) switch (_context54.prev = _context54.next) {
            case 0:
              if (!t) {
                _context54.next = 5;
                break;
              }
              _context54.next = 3;
              return C(function () {
                return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryShoppingToContract)({
                  shoppingGoodsIdStr: "[".concat(t, "]")
                });
              });
            case 3:
              _context54.next = 7;
              break;
            case 5:
              _context54.next = 7;
              return C(function () {
                return wt(e, o);
              });
            case 7:
            case "end":
              return _context54.stop();
          }
        }, _callee54);
      }));
    }, []);
    var h = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
        return f.contractSettlPmoney || 0;
      }, [f]),
      C = function C(t) {
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee55() {
          var _o12;
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee55$(_context55) {
            while (1) switch (_context55.prev = _context55.next) {
              case 0:
                _context55.prev = 0;
                _context55.next = 3;
                return t();
              case 3:
                _o12 = _context55.sent;
                S(_o12);
                _context55.next = 9;
                break;
              case 7:
                _context55.prev = 7;
                _context55.t0 = _context55["catch"](0);
              case 9:
              case "end":
                return _context55.stop();
            }
          }, _callee55, null, [[0, 7]]);
        }));
      },
      S = function S(t) {
        if ((0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(t)) return;
        var o = [],
          e = [],
          n = [];
        t.forEach(function (t) {
          var c = Object.assign({}, xo);
          c.shoppingType = t.goodsType, t.shoppingpackageList.forEach(function (t) {
            c.comDisMoney += t.disMoney, c.copyComDisMoney += t.disMoney, t.shoppingGoodsList.forEach(function (e) {
              o.push(e), c.shoppingCountPrice += e.pricesetNprice * e.goodsCamount, e.contractGoodsGtype = 0, c.promotionCode = t.promotionCode, e.goodsType;
            }), t.disMoney > 0 && g.current.push({
              contractSettlBlance: 0 == t.promotionInType ? "PM" : "COP",
              contractPmode: "0",
              contractSettlGmoney: Number(t.disMoney.toFixed(2)),
              contractSettlPmoney: Number(t.disMoney.toFixed(2)),
              contractSettlOpno: t.promotionCode,
              contractSettlOpemo: t.promotionName
            }), t.giftList && (t.shoppingGoodsList = t.shoppingGoodsList.map(function (t) {
              return t.ginfoCode = t.pmPromotionList.find(function (t) {
                return "0001" == t.pbCode;
              }).promotionCode, t;
            })), e.push.apply(e, (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_9__["default"])(t.shoppingGoodsList).concat((0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_9__["default"])(t.giftList || [])));
          }), n.push(c);
        }), u(n), a(e), m(o), b(n);
      },
      b = function b(t) {
        var o = 0;
        t.forEach(function (t) {
          var e = t.shoppingCountPrice,
            n = t.totalDiscountPrice,
            c = t.discount,
            i = t.comDisMoney,
            r = t.freight;
          o += e - n - c - i + r;
        }), v(o);
      };
    return {
      amount: y,
      list: n,
      shoppingGoodsList: p,
      payState: l,
      ocContractSettlList: g,
      disCount: h,
      orderStoreInfo: f
    };
  },
  Eo = function Eo() {
    var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
    var _s69 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]),
      _s70 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s69, 2),
      o = _s70[0],
      e = _s70[1],
      _s71 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!1),
      _s72 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s71, 2),
      n = _s72[0],
      c = _s72[1],
      _s73 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(),
      _s74 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s73, 2),
      i = _s74[0],
      a = _s74[1];
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee56() {
        var _o13;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee56$(_context56) {
          while (1) switch (_context56.prev = _context56.next) {
            case 0:
              _context56.prev = 0;
              if (!(0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(t)) {
                _context56.next = 3;
                break;
              }
              return _context56.abrupt("return");
            case 3:
              _context56.next = 5;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryUserConByGoods)({
                pmContractGoodsDomainListStr: JSON.stringify(t)
              });
            case 5:
              _o13 = _context56.sent;
              e(_o13);
              _context56.next = 12;
              break;
            case 9:
              _context56.prev = 9;
              _context56.t0 = _context56["catch"](0);
              console.log(74, _context56.t0);
            case 12:
            case "end":
              return _context56.stop();
          }
        }, _callee56, null, [[0, 9]]);
      }));
    }, [t]);
    var l = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
        return (o.find(function (t) {
          return t.promotionCode === i;
        }) || {}).promotionName;
      }, [i]),
      u = function u(t) {
        var o = t.couponAmount,
          e = t.usercouponCode,
          n = t.promotionCode,
          c = t.discAmount,
          i = {
            contractSettlBlance: "COP",
            contractPmode: "0",
            contractSettlGmoney: +o,
            contractSettlPmoney: +c,
            contractSettlOpno: e,
            contractSettlOpemo: n
          };
        wo.dispatch({
          type: "select",
          payload: i
        });
      };
    return {
      coupon: o,
      visible: n,
      selectCoupon: l,
      onChange: function onChange(t) {
        var e = t.detail.value,
          n = o.find(function (t) {
            return t.promotionCode === e;
          }) || {};
        a(e), c(!1), u(n);
      },
      setVisible: c
    };
  };
function Vo(_ref8) {
  var _this11 = this;
  var t = _ref8.ocContractSettlList,
    o = _ref8.payState,
    e = _ref8.list;
  var n = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "";
  var c = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
  var r = arguments.length > 3 ? arguments[3] : undefined;
  var d = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)([]),
    _s75 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!1),
    _s76 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s75, 2),
    a = _s76[0],
    l = _s76[1],
    u = function u(t) {
      var o = t.shoppingCountPrice,
        e = t.copyComDisMoney,
        n = t.discount;
      return (o - e - n).toFixed(2);
    },
    p = function p(t) {
      var o = t.shoppingCountPrice,
        e = t.copyComDisMoney,
        n = t.freight;
      return (o - e + n).toFixed(2);
    };
  return {
    savePayPrice: function savePayPrice() {
      return Bt(_this11, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee57() {
        var i, s, _t14, _vt2, _o14, _e5;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee57$(_context57) {
          while (1) switch (_context57.prev = _context57.next) {
            case 0:
              i = Mo.addressInfo;
              if (!(0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(i)) {
                _context57.next = 3;
                break;
              }
              return _context57.abrupt("return", void (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.taroMessage)("请选择收货地址"));
            case 3:
              d.current = function (t) {
                var i = t.addressMember,
                  r = t.userName,
                  s = t.provinceName,
                  d = t.cityName,
                  a = t.areaName,
                  l = t.addressDetail,
                  m = t.areaCode;
                return o.map(function (t) {
                  return {
                    contractPaytime: new Date().valueOf(),
                    goodsPbillno: 0,
                    goodsPmbillno: t.promotionCodes,
                    contractProperty: "0",
                    contractBlance: 0,
                    contractPmode: 0,
                    contractPumode: "0",
                    goodsSupplierName: "",
                    goodsSupplierCode: "",
                    packageList: [{
                      contractGoodsList: e,
                      shoppingGoodsIdList: [],
                      promotionCode: t.promotionCode,
                      packageRemark: null
                    }],
                    packageMode: "",
                    contractType: t.shoppingType,
                    ocContractSettlList: [],
                    contractInmoney: p(t),
                    contractMoney: u(t),
                    goodsReceiptMem: i,
                    goodsReceiptPhone: r,
                    goodsReceiptArrdess: s + d + a + l,
                    areaCode: m,
                    contractNbillcode: null,
                    skuIdList: n ? [{
                      skuId: +n,
                      goodsNum: +c
                    }] : [],
                    giftSkuIdList: []
                  };
                });
              }(i), (0,lodash_es__WEBPACK_IMPORTED_MODULE_13__["default"])(d.current, "[0].ocContractSettlList", [].concat((0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_9__["default"])(t.current), [r])), l(!0);
              s = {
                orderDomainStr: JSON.stringify(d.current)
              };
              _context57.prev = 5;
              _context57.next = 8;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.saveContract)(s);
            case 8:
              _t14 = _context57.sent;
              _vt2 = (0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(_t14, "dataObj", {
                contractBillcode: "",
                contractBbillcode: ""
              });
              _o14 = _vt2.contractBillcode;
              _e5 = _vt2.contractBbillcode;
              (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("paymentMode", {
                contractBillcode: _o14,
                contractBbillcode: _e5
              });
              _context57.next = 18;
              break;
            case 15:
              _context57.prev = 15;
              _context57.t0 = _context57["catch"](5);
              (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.taroMessage)(_context57.t0.msg || "获取订单失败");
            case 18:
              _context57.prev = 18;
              l(!1);
              return _context57.finish(18);
            case 21:
            case "end":
              return _context57.stop();
          }
        }, _callee57, null, [[5, 15, 18, 21]]);
      }));
    },
    loading: a
  };
}
function Ro(t) {
  var _this12 = this;
  var _s77 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({}),
    _s78 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s77, 2),
    o = _s78[0],
    e = _s78[1],
    n = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)();
  return (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    (function () {
      Bt(_this12, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee58() {
        var _o15, _c3, _o$dataObj, _i5, _at4, _at4$CartList, _r5;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee58$(_context58) {
          while (1) switch (_context58.prev = _context58.next) {
            case 0:
              _context58.prev = 0;
              _context58.next = 3;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.syncContractPayState)({
                contractBillcode: t,
                isLocalMock: !n
              });
            case 3:
              _o15 = _context58.sent;
              _c3 = _o15.sysRecode;
              _o$dataObj = _o15.dataObj;
              _i5 = _o$dataObj === void 0 ? {} : _o$dataObj;
              e({
                sysRecode: _c3,
                dataObj: _i5
              });
              _at4 = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getPagesRefreshStore)(), _at4$CartList = _at4.CartList, _r5 = _at4$CartList === void 0 ? 0 : _at4$CartList;
              (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.updatePagesRefreshStore)({
                CartList: _r5 + 1
              });
              _context58.next = 15;
              break;
            case 12:
              _context58.prev = 12;
              _context58.t0 = _context58["catch"](0);
              console.log(_context58.t0);
            case 15:
            case "end":
              return _context58.stop();
          }
        }, _callee58, null, [[0, 12]]);
      }));
    })();
  }, []), {
    result: o
  };
}
function Jo(t, o) {
  var _s79 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(t),
    _s80 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s79, 2),
    e = _s80[0],
    n = _s80[1];
  return (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    var e = o.filter(function (t) {
      return !((0,lodash_es__WEBPACK_IMPORTED_MODULE_16__["default"])(t) || (0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(t));
    }).filter(function (t) {
      return !Object.values(t).every(function (o) {
        return (0,lodash_es__WEBPACK_IMPORTED_MODULE_16__["default"])(o) || (0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(t);
      });
    });
    var c = t;
    (0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(e) || (c = e), n(c);
  }, [o]), e;
}
var qo = [{
    name: "全部",
    code: ""
  }, {
    name: "待付款",
    code: "1"
  }, {
    name: "待发货",
    code: "2"
  }, {
    name: "待收货",
    code: "3"
  }, {
    name: "已完成",
    code: "4,5"
  }, {
    name: "已取消",
    code: "-1"
  }],
  Uo = function Uo(t) {
    var _ref9 = qo.find(function (o) {
        return o.code.includes(t + "");
      }) || {},
      _ref9$name = _ref9.name,
      o = _ref9$name === void 0 ? "" : _ref9$name;
    return o;
  },
  $o = {
    1: [{
      name: "取消订单",
      handler: "cancel"
    }, {
      name: "立即支付",
      handler: "pay"
    }],
    3: [{
      name: "物流信息",
      handler: "expressInfo"
    }, {
      name: "确认收货",
      handler: "confirmReceive"
    }],
    4: [{
      name: "去评价",
      handler: "evaluate"
    }],
    5: [{
      name: "已完成"
    }]
  };
function zo(_ref10) {
  var _this13 = this;
  var _ref10$dataState = _ref10.dataState,
    t = _ref10$dataState === void 0 ? "" : _ref10$dataState,
    o = _ref10.contractId,
    e = _ref10.contractBillcode,
    n = _ref10.init;
  var c = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
      return $o[t + ""] || [];
    }, [t]),
    i = function () {
      return {
        expressInfo: function expressInfo() {
          (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("expressInfo", {
            code: e
          });
        },
        pay: function pay() {
          (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("paymentMode", {
            code: e
          });
        },
        evaluate: function evaluate() {
          (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("evaluateDetail", {
            code: e
          });
        },
        confirmReceive: function confirmReceive() {
          return Bt(_this13, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee59() {
            return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee59$(_context59) {
              while (1) switch (_context59.prev = _context59.next) {
                case 0:
                  _context59.prev = 0;
                  _context59.next = 3;
                  return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.confirmReceive)({
                    contractBillcode: e
                  });
                case 3:
                  null == n || n();
                  _context59.next = 8;
                  break;
                case 6:
                  _context59.prev = 6;
                  _context59.t0 = _context59["catch"](0);
                case 8:
                case "end":
                  return _context59.stop();
              }
            }, _callee59, null, [[0, 6]]);
          }));
        },
        cancel: function cancel() {
          return Bt(_this13, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee60() {
            return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee60$(_context60) {
              while (1) switch (_context60.prev = _context60.next) {
                case 0:
                  _context60.prev = 0;
                  _context60.next = 3;
                  return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.cancelContractC)({
                    contractId: o
                  });
                case 3:
                  null == n || n();
                  _context60.next = 8;
                  break;
                case 6:
                  _context60.prev = 6;
                  _context60.t0 = _context60["catch"](0);
                case 8:
                case "end":
                  return _context60.stop();
              }
            }, _callee60, null, [[0, 6]]);
          }));
        }
      };
    }();
  return {
    handlerImpl: function handlerImpl(t) {
      i[t]();
    },
    operateArray: c
  };
}
var Ho = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)(),
  Ko = {
    contractBillcode: "",
    goodsList: [{
      dataPic: "",
      goodsName: "",
      dataBmoney: 0,
      goodsCamount: 0,
      contractGoodsId: 0,
      dataState: 0
    }],
    dataBmoney: 0,
    dataBnum: 0,
    dataState: 0,
    contractId: "",
    contractAppraise: 0
  };
function Wo(t, o) {
  var _this14 = this;
  var e = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(!1),
    _s81 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!1),
    _s82 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s81, 2),
    n = _s82[0],
    c = _s82[1],
    _s83 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([Ko]),
    _s84 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s83, 2),
    d = _s84[0],
    a = _s84[1],
    l = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(0);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    u();
  }, [o]);
  var u = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.useImmutableCallback)(function () {
      l.current = 0, a([]), p();
    }),
    p = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.useImmutableCallback)(function () {
      var o = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      return Bt(_this14, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee61() {
        var o, _t15;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee61$(_context61) {
          while (1) switch (_context61.prev = _context61.next) {
            case 0:
              if (!e.current) {
                _context61.next = 2;
                break;
              }
              return _context61.abrupt("return");
            case 2:
              c(!0), ++l.current;
              o = t.code;
              _context61.prev = 4;
              _context61.next = 7;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryContractPageC)({
                page: l.current,
                rows: 10,
                isLocalMock: !Ho,
                childFlag: !0,
                dataStateStr: o
              });
            case 7:
              _t15 = _context61.sent;
              e.current = (0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(_t15.list) || _t15.list.length < 10, a(function (o) {
                return o.concat(_t15.list || []);
              }), c(!1);
              _context61.next = 14;
              break;
            case 11:
              _context61.prev = 11;
              _context61.t0 = _context61["catch"](4);
              --l.current, console.log(30, _context61.t0);
            case 14:
            case "end":
              return _context61.stop();
          }
        }, _callee61, null, [[4, 11]]);
      }));
    });
  return {
    onScroll: p,
    data: d,
    loading: n,
    init: u
  };
}
var _o = {
    goodsList: [],
    dataState: "",
    packageRemark: "",
    goodsReceiptMem: "",
    goodsReceiptPhone: "",
    goodsReceiptArrdess: "",
    dataBmoney: 0,
    goodsPmoney: 0,
    contractInmoney: 0,
    contractBillcode: "",
    refundMoney: 0,
    gmtCreate: "",
    goodsNum: 0,
    contractId: 0
  },
  Qo = function Qo(t) {
    var _s85 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(""),
      _s86 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s85, 2),
      o = _s86[0],
      e = _s86[1],
      n = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)(),
      _s87 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_o),
      _s88 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s87, 2),
      c = _s88[0],
      i = _s88[1];
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee62() {
        var _o16;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee62$(_context62) {
          while (1) switch (_context62.prev = _context62.next) {
            case 0:
              _context62.prev = 0;
              _context62.next = 3;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.getContractByCode)({
                contractBillcode: t,
                isLocalMock: !n
              });
            case 3:
              _o16 = _context62.sent;
              if (!(0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(_o16)) {
                _context62.next = 6;
                break;
              }
              return _context62.abrupt("return");
            case 6:
              e(Uo(_o16.dataState)), i(_o16);
              _context62.next = 12;
              break;
            case 9:
              _context62.prev = 9;
              _context62.t0 = _context62["catch"](0);
              console.log(45, _context62.t0);
            case 12:
            case "end":
              return _context62.stop();
          }
        }, _callee62, null, [[0, 9]]);
      }));
    }, []), {
      orderDetail: c,
      status: o
    };
  },
  Xo = {
    0: "在途",
    1: "揽收",
    2: "疑难",
    3: "签收",
    4: "退签",
    5: "派件",
    8: "清关",
    14: "拒签"
  },
  Yo = function Yo(t) {
    var _s89 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({}),
      _s90 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s89, 2),
      o = _s90[0],
      e = _s90[1],
      _s91 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({}),
      _s92 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s91, 2),
      n = _s92[0],
      c = _s92[1];
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee63() {
        var _o17, _n7, _i6, _r6, _s93;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee63$(_context63) {
          while (1) switch (_context63.prev = _context63.next) {
            case 0:
              _context63.prev = 0;
              _o17 = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)();
              _context63.next = 4;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.getContractByCode)({
                contractBillcode: t,
                isLocalMock: !_o17
              });
            case 4:
              _n7 = _context63.sent;
              e(_n7);
              _i6 = (0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(_n7, "packageList[0].expressCode", "");
              _r6 = (0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(_n7, "packageList[0].packageBillno");
              _context63.next = 10;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryExpressInfo)({
                expressNo: _r6,
                expressType: _i6,
                isLocalMock: !_o17
              });
            case 10:
              _s93 = _context63.sent;
              c(JSON.parse(_s93.dataObj));
              _context63.next = 17;
              break;
            case 14:
              _context63.prev = 14;
              _context63.t0 = _context63["catch"](0);
              console.log(_context63.t0);
            case 17:
            case "end":
              return _context63.stop();
          }
        }, _callee63, null, [[0, 14]]);
      }));
    }, []), {
      info: o,
      detail: n,
      stateObj: Xo
    };
  };
function Zo() {
  var _this15 = this;
  var _s94 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(""),
    _s95 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s94, 2),
    t = _s95[0],
    o = _s95[1],
    _s96 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]),
    _s97 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s96, 2),
    e = _s97[0],
    n = _s97[1],
    c = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)();
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    i();
  }, []);
  var i = function i() {
    return Bt(_this15, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee64() {
      var _t16, _e6;
      return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee64$(_context64) {
        while (1) switch (_context64.prev = _context64.next) {
          case 0:
            _context64.prev = 0;
            _context64.next = 3;
            return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryGoodsClassTree)();
          case 3:
            _t16 = _context64.sent;
            n(_t16 || []);
            _e6 = (0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(_t16, "[0].goodsClassCode");
            o(_e6);
            _context64.next = 12;
            break;
          case 9:
            _context64.prev = 9;
            _context64.t0 = _context64["catch"](0);
            console.log(_context64.t0);
          case 12:
          case "end":
            return _context64.stop();
        }
      }, _callee64, null, [[0, 9]]);
    }));
  };
  return {
    activeKey: t,
    navList: e,
    flag: c,
    setActiveKey: o
  };
}
var te = function te() {
    var _s98 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([{
        collectOpcont: "",
        collectOpnum: ""
      }]),
      _s99 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s98, 2),
      t = _s99[0],
      o = _s99[1],
      e = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(1),
      _s100 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!1),
      _s101 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s100, 2),
      n = _s101[0],
      c = _s101[1],
      _s102 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(""),
      _s103 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s102, 2),
      d = _s103[0],
      a = _s103[1],
      _s104 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!1),
      _s105 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s104, 2),
      l = _s105[0],
      u = _s105[1],
      _s106 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(""),
      _s107 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s106, 2),
      p = _s107[0],
      m = _s107[1],
      _s108 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!1),
      _s109 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s108, 2),
      g = _s109[0],
      y = _s109[1];
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      v();
    }, []);
    var v = function v() {
        e.current = 1, o([]), h();
      },
      h = function h() {
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee65() {
          var _t17;
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee65$(_context65) {
            while (1) switch (_context65.prev = _context65.next) {
              case 0:
                _context65.prev = 0;
                _context65.next = 3;
                return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryCollectPage)({
                  row: 10,
                  page: e.current,
                  collectType: 0
                });
              case 3:
                _t17 = _context65.sent;
                o(function (o) {
                  return o.concat((0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(_t17, "list", []));
                }), e.current += 1;
                _context65.next = 10;
                break;
              case 7:
                _context65.prev = 7;
                _context65.t0 = _context65["catch"](0);
                return _context65.abrupt("return", (console.log(_context65.t0), []));
              case 10:
              case "end":
                return _context65.stop();
            }
          }, _callee65, null, [[0, 7]]);
        }));
      },
      C = function C() {
        var o = [];
        for (var _e7 = 0; _e7 < t.length; _e7++) o.push(t[_e7].collectCode);
        return o.toString();
      };
    return {
      collectionList: t,
      edit: n,
      setEdit: c,
      getData: h,
      collectCodeStr: d,
      getSelectItem: function getSelectItem(o) {
        var e = o.detail.value;
        a(e.toString()), e.length === t.length ? y(!0) : (y(!1), a(""));
      },
      delItem: function delItem() {
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee66() {
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee66$(_context66) {
            while (1) switch (_context66.prev = _context66.next) {
              case 0:
                _context66.prev = 0;
                _context66.next = 3;
                return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.deleteCollectByCodeStr)({
                  collectCodeStr: d
                });
              case 3:
                e.current = 1;
                v();
                _context66.next = 10;
                break;
              case 7:
                _context66.prev = 7;
                _context66.t0 = _context66["catch"](0);
                console.log(_context66.t0);
              case 10:
              case "end":
                return _context66.stop();
            }
          }, _callee66, null, [[0, 7]]);
        }));
      },
      init: v,
      checked: l,
      setChecked: u,
      handleSelectAll: function handleSelectAll(t) {
        t.detail.value.length ? (u(!0), a(C())) : u(!1);
      },
      selectAll: p,
      setSelectAll: m,
      selectAllChecked: g
    };
  },
  oe = function oe(t) {
    var _s110 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]),
      _s111 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s110, 2),
      o = _s111[0],
      e = _s111[1],
      n = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)([]),
      c = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)({}),
      d = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee67() {
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee67$(_context67) {
          while (1) switch (_context67.prev = _context67.next) {
            case 0:
              _context67.next = 2;
              return u();
            case 2:
              _context67.next = 4;
              return a();
            case 4:
            case "end":
              return _context67.stop();
          }
        }, _callee67);
      }));
    }, []);
    var a = function a() {
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee68() {
          var _o18, _n8, _n$, _i7, _r7, _s112, _a2, _u2;
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee68$(_context68) {
            while (1) switch (_context68.prev = _context68.next) {
              case 0:
                _context68.prev = 0;
                _context68.next = 3;
                return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.getContractByCode)({
                  contractBillcode: t,
                  isLocalMock: !d
                });
              case 3:
                _o18 = _context68.sent;
                _n8 = l((0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(_o18, "goodsList", []));
                _n$ = _n8[0];
                _i7 = _n$.contractBillcode;
                _r7 = _n$.memberBcode;
                _s112 = _n$.memberBname;
                _a2 = _n$.memberCode;
                _u2 = _n$.memberName;
                c.current = {
                  contractBillcode: _i7,
                  memberBcode: _r7,
                  memberBname: _s112,
                  memberCode: _a2,
                  memberName: _u2
                }, e(_n8);
                _context68.next = 17;
                break;
              case 14:
                _context68.prev = 14;
                _context68.t0 = _context68["catch"](0);
                console.log(_context68.t0);
              case 17:
              case "end":
                return _context68.stop();
            }
          }, _callee68, null, [[0, 14]]);
        }));
      },
      l = function l(t) {
        for (var _o19 = 0; _o19 < t.length; _o19++) t[_o19].upImgLength = !0, t[_o19].upImg = [], t[_o19].evaluateGoodsImgs = "", t[_o19].evaluateScopeList = [n.current[0]], t[_o19].evaluateGoodsContent = "";
        return t;
      },
      u = function u() {
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee69() {
          var _t18;
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee69$(_context69) {
            while (1) switch (_context69.prev = _context69.next) {
              case 0:
                _context69.prev = 0;
                _context69.next = 3;
                return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryUseTemplate)({
                  applyTarget: "goods",
                  isLocalMock: !d
                });
              case 3:
                _t18 = _context69.sent;
                n.current = _t18[0].templateValuesReList;
                _context69.next = 10;
                break;
              case 7:
                _context69.prev = 7;
                _context69.t0 = _context69["catch"](0);
                console.log(_context69.t0);
              case 10:
              case "end":
                return _context69.stop();
            }
          }, _callee69, null, [[0, 7]]);
        }));
      };
    return {
      orderInfo: o,
      changeStar: function changeStar(t, c) {
        var i = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_9__["default"])(o),
          r = [];
        for (var _t19 = 0; _t19 < c; _t19++) r.push(n.current[_t19]);
        i[t].evaluateScopeList = r, e(i);
      },
      Submit: function Submit() {
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee70() {
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee70$(_context70) {
            while (1) switch (_context70.prev = _context70.next) {
              case 0:
                _context70.prev = 0;
                _context70.next = 3;
                return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.saveEvaluateGoods)({
                  paramStr: JSON.stringify(o)
                });
              case 3:
                _context70.next = 5;
                return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.saveEvaluateShop)(Object.assign({
                  paramStr: JSON.stringify(o)
                }, c.current));
              case 5:
                (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("orderlist");
                _context70.next = 11;
                break;
              case 8:
                _context70.prev = 8;
                _context70.t0 = _context70["catch"](0);
                console.log(_context70.t0);
              case 11:
              case "end":
                return _context70.stop();
            }
          }, _callee70, null, [[0, 8]]);
        }));
      },
      changeContent: function changeContent(t, n) {
        var c = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_9__["default"])(o);
        c[t].evaluateGoodsContent = n.detail.value, e(c);
      }
    };
  },
  ee = function ee() {
    var _s113 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([{
        footprintOpcont: "",
        footprintOpnum: "",
        gmtCreate: "",
        gmtModified: ""
      }, {
        footprintOpcont: "",
        footprintOpnum: "",
        gmtCreate: "",
        gmtModified: ""
      }, {
        footprintOpcont: "",
        footprintOpnum: "",
        gmtCreate: "",
        gmtModified: ""
      }, {
        footprintOpcont: "",
        footprintOpnum: "",
        gmtCreate: "",
        gmtModified: ""
      }, {
        footprintOpcont: "",
        footprintOpnum: "",
        gmtCreate: "",
        gmtModified: ""
      }]),
      _s114 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s113, 2),
      t = _s114[0],
      o = _s114[1],
      e = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(1),
      _s115 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!1),
      _s116 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s115, 2),
      n = _s116[0],
      c = _s116[1],
      _s117 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(""),
      _s118 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s117, 2),
      d = _s118[0],
      a = _s118[1],
      _s119 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!1),
      _s120 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s119, 2),
      l = _s120[0],
      u = _s120[1],
      _s121 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(""),
      _s122 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s121, 2),
      p = _s122[0],
      m = _s122[1],
      _s123 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!1),
      _s124 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s123, 2),
      g = _s124[0],
      y = _s124[1];
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      v();
    }, []);
    var v = function v() {
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee71() {
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee71$(_context71) {
            while (1) switch (_context71.prev = _context71.next) {
              case 0:
                e.current = 1;
                _context71.next = 3;
                return f();
              case 3:
              case "end":
                return _context71.stop();
            }
          }, _callee71);
        }));
      },
      f = function f() {
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee72() {
          var t, _n9;
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee72$(_context72) {
            while (1) switch (_context72.prev = _context72.next) {
              case 0:
                _context72.prev = 0;
                _context72.next = 3;
                return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryFootprintPagePlat)({
                  rows: 5,
                  page: e.current
                });
              case 3:
                _n9 = _context72.sent;
                if (!(0 === (null === (t = _n9.list) || void 0 === t ? void 0 : t.length))) {
                  _context72.next = 6;
                  break;
                }
                return _context72.abrupt("return");
              case 6:
                o(function (t) {
                  return 1 === e.current ? _n9.list : t.concat(_n9.list || []);
                }), e.current += 1;
                _context72.next = 12;
                break;
              case 9:
                _context72.prev = 9;
                _context72.t0 = _context72["catch"](0);
                return _context72.abrupt("return", (console.log(34, _context72.t0), o([]), []));
              case 12:
              case "end":
                return _context72.stop();
            }
          }, _callee72, null, [[0, 9]]);
        }));
      },
      h = function h() {
        var t = [];
        for (var _o20 = 0; _o20 < collectionList.length; _o20++) t.push(collectionList[_o20].collectCode);
        return t.toString();
      };
    return {
      footprintList: t,
      edit: n,
      setEdit: c,
      getData: f,
      getSelectItem: function getSelectItem(t) {
        var o = t.detail.value;
        console.log(43, o), a(o.toString());
      },
      delItem: function delItem() {
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee73() {
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee73$(_context73) {
            while (1) switch (_context73.prev = _context73.next) {
              case 0:
                _context73.prev = 0;
                _context73.next = 3;
                return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.deleteFootprintByCodeStr)({
                  footprintCodeStr: d
                });
              case 3:
                e.current = 1;
                _context73.next = 6;
                return v();
              case 6:
                _context73.next = 11;
                break;
              case 8:
                _context73.prev = 8;
                _context73.t0 = _context73["catch"](0);
                console.log(_context73.t0);
              case 11:
              case "end":
                return _context73.stop();
            }
          }, _callee73, null, [[0, 8]]);
        }));
      },
      init: v,
      checked: l,
      setChecked: u,
      handleSelectAll: function handleSelectAll(t) {
        t.detail.value.length ? (u(!0), setCollectCodeStr(h())) : u(!1);
      },
      selectAll: p,
      setSelectAll: m,
      selectAllChecked: g
    };
  };
function ne(t) {
  var _this16 = this;
  var _s125 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]),
    _s126 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s125, 2),
    o = _s126[0],
    e = _s126[1];
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    (function () {
      Bt(_this16, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee74() {
        var _o21, _n10;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee74$(_context74) {
          while (1) switch (_context74.prev = _context74.next) {
            case 0:
              _context74.prev = 0;
              _context74.next = 3;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryNoticePage)({
                page: 1,
                rows: t,
                dataState: 1
              });
            case 3:
              _o21 = _context74.sent;
              _n10 = (0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(_o21, "list", []);
              e(_n10);
              _context74.next = 10;
              break;
            case 8:
              _context74.prev = 8;
              _context74.t0 = _context74["catch"](0);
            case 10:
            case "end":
              return _context74.stop();
          }
        }, _callee74, null, [[0, 8]]);
      }));
    })();
  }, [t]);
  return {
    content: (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(function () {
      return o.map(function (t) {
        return t.noticeTitle;
      });
    }, [o]),
    navigator: function navigator(t) {
      var e = (0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(o, "".concat(t, ".noticeId"), "");
      (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.navigatorHandler)("noticeDetail", {
        noticeId: e
      });
    }
  };
}
var ce = function ce(t) {
    var _s127 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({}),
      _s128 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s127, 2),
      o = _s128[0],
      e = _s128[1];
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee75() {
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee75$(_context75) {
          while (1) switch (_context75.prev = _context75.next) {
            case 0:
              _context75.next = 2;
              return n();
            case 2:
            case "end":
              return _context75.stop();
          }
        }, _callee75);
      }));
    }, []);
    var n = function n() {
      return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee76() {
        var _o22;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee76$(_context76) {
          while (1) switch (_context76.prev = _context76.next) {
            case 0:
              _context76.prev = 0;
              _context76.next = 3;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.getNotice)({
                noticeId: t
              });
            case 3:
              _o22 = _context76.sent;
              e(_o22);
              _context76.next = 10;
              break;
            case 7:
              _context76.prev = 7;
              _context76.t0 = _context76["catch"](0);
              console.log(_context76.t0);
            case 10:
            case "end":
              return _context76.stop();
          }
        }, _callee76, null, [[0, 7]]);
      }));
    };
    return {
      info: o,
      setInfo: e
    };
  },
  ie = {
    doclistTitle: "",
    doclistTitle4: "",
    doclistContent: ""
  },
  re = function re(t) {
    var _s129 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(ie),
      _s130 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s129, 2),
      o = _s130[0],
      e = _s130[1];
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee77() {
        var _o23, _n11;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee77$(_context77) {
          while (1) switch (_context77.prev = _context77.next) {
            case 0:
              _context77.prev = 0;
              _o23 = (0,_brushes_utils__WEBPACK_IMPORTED_MODULE_3__.getEnv)();
              _context77.next = 4;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.getDoclist)({
                doclistId: t,
                isLocalMock: !_o23
              });
            case 4:
              _n11 = _context77.sent;
              e(_n11);
              _context77.next = 11;
              break;
            case 8:
              _context77.prev = 8;
              _context77.t0 = _context77["catch"](0);
              console.log(_context77.t0);
            case 11:
            case "end":
              return _context77.stop();
          }
        }, _callee77, null, [[0, 8]]);
      }));
    }, []), {
      info: o
    };
  },
  se = function se(_ref11) {
    var t = _ref11.defaultValue,
      o = _ref11.goods;
    console.log(17, t, o);
    var _s131 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(t),
      _s132 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s131, 2),
      e = _s132[0],
      n = _s132[1],
      c = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      (0,lodash_es__WEBPACK_IMPORTED_MODULE_17__["default"])(c.current, o) || (c.current = o, (0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(o) ? n(t) : Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee78() {
        var _t20;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee78$(_context78) {
          while (1) switch (_context78.prev = _context78.next) {
            case 0:
              _context78.prev = 0;
              _context78.next = 3;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.find)({
                goodsCode: o.toString(),
                distinctField: "goodsNo"
              });
            case 3:
              _t20 = _context78.sent;
              console.log(63, _t20), n(_t20.list);
              _context78.next = 10;
              break;
            case 7:
              _context78.prev = 7;
              _context78.t0 = _context78["catch"](0);
              n(t);
            case 10:
            case "end":
              return _context78.stop();
          }
        }, _callee78, null, [[0, 7]]);
      })));
    }, [o]), {
      list: e
    };
  },
  de = function de(t) {
    var _s133 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]),
      _s134 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s133, 2),
      o = _s134[0],
      e = _s134[1],
      _s135 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!1),
      _s136 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s135, 2),
      n = _s136[0],
      c = _s136[1],
      i = t.coupons,
      d = t.defaultValue;
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      a();
    }, [i]);
    var a = function a() {
      return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee79() {
        var _t21;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee79$(_context79) {
          while (1) switch (_context79.prev = _context79.next) {
            case 0:
              if (!(0 !== i.length)) {
                _context79.next = 13;
                break;
              }
              _context79.prev = 1;
              _context79.next = 4;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryPromotioByCodePage)({
                promotionCode: null == i ? void 0 : i.join(","),
                list: 1
              });
            case 4:
              _t21 = _context79.sent;
              e((0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(_t21, "list", []));
              _context79.next = 11;
              break;
            case 8:
              _context79.prev = 8;
              _context79.t0 = _context79["catch"](1);
              console.log(_context79.t0);
            case 11:
              _context79.next = 14;
              break;
            case 13:
              e(d);
            case 14:
            case "end":
              return _context79.stop();
          }
        }, _callee79, null, [[1, 8]]);
      }));
    };
    return {
      list: o,
      setList: e,
      takeCoupon: function takeCoupon(t) {
        return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee80() {
          return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee80$(_context80) {
            while (1) switch (_context80.prev = _context80.next) {
              case 0:
                if (n) {
                  _context80.next = 9;
                  break;
                }
                _context80.prev = 1;
                _context80.next = 4;
                return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.saveUsercoupon)(t);
              case 4:
                c(!0);
                _context80.next = 9;
                break;
              case 7:
                _context80.prev = 7;
                _context80.t0 = _context80["catch"](1);
              case 9:
              case "end":
                return _context80.stop();
            }
          }, _callee80, null, [[1, 7]]);
        }));
      },
      got: n
    };
  },
  ae = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)([{}, lodash_es__WEBPACK_IMPORTED_MODULE_11__["default"]]);
function le(_ref12) {
  var o = _ref12.initialValue,
    e = _ref12.children;
  return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ae.Provider, Object.assign({
    value: (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(o || {})
  }, {
    children: e
  }));
}
function ue() {
  var t = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(ae);
  return t || [{}, lodash_es__WEBPACK_IMPORTED_MODULE_11__["default"]];
}
var pe = function pe() {
    var _ue = ue(),
      _ue2 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_ue, 2),
      t = _ue2[1];
    return {
      goTop: function goTop() {
        t(function (t) {
          var o = t.scrollTop;
          return Object.assign(Object.assign({}, t), {
            scrollTop: 0 === o ? 1 : 0
          });
        });
      }
    };
  },
  me = function me(_ref13) {
    var t = _ref13.params;
    var o = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)([]),
      _s137 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]),
      _s138 = (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_s137, 2),
      e = _s138[0],
      n = _s138[1],
      c = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(0),
      d = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(10);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
      c.current = 0, o.current = [], a();
    }, [t]);
    var a = function a() {
      return Bt(void 0, void 0, void 0, /*#__PURE__*/(0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().mark(function _callee81() {
        var _o$current, _e8, _i8;
        return (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_regeneratorRuntime_js__WEBPACK_IMPORTED_MODULE_6__["default"])().wrap(function _callee81$(_context81) {
          while (1) switch (_context81.prev = _context81.next) {
            case 0:
              ++c.current;
              _context81.prev = 1;
              _context81.next = 4;
              return (0,qj_b2c_api__WEBPACK_IMPORTED_MODULE_2__.queryPromotioPage)({
                pbCode: t,
                list: 1,
                page: c.current,
                rows: d.current
              });
            case 4:
              _e8 = _context81.sent;
              _i8 = (0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(_e8, "list", []);
              (_o$current = o.current).push.apply(_o$current, (0,_Users_devil_Desktop_taro_taro_mobile_react_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_9__["default"])(_i8)), n(o.current);
              _context81.next = 12;
              break;
            case 9:
              _context81.prev = 9;
              _context81.t0 = _context81["catch"](1);
              console.log(_context81.t0);
            case 12:
            case "end":
              return _context81.stop();
          }
        }, _callee81, null, [[1, 9]]);
      }));
    };
    return {
      list: e,
      getData: a
    };
  };


/***/ })

}]);
//# sourceMappingURL=common.js.map